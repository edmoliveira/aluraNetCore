﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Advanced.Algorithms")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Advanced.Algorithms")]
[assembly: AssemblyCopyright("Copyright ©  2017")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

#if NET40
// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("0bcbf659-72a2-4f4c-a481-b40d78490c2f")]
#endif

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: InternalsVisibleTo("Advanced.Algorithms.Tests, PublicKey=" +
                              "00240000048000009400000006020000002400005253413100040000010001009d6e7fa635694c" +
                              "4f15e68996fe058ea398fcc08bd885b68a9b1027d0a89d90b009565a4dae145119bdc6f8454241" +
                              "8e36122767529b7e2b3fb126f986e55458e01ddb5c2e93e913fce5c32d1ce98ac741a8dd2f1c76" +
                              "29bd6bfd11fe86f6ea25aacb1c16e085d61103b16f8f667068415b7b02633b61aff76406e10313" +
                              "0bcf3ee5")]
[assembly: InternalsVisibleTo("Advanced.Algorithms.Tests, PublicKey=" +
                              "00240000048000009400000006020000002400005253413100040000010001009d6e7fa635694c" +
                              "4f15e68996fe058ea398fcc08bd885b68a9b1027d0a89d90b009565a4dae145119bdc6f8454241" +
                              "8e36122767529b7e2b3fb126f986e55458e01ddb5c2e93e913fce5c32d1ce98ac741a8dd2f1c76" +
                              "29bd6bfd11fe86f6ea25aacb1c16e085d61103b16f8f667068415b7b02633b61aff76406e10313" +
                              "0bcf3ee5")]