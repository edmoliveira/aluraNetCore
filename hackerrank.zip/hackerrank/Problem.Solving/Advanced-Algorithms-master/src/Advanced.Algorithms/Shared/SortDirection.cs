﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Advanced.Algorithms
{
    public enum SortDirection
    {
        Ascending = 0,
        Descending = 1
    }
}
