﻿using System.Collections.Generic;

namespace CaptchaGameLibrary.Extensions
{
    internal static class ListExtension
    {
        #region Public Methods

        /// <summary>
        /// Gets and removes the element at the specified index of the System.Collections.Generic.List`1
        /// </summary>
        /// <typeparam name="T">Type</typeparam>
        /// <param name="source">List</param>
        /// <param name="index">The zero-based index of the element to remove</param>
        /// <returns>returns the element at the specified index</returns>
        public static T PushAt<T>(this List<T> source, int index)
        {
            T value = source[index];

            source.RemoveAt(index);

            return value;
        }

        #endregion
    }
}
