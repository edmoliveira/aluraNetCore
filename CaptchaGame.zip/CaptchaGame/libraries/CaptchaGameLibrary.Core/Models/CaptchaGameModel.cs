﻿using CaptchaGameLibrary.Interfaces;

namespace CaptchaGameLibrary.Models
{
    /// <summary>
    /// Model to create the game script of the client side.
    /// </summary>
    public class CaptchaGameModel
    {
        #region Properties

        /// <summary>
        /// Object used for loading the game of the client side.
        /// </summary>
        public IGame Game { get; set; }
        /// <summary>
        /// Submit button of the client side.
        /// </summary>
        public string ButtonLink { get; set; }
        /// <summary>
        /// Container to put the object canvas of the client side.
        /// </summary>
        public string ContentLink { get; set; }
        /// <summary>
        /// Componet to save the result of the game.
        /// </summary>
        public string ValueLink { get; set; }

        #endregion
    }
}
