﻿using CaptchaGameLibrary.Formulas;
using CaptchaGameLibrary.Interfaces;
using CaptchaGameLibrary.Validators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CaptchaGameLibrary.Games
{
    /// <summary>
    /// Game Class Switch.
    /// </summary>
    internal sealed class SwitchGame : BaseGame
    {
        #region Properties

        /// <summary>
        /// key used for validation.
        /// </summary>
        public override string ValidatorKey { get; }
        /// <summary>
        /// Class name of the game script (Client Side)
        /// </summary>
        public override string ClassName { get; }

        #endregion

        #region Fields

        /// <summary>
        /// Element Name (Canvas)(ClientSide)
        /// </summary>
        private readonly string elementName;
        /// <summary>
        /// Field name of the Property Get (Property used to get the result)(ClientSide)
        /// </summary>
        private readonly string fieldGetName;
        /// <summary>
        /// Object used for saving the objects position on the screen (ClientSide)
        /// </summary>
        private readonly string arrayScript;
        /// <summary>
        ///  Array name (ClientSide).
        /// </summary>
        private readonly string arrayName;
        /// <summary>
        /// Field name used for saving the selected item of the array. When the user clicks and moves the object on the screen)(ClientSide)
        /// </summary>
        private readonly string objectName;
        /// <summary>
        /// Function name of the event Leave Out.
        /// </summary>
        private readonly string functioNameLeaveOut;
        /// <summary>
        /// Function name Go Back(ClientSide)
        /// </summary>
        private readonly string functionNameGoBack;
        /// <summary>
        /// Function name To Target(ClientSide)
        /// </summary>
        private readonly string functionNameToTarget;
        /// <summary>
        /// Block Enumerator => CanGoBack | CannotGobackAndToTarget | CanToTarget | IsOnTarget
        ///               CanGoBack = Animation function can go back the object from original position              
        /// CannotGobackAndToTarget = Animation function cannot go back the object from original position and it cannot move the object to target. 
        ///             CanToTarget = Animation function can move the object to target. 
        ///              IsOnTarget = The object is on the target position.
        /// </summary>
        private readonly int[] blockStatus;
        /// <summary>
        /// Objects Total of the Array;
        /// </summary>
        private readonly int objectCount;
        /// <summary>
        /// Result putted on the function Animation(Value expected by the validator).
        /// </summary>
        private readonly string result1;
        /// <summary>
        /// Result putted on the function ToTarget(Value expected by the validator).
        /// </summary>
        private readonly string result2;
        /// <summary>
        /// Objects Colors on the Client Side (Canvas).
        /// </summary>
        private readonly string gameColors;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="getName">Property Name used for getting the result (Client Side)</param>
        /// <param name="publicControlName">Global Object name of the game control (Client Side)</param>
        /// <param name="loadMethodName">Method name used for loading the game (Client side).</param>
        public SwitchGame(string getName, string publicControlName, string loadMethodName) : base(getName, publicControlName, loadMethodName)
        {
            INamesGenerator namesGenerator = GameFactory.Instance.CreateNamesGenerator();

            ClassName = namesGenerator.GetNextName();
            elementName = namesGenerator.GetNextName();
            fieldGetName = namesGenerator.GetNextName();
            arrayName = namesGenerator.GetNextName();
            objectName = namesGenerator.GetNextName();
            functioNameLeaveOut = namesGenerator.GetNextName();
            functionNameGoBack = namesGenerator.GetNextName();
            functionNameToTarget = namesGenerator.GetNextName();

            blockStatus = new int[4];

            Random random = new Random();

            int[] numbers = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };

            int numberIndex = random.Next(numbers.Length);

            for (int i = 0; i < 4; i++)
            {
                blockStatus[i] = numbers[numberIndex];

                numberIndex = (numberIndex + 1) % numbers.Length;
            }

            var arrayColors = new string[]
            {
                "'#DBF2D6','#ffd800','#b6ff00','#00ffff','#b200ff','#b200dd','#000000','#FFFFFF','#FDDB6F','#2D2D2D'"
            };

            gameColors = arrayColors[0];

            ArrayScriptValidator oArrayScriptValidator = CreateArrayScriptAndValidator(namesGenerator.GetNextName(), 6, blockStatus[0], (DirectionSwitchGame)new Random().Next(2));

            arrayScript = $"{arrayName} = [{oArrayScriptValidator.ArrayScript}];";
            objectCount = oArrayScriptValidator.ObjectTotal;

            if (new Random().Next(100) % 2 == 0)
            {
                result2 = oArrayScriptValidator.ResultScript;
            }
            else
            {
                result1 = $"{arrayName}.forEach(item => {{{oArrayScriptValidator.ResultScript}}});";
            }

            ValidatorKey = CreatetValidatorKey(oArrayScriptValidator.Formula);
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Gets game script (Client Side)
        /// </summary>
        /// <returns>Returns the script</returns>
        public override string GetScript()
        {
            List<Func<string>> funcList = new List<Func<string>>{
                CreateFunctionGet
                , CreateFunctionRefresh
                , CreateEventMousedown
                , CreateEventMousemove
                , CreateEventMousemove
                , CreateEventMouseup
                , CreateEventMouseout
                , CreateAnimationFunction
                , CreateInitializeFunction
                , CreateDrawFunction
                , CreateDrawStarFunction
                , CreateFunctionLeaveOut
                , CreateFunctionGoBack
                , CreateFunctionToTarget
            };

            var random = new Random();
            var builder = new StringBuilder();

            while (funcList.Count > 0)
            {
                int funcIndex = random.Next(funcList.Count);

                builder.Append(funcList[funcIndex]());
                funcList.RemoveAt(funcIndex);
            }

            return $@"
                function {ClassName}({elementName}) {{
                    let self = this;
                    let ctx = {elementName}.getContext('2d');
                    let {arrayName} = null;
                    let {fieldGetName} = '';
                    let idF = null;
                    let time = null;
                    let {objectName} = null;

                    self.onChange = null;

                    {builder.ToString()}
                }}
            ";
        }

        #endregion

        #region Private Methods 

        /// <summary>
        /// Creates the function Get used for returning the array object. (Client Side)
        /// </summary>
        /// <returns>Returns the script</returns>
        private string CreateFunctionGet()
        {
            return $@"
                self.{base.GetName} = () => {{
                    return {fieldGetName};
                }};
            ";
        }

        /// <summary>
        /// Creates the function Refresh used for starting the game. (Client Side)
        /// </summary>
        /// <returns>Returns the script</returns>
        private string CreateFunctionRefresh()
        {
            return $@"
                self.refresh = () => {{
                    cancelAnimationFrame(idF);
                    initialize();

                    if (self.onChange != null) {{
                        self.onChange(false);
                    }}
                }};
            ";
        }

        /// <summary>
        /// Creates the event Mousedown used for searching the object. (Client Side)
        /// </summary>
        /// <returns>Returns the script</returns>
        private string CreateEventMousedown()
        {
            return $@"
                {base.PublicControlName}.aevt({elementName}, 0, e => {{
                    e.preventDefault();

                    let pageX = e.touches ? e.touches[0].pageX : e.pageX;
                    let pageY = e.touches ? e.touches[0].pageY : e.pageY;

                    let elOfL = {elementName}.getBoundingClientRect().left + window.scrollX;
                    let elOfT = {elementName}.getBoundingClientRect().top + window.scrollY;

                    let cx = pageX - elOfL;
                    let cy = pageY - elOfT;

                    {objectName} = {arrayName}.find(item => item.s != undefined && item.block === {blockStatus[0]}  && item.s(cx, cy));
                    if ({objectName} != null) {{
                        {objectName}.block = {blockStatus[1]};
                        {objectName}.offX = cx - {objectName}.x;
                        {objectName}.offY = cy - {objectName}.y;
                    }}

                    e.preventDefault();
                }});
            ";
        }

        /// <summary>
        /// Creates the event Mousemove used for moving the object. (Client Side)
        /// </summary>
        /// <returns>Returns the script</returns>
        private string CreateEventMousemove()
        {
            return $@"
                {base.PublicControlName}.aevt({elementName}, 1, e => {{
                    e.preventDefault();

                    let pageX = e.touches ? e.touches[0].pageX : e.pageX;
                    let pageY = e.touches ? e.touches[0].pageY : e.pageY;

                    let elOfL = {elementName}.getBoundingClientRect().left + window.scrollX;
                    let elOfT = {elementName}.getBoundingClientRect().top + window.scrollY;

                    let cx = pageX - elOfL;
                    let cy = pageY - elOfT;

                    if ({objectName} != null) {{
                        {objectName}.x = cx - {objectName}.offX;
                        {objectName}.y = cy - {objectName}.offY;
                    }}
                }});
            ";
        }

        /// <summary>
        /// Creates the event Mouseup used for stopping object movement. (Client Side)
        /// </summary>
        /// <returns>Returns the script</returns>
        private string CreateEventMouseup()
        {
            return $@"
                {base.PublicControlName}.aevt({elementName}, 2, e => {{
                    e.preventDefault();
                    {functioNameLeaveOut}();
                }});
            ";
        }

        /// <summary>
        /// Creates the event Mouseout used for stopping object movement. (Client Side)
        /// </summary>
        /// <returns>Returns the script</returns>
        private string CreateEventMouseout()
        {
            return $@"
                {base.PublicControlName}.aevt({elementName}, 3, e => {{
                    e.preventDefault();
                    {functioNameLeaveOut}();
                }});
            ";
        }

        /// <summary>
        /// Creates the function Animation. (Client Side)
        /// </summary>
        /// <returns>Returns the script</returns>
        private string CreateAnimationFunction()
        {
            return $@"
                function animation() {{
                    let lastTime = new Date();

                    let delta = (lastTime.getTime() - time.getTime()) / 1000;
                    let vel = {base.PublicControlName}.scaleCG(500, {elementName}.width, {elementName}.height);
                    let speed = vel * delta;

                    time = lastTime;

                    {arrayName}.filter(item => item.s != undefined && item.block === {blockStatus[0]}  && (item.x !== item.oX || item.y !== item.oY)).forEach(item => {functionNameGoBack}(item, speed));
                    {arrayName}.filter(item => item.s != undefined && item.block === {blockStatus[2]} ).forEach(item => {functionNameToTarget}(item, speed));                        

                    {elementName}.width = {elementName}.width;
                    draw();

                    if ({arrayName}.filter(item => item.block === {blockStatus[3]} ).length !== {objectCount}) {{
                        idF = requestAnimationFrame(animation);
                    }}
                    else {{
                        {result1}
                        {fieldGetName} = JSON.stringify({arrayName}.filter(item => item.block === {blockStatus[3]}));

                        if (self.onChange != null) {{
                            self.onChange(true);
                        }}
                    }}
                }}
            ";
        }

        /// <summary>
        /// Creates the function Initialize. (Client Side)
        /// </summary>
        /// <returns>Returns the script</returns>
        private string CreateInitializeFunction()
        {
            return $@"
                function initialize() {{
                    {arrayScript}                        

                    time = new Date();
                    animation();
                }}
            ";
        }

        /// <summary>
        /// Creates the function Draw. (Client Side)
        /// </summary>
        /// <returns>Returns the script</returns>
        private string CreateDrawFunction()
        {
            return $@"
                function draw() {{
                    let rcb = [{gameColors}];

                    let par = {arrayName}[{arrayName}.length - 1];

                    let grb = ctx.createLinearGradient(par.x1, par.y1, par.x2, par.y2);

                    let co = [rcb.length - 1, rcb.length - 2];
                    let cI = 0;

                    for (let i = 0; i < 1; i = i + 0.1) {{
                        grb.addColorStop(i, rcb[co[cI]]);
                        let next = i + 0.1;

                        if (next > 1) {{
                            next = 1;
                        }}
                        grb.addColorStop(next, rcb[co[cI]]);

                        cI = (cI + 1) % co.length;
                    }}

                    ctx.lineWidth = par.l;

                    ctx.beginPath();
                    ctx.moveTo(par.x1, par.y1);
                    ctx.lineTo(par.x2, par.y1);
                    ctx.lineTo(par.x2, par.y2);
                    ctx.lineTo(par.x1, par.y2);
                    ctx.lineTo(par.x1, par.y1);
                    ctx.fillStyle = grb;
                    ctx.fill();
                    ctx.strokeStyle = rcb[rcb.length - 1];
                    ctx.stroke();
                    ctx.closePath();

                    ctx.lineWidth = ({elementName}.width * 2 + {elementName}.height * 2) * 0.002;

                    for (let i = 0; i < {arrayName}.length - 1; i++) {{
                        let ch = {arrayName}[i];
                        let cX = ch.x;
                        let cY = ch.y;

                        let gr = ctx.createRadialGradient(ch._x, ch._y, ch.l * 0.1, ch._x, ch._y, ch.l);
                        gr.addColorStop(0, rcb[ch.v]);
                        gr.addColorStop(0.6, rcb[ch.v]);
                        gr.addColorStop(0.6, rcb[rcb.length - 4]);
                        gr.addColorStop(1, rcb[rcb.length - 4]);

                        ctx.beginPath();
                        ctx.arc(ch._x, ch._y, ch.l, 0, 2 * Math.PI);
                        ctx.fillStyle = gr;
                        ctx.fill();
                        ctx.strokeStyle = rcb[rcb.length - 3];
                        ctx.stroke();
                        ctx.closePath();

                        gr = ctx.createRadialGradient(cX, cY, ch.l * 0.1, cX, cY, ch.l);
                        gr.addColorStop(0, rcb[ch.v]);
                        gr.addColorStop(0.4, rcb[ch.v]);
                        gr.addColorStop(0.4, rcb[rcb.length - 4]);
                        gr.addColorStop(1, rcb[rcb.length - 4]);

                        cs(cX, cY, ch.l, ch.l * 0.5, 8, gr, ctx.strokeStyle);
                    }}

                    ctx.lineWidth = 1;
                }}
            ";
        }

        /// <summary>
        /// Creates the function DrawStar (Draws the object on star shape)(Client Side)
        /// </summary>
        /// <returns>Returns the script</returns>
        private string CreateDrawStarFunction()
        {
            return $@"
                function cs(cx, cy, outerRadius, innerRadius, spikes, fcolor, lcolor) {{
                    var rot = Math.PI / 2 * 3;
                    var x = cx;
                    var y = cy;
                    var step = Math.PI / spikes;

                    ctx.save();

                    ctx.beginPath();
                    ctx.moveTo(cx, cy - outerRadius);

                    for (i = 0; i < spikes; i++) {{
                        x = cx + Math.cos(rot) * outerRadius;
                        y = cy + Math.sin(rot) * outerRadius;
                        ctx.lineTo(x, y);
                        rot += step;

                        x = cx + Math.cos(rot) * innerRadius;
                        y = cy + Math.sin(rot) * innerRadius;
                        ctx.lineTo(x, y);
                        rot += step;
                    }}

                    ctx.lineTo(cx, cy - outerRadius);
                    ctx.closePath();
                    ctx.fillStyle = fcolor;
                    ctx.fill();
                    ctx.strokeStyle = lcolor;
                    ctx.stroke();

                    ctx.restore();
                }}
            ";
        }

        /// <summary>
        /// Creates the function Leave Out used for stopping object movement. (Client Side)
        /// </summary>
        /// <returns>Returns the script</returns>
        private string CreateFunctionLeaveOut()
        {
            return $@"
                function {functioNameLeaveOut}() {{
                    if ({objectName} != null) {{
                        if ({base.PublicControlName}.cont({{ x1: {objectName}.x - {objectName}.l, x2: {objectName}.x + {objectName}.l, y1: {objectName}.y - {objectName}.l, y2: {objectName}.y + {objectName}.l }}, {{ x1: {objectName}._x - {objectName}.l, x2: {objectName}._x + {objectName}.l, y1: {objectName}._y - {objectName}.l, y2: {objectName}._y + {objectName}.l }})) {{
                            {objectName}.block = {blockStatus[2]};
                        }}
                        else {{
                            {objectName}.block = {blockStatus[0]};
                        }}

                        {objectName} = null;
                    }}
                }}                
            ";
        }

        /// <summary>
        /// Creates the function GoBack.
        /// </summary>
        /// <remarks>
        /// This function is used for returning the object on  initial position when it wasn't putted in your target position.
        /// </remarks>
        /// <returns>Returns the script</returns>
        private string CreateFunctionGoBack()
        {
            return $@"
                function {functionNameGoBack}(item, speed) {{
                    if (item.x > item.oX) {{
                        item.x -= speed;
                        if (item.x < item.oX) {{ item.x = item.oX; }}
                    }}
                    else if (item.x < item.oX) {{
                        item.x += speed;
                        if (item.x > item.oX) {{ item.x = item.oX; }}
                    }}

                    if (item.y > item.oY) {{
                        item.y -= speed;
                        if (item.y < item.oY) {{ item.y = item.oY; }}
                    }}
                    else if (item.y < item.oY) {{
                        item.y += speed;
                        if (item.y > item.oY) {{ item.y = item.oY; }}
                    }}
                }}                               
            ";
        }

        /// <summary>
        /// Creates the function ToTarget.
        /// </summary>
        /// <remarks>
        /// This function is used for putting the object on target position 
        /// </remarks>
        /// <returns>Returns the script</returns>
        private string CreateFunctionToTarget()
        {
            return $@"
                function {functionNameToTarget}(item, speed) {{
                    let a = '0';

                    if (item.x > item._x) {{
                        item.x -= speed;
                        if (item.x < item._x) {{ item.x = item._x; }}
                    }}
                    else if (item.x < item._x) {{
                        item.x += speed;
                        if (item.x > item._x) {{ item.x = item._x; }}
                    }}
                    else {{
                        a += '1';
                    }}

                    if (item.y > item._y) {{
                        item.y -= speed;
                        if (item.y < item._y) {{ item.y = item._y; }}
                    }}
                    else if (item.y < item._y) {{
                        item.y += speed;
                        if (item.y > item._y) {{ item.y = item._y; }}
                    }}
                    else {{
                        a += '1';
                    }}

                    if (parseInt(a, 2) === 3) {{ item.block = {blockStatus[3]}; {result2} }}
                }}                             
            ";
        }

        /// <summary>
        /// Creates ArrayScript | ResultScript | Formula | ObjectTotal
        /// </summary>
        /// <param name="responseName">Property name used for returning the value expected by the validator</param>
        /// <param name="colorCount">Color count</param>
        /// <param name="blockZeroNumber">Item stage of the array</param>
        /// <param name="direction">Move Direction of the objects.</param>
        /// <returns>Returns ArrayScript | ResultScript | Formula | ObjectTotal.</returns>
        private ArrayScriptValidator CreateArrayScriptAndValidator(string responseName, int colorCount, int blockZeroNumber, DirectionSwitchGame direction)
        {
            ArrayScriptValidator response = new ArrayScriptValidator();

            string line = $"(({elementName}.width * 2 + {elementName}.height * 2) * 0.03)";
            string radius = $"(({elementName}.width * 2 + {elementName}.height * 2) * 0.02)";

            double keyValue = new Random().Next(1, 100);

            int[] colorArray = new int[colorCount];
            for (int i = 0; i < colorArray.Length; i++)
            {
                colorArray[i] = i;
            }

            List<int> colorIndexes = CreateListRandom(colorArray);

            StringBuilder script = new StringBuilder();

            string valueProp;
            string ToValueProp;
            string fromValueProp;

            response.ObjectTotal = new Random().Next(3, 5);

            string[] objectArray = new string[response.ObjectTotal];

            if (direction == DirectionSwitchGame.Vertical)
            {
                string fromY = $"({radius} + ({line} / 2) )";
                string toY = $"{elementName}.height - {fromY}";

                string oneThird = $"({elementName}.width / {objectArray.Length})";

                for (int i = 0; i < objectArray.Length; i++)
                {
                    objectArray[i] = $"({oneThird} * {i}) + {oneThird} / 2";
                }

                List<string> horizontal1 = CreateListRandom(objectArray);
                List<string> horizontal2 = CreateListRandom(objectArray);


                for (int i = 0; i < objectArray.Length; i++)
                {
                    script.Append(CreateItem(horizontal1[i], horizontal2[i], fromY, toY, radius, colorIndexes[i], blockZeroNumber));
                    script.Append(",");
                }

                script.Append($"{{ x1: 0, y1: 0, x2: {elementName}.width, y2: {elementName}.height, l: {line} }}");

                valueProp = "y";
                fromValueProp = "oY";
                ToValueProp = "_y";
            }
            else
            {
                string fromX = $"({radius} + ({line} / 2) )";
                string toX = $"{elementName}.width - {fromX}";

                string oneThird = $"({elementName}.height / {objectArray.Length})";

                for (int i = 0; i < objectArray.Length; i++)
                {
                    objectArray[i] = $"({oneThird} * {i}) + {oneThird} / 2";
                }

                List<string> vertical1 = CreateListRandom(objectArray);
                List<string> vertical2 = CreateListRandom(objectArray);

                for (int i = 0; i < objectArray.Length; i++)
                {
                    script.Append(CreateItem(fromX, toX, vertical1[i], vertical2[i], radius, colorIndexes[i], blockZeroNumber));
                    script.Append(",");
                }

                script.Append($"{{ x1: 0, y1: 0, x2: {elementName}.width, y2: {elementName}.height, l: {line} }}");

                valueProp = "x";
                fromValueProp = "oX";
                ToValueProp = "_x";
            }

            response.ArrayScript = script.ToString();
            response.ResultScript = $"item.{responseName} = {keyValue}";
            response.Formula = new SwitchFormula { Value = valueProp, FromValue = fromValueProp, ToValue = ToValueProp, KeyValue = keyValue, ResponseName = responseName, Operation = OperationType.Subtraction, ValidatorClassName = typeof(SwitchValidator).FullName };

            return response;
        }

        /// <summary>
        /// Creates a item of the array used for saving the objects position on the screen (Client Side).
        /// </summary>
        /// <param name="fromX">Property name of the original object position [Horizontal]</param>
        /// <param name="toX">Property name of the target object position [Horizontal]</param>
        /// <param name="fromY">Property name of the original object position [Vertical]</param>
        /// <param name="toY">Property name of the target object position [Vertical]</param>
        /// <param name="radius">Radius of the object</param>
        /// <param name="colorIndex">Color of the object</param>
        /// <param name="blockZeroNumber">Stage of the object</param>
        /// <returns>Returns script</returns>
        private string CreateItem(string fromX, string toX, string fromY, string toY, string radius, int colorIndex, int blockZeroNumber)
        {
            return $"{{ x: {fromX}, y: {fromY}, oX: {fromX}, oY: {fromY}, l: {radius}, v: {colorIndex}, _x: {toX}, _y: {toY}, s: {PublicControlName}.sear, block: {blockZeroNumber} }}";
        }

        /// <summary>
        /// Method used for creating a list random.
        /// </summary>
        /// <typeparam name="T">The type of elements in the list</typeparam>
        /// <param name="array">Array of the element type to create the list random</param>
        /// <returns>Returns the list random</returns>
        private List<T> CreateListRandom<T>(T[] array)
        {
            List<T> collection = new List<T>();
            List<T> list = array.ToList();

            Random random = new Random();

            while (list.Count > 0)
            {
                int index = random.Next(list.Count);

                collection.Add(list[index]);

                list.RemoveAt(index);
            }

            return collection;
        }

        #endregion

        #region classes

        /// <summary>
        /// Model to create the array script and the Validator. 
        /// </summary>
        private class ArrayScriptValidator
        {
            /// <summary>
            /// Object used for saving the objects position on the screen (ClientSide)
            /// </summary>
            public string ArrayScript { get; set; }
            /// <summary>
            /// Value expected by the validator
            /// </summary>
            public string ResultScript { get; set; }
            /// <summary>
            /// Formula class for the validator
            /// </summary>
            public SwitchFormula Formula { get; set; }
            /// <summary>
            /// Objects Total of the Array;
            /// </summary>
            public int ObjectTotal { get; set; }
        }

        #endregion
    }
}