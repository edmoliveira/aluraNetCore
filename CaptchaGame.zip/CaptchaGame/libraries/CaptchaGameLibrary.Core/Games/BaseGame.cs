﻿using CaptchaGameLibrary.Formulas;
using CaptchaGameLibrary.Interfaces;

namespace CaptchaGameLibrary.Games
{
    /// <summary>
    /// Base class of the games class.
    /// </summary>
    internal abstract class BaseGame : IGameScript
    {
        #region Properties

        #region public

        /// <summary>
        /// Class name of the game script (Client Side)
        /// </summary>
        public abstract string ClassName { get; }
        /// <summary>
        /// Key used for validation.
        /// </summary>
        public abstract string ValidatorKey { get; }
        /// <summary>
        /// Global Object name of the game control (Client Side)
        /// </summary>
        public string PublicControlName { get; }
        /// <summary>
        /// Method name used for loading the game (Client side)
        /// </summary>
        public string LoadMethodName { get; }

        #endregion

        #region protected

        /// <summary>
        /// Property name used for getting the result (Client Side)
        /// </summary>
        public string GetName { get; }

        #endregion

        #endregion

        #region Fields

        /// <summary>
        /// Class used for encrypting the validator key
        /// </summary>
        private readonly ICryptography cryptography;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="getName">Property Name used for getting the result (Client Side)</param>
        /// <param name="publicControlName">Global Object name of the game control (Client Side)</param>
        /// <param name="loadMethodName">Method name used for loading the game (Client side)</param>
        public BaseGame(string getName, string publicControlName, string loadMethodName)
        {
            GetName = getName;
            PublicControlName = publicControlName;
            LoadMethodName = loadMethodName;

            cryptography = GameFactory.Instance.CreateCryptography();
        }

        #endregion

        #region Methods

        #region public

        /// <summary>
        /// Gets game script (Client Side)
        /// </summary>
        /// <returns>Returns the script</returns>
        public abstract string GetScript();

        #endregion

        #region protected 

        /// <summary>
        /// Create the encrypted key of the validator.
        /// </summary>
        /// <param name="formula">Formula object for the validator</param>
        /// <returns>Returns the encrypted key of the validator </returns>
        protected string CreatetValidatorKey(BaseFormula formula)
        {
            return cryptography.CreatetValidatorKey(formula);
        }

        #endregion

        #endregion
    }
}