﻿namespace CaptchaGameLibrary.Formulas
{
    /// <summary>
    /// Formula class for the validator (Game Switch)
    /// </summary>
    internal sealed class SwitchFormula : BaseFormula
    {
        #region Properties

        /// <summary>
        /// Property name of the object position.
        /// </summary>
        public string Value { get; set; }
        /// <summary>
        /// Property name of the starting position of the object.
        /// </summary>
        public string FromValue { get; set; }
        /// <summary>
        /// Property name of the target position of the object.
        /// </summary>
        public string ToValue { get; set; }
        /// <summary>
        /// Random value for math operation
        /// </summary>
        public double KeyValue { get; set; }
        /// <summary>
        /// Random value of the client side for math operation
        /// </summary>
        public string ResponseName { get; set; }
        /// <summary>
        /// Types of Operation
        /// </summary>
        public OperationType Operation { get; set; }

        #endregion
    }
}
