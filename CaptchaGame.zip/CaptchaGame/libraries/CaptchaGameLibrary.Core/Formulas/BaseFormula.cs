﻿namespace CaptchaGameLibrary.Formulas
{
    /// <summary>
    /// Base class of the formulas class to the validator 
    /// </summary>
    internal class BaseFormula
    {
        #region Properties

        /// <summary>
        /// Name of validator class.
        /// </summary>
        public string ValidatorClassName { get; set; }

        #endregion
    }
}
