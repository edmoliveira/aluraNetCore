﻿using CaptchaGameLibrary.Extensions;
using CaptchaGameLibrary.Interfaces;
using System;
using System.Collections.Generic;

namespace CaptchaGameLibrary
{
    /// <summary>
    /// Random name generator
    /// </summary>
    internal sealed class NamesGenerator : INamesGenerator
    {
        #region Fields

        /// <summary>
        /// Names list
        /// </summary>
        private readonly List<string> nameCollection;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructor
        /// </summary>
        public NamesGenerator()
        {
            char[] alphabetNumbers = "abcdefghijklmnopqrstuvwxyz0123456789".ToCharArray();
            nameCollection = new List<string>();

            for (var row = 0; row < alphabetNumbers.Length; row++)
            {
                for (var col = 0; col < alphabetNumbers.Length; col++)
                {
                    nameCollection.Add($"$cp_{alphabetNumbers[row]}{alphabetNumbers[col]}");
                }
            }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Gets the next name.
        /// </summary>
        /// <returns>Name</returns>
        public string GetNextName()
        {
            Random random = new Random();

            int index = random.Next(nameCollection.Count);

            return nameCollection.PushAt(index);
        }

        #endregion
    }
}
