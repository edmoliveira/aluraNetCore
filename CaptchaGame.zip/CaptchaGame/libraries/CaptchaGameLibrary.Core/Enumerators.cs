﻿namespace CaptchaGameLibrary
{
    #region Enumerators

    /// <summary>
    /// Numbers of Game
    /// </summary>
    internal enum GameNumber
    {
        Switch = 1
    }

    /// <summary>
    /// Types of Operation
    /// </summary>
    internal enum OperationType
    {
        Addition = 0,
        Subtraction = 1,
        Multiplication = 2,
        Division = 3,
    }

    /// <summary>
    /// Direction of the object
    /// </summary>
    internal enum DirectionSwitchGame
    {
        Horizontal = 0
        , Vertical = 1
    }

    #endregion
}
