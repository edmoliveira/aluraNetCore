﻿using CaptchaGameLibrary.Formulas;
using CaptchaGameLibrary.Interfaces;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace CaptchaGameLibrary
{
    /// <summary>
    /// Provides methods for creates, encrypts and validates the key.
    /// </summary>
    internal sealed class Cryptography : ICryptography, IValidation
    {
        #region constants

        /// <summary>
        /// The password used to derive the key
        /// </summary>
        private const string passwordHash = "P@@Sw0rd";
        /// <summary>
        /// The key salt used to derive the key.
        /// </summary>
        private const string saltKey = "S@LT&KEY";
        /// <summary>
        /// The IV to be used for the symmetric algorithm.
        /// </summary>
        private const string viKey = "@1B2c3D4e5F6g7H8";

        #endregion

        #region Public Methods

        /// <summary>
        /// Creates the validator key, serializes and encrypts the object formula.
        /// </summary>
        /// <param name="formula">Object formula for the validator</param>
        /// <returns>Object formula serialized and encrypted</returns>
        public string CreatetValidatorKey(BaseFormula formula)
        {
            return Encrypt(JsonConvert.SerializeObject(formula));
        }

        /// <summary>
        /// Method used for validates the validator key
        /// </summary>
        /// <param name="validatorKey">Encrypted key of the validator</param>
        /// <param name="gameResponse">Response of the client side</param>
        /// <returns>Returns true if validator key is valid</returns>
        public bool Validate(string validatorKey, string gameResponse)
        {
            try
            {
                string formulaJson = Decrypt(validatorKey);

                var validator = GameFactory.Instance.CreateValidator(JsonConvert.DeserializeObject<BaseFormula>(formulaJson));

                return validator.Validate(formulaJson, gameResponse);
            }
            catch (JsonException)
            {
                throw new CaptchaGameException("Validator Key isn't valid");
            }
            catch (Exception)
            {
                throw new CaptchaGameException("Game Response isn't valid");
            }
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Encrypts the text
        /// </summary>
        /// <param name="text">Text for be encrypted</param>
        /// <returns>Text encrypted</returns>
        private string Encrypt(string text)
        {
            byte[] plainTextBytes = Encoding.UTF8.GetBytes(text);

            byte[] keyBytes = new Rfc2898DeriveBytes(passwordHash, Encoding.ASCII.GetBytes(saltKey)).GetBytes(256 / 8);
            var symmetricKey = new RijndaelManaged() { Mode = CipherMode.CBC, Padding = PaddingMode.Zeros };
            var encryptor = symmetricKey.CreateEncryptor(keyBytes, Encoding.ASCII.GetBytes(viKey));

            byte[] cipherTextBytes;

            using (var memoryStream = new MemoryStream())
            {
                using (var cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
                {
                    cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
                    cryptoStream.FlushFinalBlock();
                    cipherTextBytes = memoryStream.ToArray();
                    cryptoStream.Close();
                }
                memoryStream.Close();
            }
            return Convert.ToBase64String(cipherTextBytes);
        }

        /// <summary>
        /// Decrypts the text
        /// </summary>
        /// <param name="encryptedText">Text for be decrypted</param>
        /// <returns>Text decrypted</returns>
        private string Decrypt(string encryptedText)
        {
            byte[] cipherTextBytes = Convert.FromBase64String(encryptedText);
            byte[] keyBytes = new Rfc2898DeriveBytes(passwordHash, Encoding.ASCII.GetBytes(saltKey)).GetBytes(256 / 8);
            var symmetricKey = new RijndaelManaged() { Mode = CipherMode.CBC, Padding = PaddingMode.None };

            var decryptor = symmetricKey.CreateDecryptor(keyBytes, Encoding.ASCII.GetBytes(viKey));
            var memoryStream = new MemoryStream(cipherTextBytes);
            var cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);
            byte[] plainTextBytes = new byte[cipherTextBytes.Length];

            int decryptedByteCount = cryptoStream.Read(plainTextBytes, 0, plainTextBytes.Length);
            memoryStream.Close();
            cryptoStream.Close();
            return Encoding.UTF8.GetString(plainTextBytes, 0, decryptedByteCount).TrimEnd("\0".ToCharArray());
        }

        #endregion
    }
}
