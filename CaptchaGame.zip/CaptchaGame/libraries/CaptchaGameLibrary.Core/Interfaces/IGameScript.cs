﻿namespace CaptchaGameLibrary.Interfaces
{
    /// <summary>
    /// Defines methods to create the scripts (Client Side).
    /// </summary>
    internal interface IGameScript : IGame
    {
        #region Properties

        /// <summary>
        /// Class name of the script Javascript (Client Side)
        /// </summary>
        string ClassName { get; }
        /// <summary>
        /// Class name of the game script (Client Side)
        /// </summary>
        string PublicControlName { get; }
        /// <summary>
        /// Property name used to get the result (Client Side)
        /// </summary>
        string LoadMethodName { get; }

        #endregion

        #region Methods

        /// <summary>
        /// Gets game script (Client Side)
        /// </summary>
        /// <returns>Returns the script</returns>
        string GetScript();

        #endregion
    }
}