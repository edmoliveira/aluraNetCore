﻿namespace CaptchaGameLibrary.Interfaces
{
    /// <summary>
    /// Defines method to generate names randomly
    /// </summary>
    internal interface INamesGenerator
    {
        #region Properties

        /// <summary>
        /// Gets the next name.
        /// </summary>
        /// <returns>Name</returns>
        string GetNextName();

        #endregion
    }
}
