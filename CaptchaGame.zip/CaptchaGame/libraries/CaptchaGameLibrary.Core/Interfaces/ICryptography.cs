﻿using CaptchaGameLibrary.Formulas;

namespace CaptchaGameLibrary.Interfaces
{
    /// <summary>
    /// Provides methods for creates and encrypts the validator key.
    /// </summary>
    internal interface ICryptography
    {
        #region Methods

        /// <summary>
        /// Creates the validator key, serializes and encrypts the object formula.
        /// </summary>
        /// <param name="formula">Object formula for the validator</param>
        /// <returns>Object formula serialized and encrypted</returns>
        string CreatetValidatorKey(BaseFormula formula);

        #endregion
    }
}
