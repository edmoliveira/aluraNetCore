﻿namespace CaptchaGameLibrary.Interfaces
{
    /// <summary>
    /// Define methos to validate the game result.
    /// </summary>
    internal interface IValidator
    {
        #region Methods

        /// <summary>
        /// Validates the game result with the validator key. 
        /// </summary>
        /// <param name="formulaJson">Object Formula in JSON format.</param>
        /// <param name="array">Object used for saving the objects position on the screen (ClientSide)</param>
        /// <returns>Returns true if game result to pass on the tests of the objet formula</returns>
        bool Validate(string formulaJson, string array);

        #endregion
    }
}
