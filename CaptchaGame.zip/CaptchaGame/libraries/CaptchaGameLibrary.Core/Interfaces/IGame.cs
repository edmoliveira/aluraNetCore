﻿namespace CaptchaGameLibrary.Interfaces
{
    /// <summary>
    /// Defines method to get the key used for validation.
    /// </summary>
    public interface IGame
    {
        #region Properties

        /// <summary>
        ///  Key used for validation.
        /// </summary>
        string ValidatorKey { get; }

        #endregion
    }
}
