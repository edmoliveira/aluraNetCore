﻿using CaptchaGameLibrary.Interfaces;
using CaptchaGameLibrary.Models;
using System.Text;
using System.Text.RegularExpressions;

namespace CaptchaGameLibrary.Scripts
{
    /// <summary>
    /// Creates the scripts to load and control the game of the client side.
    /// </summary>
    internal class ScriptManager : IScriptManager
    {
        #region Fields

        /// <summary>
        /// Property Name used for getting the result (Client Side)
        /// </summary>
        private readonly string getName;
        /// <summary>
        /// Global Object name of the game control (Client Side)
        /// </summary>
        private readonly string publicControlName;
        /// <summary>
        /// Method name used for loading the game (Client side)
        /// </summary>
        private readonly string loadMethodName;
        /// <summary>
        /// Object name of the game control (Client Side)
        /// </summary>
        private readonly string controlName;
        /// <summary>
        /// Componet name used for saving the result of the game (Client side)
        /// </summary>
        private readonly string inputName;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="getName">Property Name used for getting the result (Client Side)</param>
        /// <param name="publicControlName">Global Object name of the game control (Client Side)</param>
        /// <param name="loadMethodName">Method name used for loading the game (Client side).</param>
        public ScriptManager(string getName, string publicControlName, string loadMethodName)
        {
            INamesGenerator namesGenerator = GameFactory.Instance.CreateNamesGenerator();

            this.getName = getName;
            this.publicControlName = publicControlName;
            this.loadMethodName = loadMethodName;

            controlName = namesGenerator.GetNextName();
            inputName = namesGenerator.GetNextName();
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Gets the main script, this script to load the game. (Client Side)
        /// </summary>
        /// <returns>Returns the script</returns>
        public string GetMainScript()
        {
            var script = @"
                <script>
                    let " + controlName + @" = {
                        " + loadMethodName + @": (a, b, c, d, x, z, fn) => {
                            let f = document.querySelectorAll('[' + a + '=""' + b + '""]')[0];
                            let g = document.querySelectorAll('[' + c + '=""' + d + '""]')[0];
                            let " + inputName + @" = document.querySelectorAll('[' + x + '=""' + z + '""]')[0];

                            let m = document.createElement('CANVAS');

                            m.style.width = g.offsetWidth + 'px';
                            m.style.height = g.offsetHeight + 'px';
                            m.width = g.offsetWidth;
                            m.height = g.offsetHeight;

                            g.appendChild(m);

                            let gg = fn(m);

                            f.cptRefresh = () => { gg.refresh(); };

                            gg.onChange = (ok) => { 
                                if(" + inputName + @".value !== undefined) {

                                    " + inputName + @".value = gg." + getName + @"();
                                }
                                else{
                                    " + inputName + @".innerHTML = gg." + getName + @"();
                                }

                                if(f.cptChange != null){ f.cptChange(ok); }; 
                            };

                            gg.refresh();
                        }
                        , aevt: function (el, eI, fn) {
                            let events = [
                                { m: 'touchstart', b: 'mousedown' }
                                , { m: 'touchmove', b: 'mousemove' }
                                , { m: 'touchend', b: 'mouseup' }
                                , { m: 'touchcancel', b: 'mouseout' }
                            ];

                            let evt1 = events[eI].m;
                            let evt2 = events[eI].b;

                            if (el.addEventListener) {
                                if (evt1 in document.documentElement === true || 'on' + evt1 in document.documentElement === true) {
                                    el.addEventListener(evt1, fn, false);
                                }
                                else {
                                    el.addEventListener(evt2, fn, false);
                                }
                            }
                            else {
                                evt1 = 'on' + evt1;
                                evt2 = 'on' + evt2;

                                if (evt1 in document.documentElement === true) {
                                    el.attachEvent(evt1, fn);
                                }
                                else {
                                    el.attachEvent(evt2, fn);
                                }
                            }
                        }
                        , scaleCG: function (value, elW, elH) {
                            let widthOrig = 640;
                            let heightOrig = 360;

                            let areaOrig = (widthOrig * 2) + (heightOrig * 2);
                            let areaCurrent = (elW * 2) + (elW * 2);

                            return (areaCurrent * value) / areaOrig;
                        }
                        , sear: function (mx, my) {
                            var x1 = this.x - this.l;
                            var y1 = this.y - this.l;
                            var x2 = this.x + this.l;
                            var y2 = this.y + this.l;

                            return (mx >= x1 && mx <= x2 && my >= y1 && my <= y2);
                        }
                        , cont: function (point1, point2) {
                            return ((point1.x1 >= point2.x1 && point1.x1 <= point2.x2) || (point1.x2 >= point2.x1 && point1.x2 <= point2.x2)) &&
                                   ((point1.y1 >= point2.y1 && point1.y1 <= point2.y2) || (point1.y2 >= point2.y1 && point1.y2 <= point2.y2));
                        }
                    };

                    Object.defineProperty(window, '" + publicControlName + @"', {
                        get() { return " + controlName + @"; }
                    });
                </script>
            ";

            return Regex.Replace(script, @"\r|\n|\s{2,}", "");
        }

        /// <summary>
        /// Gets the game script, this script to control the game. (Client Side)
        /// </summary>
        /// <param name="model">Model to create the game script of the client side</param>
        /// <returns>Returns the script</returns>
        public string GetGameScript(CaptchaGameModel model)
        {
            var buttonLink = model.ButtonLink.Split('|');
            var contentLink = model.ContentLink.Split('|');
            var valueLink = model.ValueLink.Split('|');
            var baseGame = (IGameScript)model.Game;

            StringBuilder script = new StringBuilder();

            script.Append(baseGame.GetScript());
            script.Append("((el) => {");
            script.Append("    let onLoad = el.addEventListener ? (fn) => el.addEventListener('load', fn, false) : (fn) => el.attachEvent('onload', fn);");
            script.Append("onLoad(() => { " + baseGame.PublicControlName + "." + baseGame.LoadMethodName + $"('{buttonLink[0]}', '{buttonLink[1]}', '{contentLink[0]}', '{contentLink[1]}', '{valueLink[0]}', '{valueLink[1]}', (el) => {{ return new {baseGame.ClassName}(el); }}); }})");
            script.Append("})(window);");

            return Regex.Replace(script.ToString(), @"\r|\n|\s{2,}", "");
        }

        #endregion
    }
}
