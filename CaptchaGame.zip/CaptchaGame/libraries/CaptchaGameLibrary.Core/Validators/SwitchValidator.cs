﻿using CaptchaGameLibrary.Formulas;
using CaptchaGameLibrary.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace CaptchaGameLibrary.Validators
{
    /// <summary>
    /// Class used for validating of the game result.
    /// </summary>
    internal sealed class SwitchValidator : IValidator
    {
        #region Constructors

        public SwitchValidator() { }

        #endregion

        #region Methods

        #region public

        /// <summary>
        /// Validates the game result with the validator key. 
        /// </summary>
        /// <param name="formulaJson">Object Formula in JSON format.</param>
        /// <param name="array">Object used for saving the objects position on the screen (ClientSide)</param>
        /// <returns>Returns true if game result to pass on the tests of the objet formula</returns>
        public bool Validate(string formulaJson, string array)
        {
            bool result = true;

            var mathFunction = new Dictionary<OperationType, Func<double, double, double, double, bool>> {
                {  OperationType.Addition, (value, fromValue, keyValue, userKeyValue) =>{ return ((value - fromValue) + keyValue) == ((value - fromValue) + userKeyValue); } }
                , {  OperationType.Subtraction, (value, fromValue, keyValue, userKeyValue) =>{ return ((value - fromValue) - keyValue) == ((value - fromValue) - userKeyValue); } }
                , {  OperationType.Multiplication, (value, fromValue, keyValue, userKeyValue) =>{ return ((value - fromValue) * keyValue) == ((value - fromValue) * userKeyValue); } }
                , {  OperationType.Division, (value, fromValue, keyValue, userKeyValue) =>{ return ((value - fromValue) / keyValue) == ((value - fromValue) / userKeyValue); } }
            };

            SwitchFormula formula = JsonConvert.DeserializeObject<SwitchFormula>(formulaJson);

            dynamic objectList = JsonConvert.DeserializeObject(array);

            for (int index = 0; index < objectList.Count; index++)
            {
                var item = objectList[index];

                object valueD = item[formula.Value].Value;
                object fromValueD = item[formula.FromValue].Value;
                object toValueD = item[formula.ToValue].Value;
                object userKeyValueD = item[formula.ResponseName].Value;

                double.TryParse(valueD?.ToString(), out double value);
                double.TryParse(fromValueD?.ToString(), out double fromValue);
                double.TryParse(toValueD?.ToString(), out double toValue);
                int.TryParse(userKeyValueD?.ToString(), out int userKeyValue);

                if (!value.Equals(toValue) ||
                    !mathFunction[formula.Operation](value, fromValue, formula.KeyValue, userKeyValue))
                {
                    result = false;
                    break;
                }
            }

            return result;
        }

        #endregion

        #endregion
    }
}
