﻿using CaptchaGameLibrary.Formulas;
using CaptchaGameLibrary.Games;
using CaptchaGameLibrary.Interfaces;
using CaptchaGameLibrary.Scripts;
using System;

namespace CaptchaGameLibrary
{
    /// <summary>
    /// Factory used for creating scripts, keys for validators and validator.
    /// </summary>
    public sealed class GameFactory
    {
        #region Properties

        /// <summary>
        /// Lazy initialization of the GameFactory instance.
        /// </summary>
        private static readonly Lazy<GameFactory> lazy = new Lazy<GameFactory>(() => new GameFactory());

        /// <summary>
        /// Singleton
        /// </summary>
        public static GameFactory Instance => lazy.Value;

        #endregion

        #region Fields

        /// <summary>
        /// Object used for generating names randomly
        /// </summary>
        private readonly INamesGenerator namesGenerator;
        /// <summary>
        /// Property Name used for getting the result (Client Side)
        /// </summary>
        private readonly string getName;
        /// <summary>
        /// Global Object name of the game control (Client Side)
        /// </summary>
        private readonly string publicControlName;
        /// <summary>
        /// Method name used for loading the game (Client side)
        /// </summary>
        private readonly string loadMethodName;

        #endregion

        #region Constructors

        /// <summary>
        /// private constructor
        /// </summary>
        private GameFactory()
        {
            namesGenerator = new NamesGenerator();

            getName = namesGenerator.GetNextName();
            publicControlName = namesGenerator.GetNextName();
            loadMethodName = namesGenerator.GetNextName();
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Creates object to get the key used for validation.
        /// </summary>
        /// <returns>Returns interface IGame</returns>
        public IGame CreateGame()
        {
            return new SwitchGame(getName, publicControlName, loadMethodName);
        }

        /// <summary>
        /// Create object used for creating scripts
        /// </summary>
        /// <returns>Returns interface IScriptManager</returns>
        public IScriptManager CreateScriptManager()
        {
            return new ScriptManager(getName, publicControlName, loadMethodName);
        }

        /// <summary>
        ///  Create object for validating the key.
        /// </summary>
        /// <returns>Returns interface IValidation</returns>
        public IValidation CreateValidation()
        {
            return new Cryptography();
        }

        #endregion

        #region Internal Methods

        /// <summary>
        /// Create an instance of the Cryptography.
        /// </summary>
        /// <returns>Returns interface IGame</returns>
        internal ICryptography CreateCryptography()
        {
            return new Cryptography();
        }

        /// <summary>
        /// Create an instance of the NamesGenerator.
        /// </summary>
        /// <returns>Returns interface IGame</returns>
        internal INamesGenerator CreateNamesGenerator()
        {
            return namesGenerator;
        }

        /// <summary>
        /// Create an instance with the class name (ValidatorClassName)
        /// </summary>
        /// <param name="formula">Base class of the formulas class to the validator </param>
        /// <returns>Returns interface IValidator</returns>
        internal IValidator CreateValidator(BaseFormula formula)
        {
            Type oType = Type.GetType(formula.ValidatorClassName);

            return (IValidator)Activator.CreateInstance(oType);
        }

        #endregion
    }
}
