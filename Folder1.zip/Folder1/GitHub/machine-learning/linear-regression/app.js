const express = require("express");
const server = express();

server.set('view engine', 'ejs');

const parseFloatDigit = (number, digit) => parseFloat(number.toFixed(digit));

const calculateW1 = (elCount, Σx1, Σy, Σx1MultY, Σx1Squared) => (elCount * Σx1MultY - Σx1 * Σy) / (elCount * Σx1Squared - Math.pow(Σx1, 2)) ;
const calculateB = (elCount, Σx1, Σy, w1) => (1 / elCount) * (Σy - w1 * Σx1);
const calculateY = (w1, b, x1) => b + w1 * x1;
const calculateErrorSquare = (y, yPrediction) => Math.pow(y - yPrediction, 2);
const calculateArrayErrorSquare = (vectX, vectY, w1, b) => vectY.map((y, index) => calculateErrorSquare(y, calculateY(w1, b, vectX[index])));

//let arrayY = [2,3,5,4,6];
//let arrayX1 = [0,1,2,3,4]; => 10

//let arrayY = [12,19,29,37,45];
//let arrayX1 = [2005,2006,2007,2008,2009];

//let arrayY = [2.5,4,3.5,3,4.5,4,5.5,7,6.5];
//let arrayX1 = [1,2,3,4,5,6,7,8,9]; // => 10

//let arrayY = [2.5,3,3.5,6,4.5,5,5.5,4,6.5];
//let arrayX1 = [1,2,3,4,5,6,7,8,9]; // => 10

let arrayY = [41,45,49,47,44];
let arrayX1 = [43,44,45,46, 47]; // => 47

let x1MultY;
let x1Squared;

let Σx1;
let Σy;
let Σx1MultY;
let Σx1Squared;

let w1;
let b; 

function calculate() {
    x1MultY = arrayX1.map((item, index) => item * arrayY[index]);
    x1Squared = arrayX1.map((item, index) => Math.pow(item, 2));
    
    Σx1 =  arrayX1.reduce((sum, current) => sum + current);
    Σy =  arrayY.reduce((sum, current) => sum + current);
    Σx1MultY =  x1MultY.reduce((sum, current) => sum + current);
    Σx1Squared =  x1Squared.reduce((sum, current) => sum + current);

    const elCount = arrayX1.length;

    w1 = calculateW1(elCount, Σx1, Σy, Σx1MultY, Σx1Squared);
    b = calculateB(elCount, Σx1, Σy, w1);

    console.log(w1);
    console.log(b);
}

server.get('/', (req, resp) =>{
    calculate();
    
    const newX = 48;
    const newY = calculateY(w1, b, newX);

    arrayX1.push(newX);
    arrayY.push(newY);

    calculate();

    const mse = calculateArrayErrorSquare(arrayX1, arrayY, w1, b).reduce((sum, current) => sum + current) / arrayX1.length;

    resp.render('index', {newY: newY, mse: mse });
});

server.listen(4242, () => {
    console.log("Express Server is running...");
    console.log("http://localhost:4242/");
});
//https://www.analyzemath.com/statistics/linear_regression.html
//y = b + w1x1 
/*
 y = is the predicted label (a desired output).
 b = is the bias (the y-intercept), sometimes referred to as .
 w1 = is the weight of feature 1. Weight is the same concept as the "slope"  in the traditional equation of a line.
 x1 = is a feature (a known input).
*/