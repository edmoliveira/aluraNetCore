$sui.createPackage('personPackage', pkg => {
    pkg.person.lastName = 'Oliveira';
    pkg.person.firstName = 'Edson';

    pkg.person.contacts.pushRange(source => {
        let list = [];

        for (let index = 0; index < 10; index++) {
            let item = source.create();

            item.code = index;
            item.text = "Contact " + index;

            let comp = ['gmail.com', 'hotmail.com', 'yahoo.com'];

            for (let indexE = 0; indexE < comp.length; indexE++) {
                item.emails.push(model => {
                    model.address = item.text.replace(/ /g, '_') + "@" + comp[indexE];
                });
            }

            list.push(item);
        }

        return list;
    });


    pkg.person.contacts.unshift(model => {
        model.code = 100;
        model.text = "Contact " + 100;

        let comp = ['gmail.com', 'hotmail.com', 'yahoo.com'];

        for (let indexE = 0; indexE < comp.length; indexE++) {
            model.emails.push(emailModel => {
                emailModel.address = model.text.replace(/ /g, '_') + "@" + comp[indexE];
            });
        }
    });

    pkg.person.contacts.sort((a, b) => a.code - b.code);

    pkg.person.contacts.unshift(model => {
        model.code = 200;
        model.text = "Contact " + 200;

        let comp = ['gmail.com', 'hotmail.com', 'yahoo.com'];

        for (let indexE = 0; indexE < comp.length; indexE++) {
            model.emails.push(emailModel => {
                emailModel.address = model.text.replace(/ /g, '_') + "@" + comp[indexE];
            });
        }
    });

    pkg.person.contacts.pop();

    pkg.person.contacts.splice(0, 1, model => {
        model.code = 10;
        model.text = "Contact " + 10;

        let comp = ['gmail.com', 'hotmail.com', 'yahoo.com'];

        for (let indexE = 0; indexE < comp.length; indexE++) {
            model.emails.push(emailModel => {
                emailModel.address = model.text.replace(/ /g, '_') + "@" + comp[indexE];
            });
        }
    });

    pkg.person.contacts.sort((a, b) => a.code - b.code);
});