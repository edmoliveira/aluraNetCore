$sui.extend({
    phoneJs: function ($root) {
        'use strict';

        let _pkg = null;

		class PhoneJs {
            constructor() {
                
			}

			get value() {
                return _pkg.userd.value;
			}

			set value(v) {
                _pkg.userd.value = v;
            }

            on(evt, fn) {
                let el = _pkg.userd.$.element;

                if (el.addEventListener) {
                    el.addEventListener(evt, fn, false);
                }
                else {
                    el.attachEvent("on" + evt, fn);
                }
            }

            trigger(evt) {
                let el = _pkg.userd.$.element;

                el.dispatchEvent(new Event(evt));
            }

            css(propName) {
                let el = _pkg.userd.$.element;

                return el.style[propName];
            }

            css(propName, value) {
                let el = _pkg.userd.$.element;

                el.style[propName] = value;
            }

            getValue() {
                return this.value;
            }

            setValue(v) {
                this.value = v;
            }
		}

        _pkg = $root.getPackage();       

		return new PhoneJs();
	}
});