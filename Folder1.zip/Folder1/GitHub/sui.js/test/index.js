$sui.createPackage('mainPackage', pkg => {
    let headText = pkg.head;

    //pkg.childrenList.phone.value = "11352999111";

    pkg.childrenList.phone.$.css("border", "1px solid #9C27B0");

    //let iconPhone = document.createElement('img');
    //iconPhone.src = 'images/phone.png';
    //iconPhone.style.width = '16px';
    //iconPhone.style.height = '16px';

    //pkg.grid.caption.captionDiv.html = iconPhone;

    let cptImg = pkg.grid.caption.captionDiv.captionImg;

    cptImg.src = 'images/phone.png';
    cptImg.$.css('width', '16px');
    cptImg.$.css('height', '16px');

    let contentHtml = pkg.grid.caption.captionDiv.html;

    //pkg.grid.caption.value = "Table";
    //pkg.grid.caption.show();

    //pkg.grid.footer.show();

    pkg.grid.head.getTempl(0).push(model => {
        let now = new Date();

        model.get(0).date.html = now.getDate() + '/' + (now.getMonth() + 1) + '/' + now.getFullYear();
    });

    pkg.grid.head.getTempl(1).push(model => {
        model.get(0).text = "Id";
        model.get(1).text = "Name";
        model.get(2).text = "Value";
        model.get(3).text = "Edit";
    });

    pkg.grid.foot.push(model => {
        model.get('total').text = 'R$ 0,00';
    });

    pkg.grid.bodies.get(0, body => {
        let templItem = body.getTempl("itemTemp");
        let templTotal = body.getTempl("subtotalTemp");

        let id = 1;

        for (let indexT = 0; indexT < 2; indexT++) {
            let subTotal = 0;

            for (let indexI = 0; indexI < 5; indexI++) {
                let value = 20 * id;

                templItem.push(model => {
                    model.get(0).text = id;
                    model.get(1).text = "Name " + id;
                    model.get(2).text = "R$ " + value + ",00";

                    
                });

                id++;

                subTotal += value;
            }

            templTotal.push(model => {
                model.get('subtotal').text = "R$ " + subTotal + ",00";
            });
        }
    });

    pkg.grid.bodies.get("body1").push(model => {
        model.get(0).text = "0101";
        //model.get(1).text = "New York";
    });

    console.log(pkg.$.name);
    console.log(pkg.$.element);

    pkg.radio.checked = true;

    let coll = pkg.childrenList.level_1.level_1_2.level_1_2_1;

    for (var index = 1; index <= 11; index++) {
        coll.push(item => {
            item.userd.value = index;
            item.level_1_2_1_1.userd.value = index + "@gmail.com";
        });
    }

    console.log(coll.pop());
    console.log(coll.shift());

    coll.unshift(item => {
        item.userd.value = 1;
        item.level_1_2_1_1.userd.value = "first@gmail.com";
    });

    coll.splice(2, 2, item => {
        item.userd.value = 20;
        item.level_1_2_1_1.userd.value = "three@gmail.com";
    });

    coll.reverse();

    coll.sort((a, b) => a.userd.value - b.userd.value);

    console.log(pkg.childrenList.level_1.level_1_2.level_1_2_1.length);


    //people
    pkg.personList.pushRange(source => {
        let list = [];

        for (let index = 5; index <= 15; index++) {
            let item = source.create();

            item.person.text = 'Person ' + index;

            list.push(item);
        }

        return list;
    });

    pkg.personList.spliceRange(0, 1, source => {
        let list = [];

        for (let index = 3; index <= 5; index++) {
            let item = source.create();

            item.person.text = 'Person ' + index;

            if (index === 5) {
                item.$.find('div').addClass('personListSelect');
            }

            list.push(item);
        }

        return list;
    });

    pkg.personList.unshiftRange(source => {
        let list = [];

        for (let index = 1; index <= 2; index++) {
            let item = source.create();

            item.person.text = 'Person ' + index;

            list.push(item);
        }

        return list;
    });
    //people

    pkg.sampleTable.head.push(row => {
        row.pushRange(source => {
            let list = [];

            for (let index = 0; index < 4; index++) {
                let item = source.create('TH');

                item.text = 'Col ' + index;
                item.$.addClass('col');
                
                list.push(item);
            }

            return list;
        });
    });

    let bodyTable2 = pkg.sampleTable.body;

    bodyTable2.pushRange(source => {
        let list = [];

        for (let index = 0; index < 10; index++) {
            let item = source.create();
            let nextIndex = source.length + index;

            item.get(0).text = 'Row ' + nextIndex + ' - Col 0';
            item.get(1).text = 'Row ' + nextIndex + ' - Col 1';
            item.get(2).text = 'Row ' + nextIndex + ' - Col 2';
            item.get(3).text = 'Row ' + nextIndex + ' - Col 3';
            
            list.push(item);
        }

        return list;
    });

    console.log(bodyTable2.pop());
    console.log(bodyTable2.shift());

    bodyTable2.unshift(item => {
        item.get(0).text = 'unshift 0';
        item.get(1).text = 'unshift 1';
        item.get(2).text = 'unshift 2';
        item.get(3).text = 'unshift 3';
    });

    bodyTable2.splice(0, 1, item => {
        item.get(0).text = 'splice 0';
        item.get(1).text = 'splice 1';
        item.get(2).text = 'splice 2';
        item.get(3).text = 'splice 3';
    });

    bodyTable2.splice(0, 1);

    bodyTable2.reverse();

    bodyTable2.sort((a, b) => {
        if (a.get(0).text < b.get(0).text) { return -1; }
        if (a.get(0).text > b.get(0).text) { return 1; }
        return 0;
    });

    (function (user) {
        user.value = 'LEGEND 01';

        user.$.on("keyup", () => {
            user.$.trigger("change");
        });
    })(pkg.clientData.user);
});

let clientPackage = $sui.createPackage('clientPackage');

clientPackage.name.first = "Name Bind";
clientPackage.className = "inputRed";

clientPackage.onPropertyChange("className", (source, newValue, oldValue) => {
    //alert($sui.clientPackage.name.first);
    clientPackage.myAudio.ctrl.play();
});

clientPackage.myAudio.src = 'https://www.w3schools.com/jsref/horse.ogg';

let countries = ["United States", "Canada"];

clientPackage.countryList.groups.pushRange(source => {
    let list = [];

    for (let index = 0; index < countries.length; index++) {
        let item = source.create();

        item.value = index;
        item.label = countries[index];

        createItemSelect(item);

        list.push(item);
    }

    return list;
});

clientPackage.countryList.push(model => {
    model.label = "London";
    model.value = "2";
});

clientPackage.countryList.$.on("change", () => {
    console.log(clientPackage.countryList.selectedItems);
});

function createItemSelect(optGroup) {
    optGroup.pushRange(source => {
        let list = [];

        for (let index = 1; index < 10; index++) {
            let item = source.create();

            item.value = optGroup.value + '.' + index;
            item.label = optGroup.label + ' - ' + index;

            list.push(item);
        }

        return list;
    });
}

clientPackage.bindCountyDistrictList.push();
clientPackage.bindCountyDistrictList.groups.push(group => {
    group.push();
});