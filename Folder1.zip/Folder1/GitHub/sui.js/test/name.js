class NameClass {
    constructor(el) {
        //let input = document.createElement();
        //el.value
    }
}