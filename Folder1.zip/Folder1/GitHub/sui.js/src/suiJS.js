(function () {
    'use strict';
    
    let _root = null;
    let _packages = null;
    let _extends = null;

    const SUI_ID = 'sui-id';
    const SUI_FOR = 'sui-for';
    const SUI_PKG = 'sui-pkg';
    const SUI_CUSTOM = 'sui-cust';
    const SUI_SELECT = 'sui-select';
    const SUI_FOR_BIND = 'sui-for-bind';
    const SUI_ITEM_TAG = 'sui-item';

    if (customElements != null && customElements.define != null) {

        class SuiPackage extends HTMLElement {
            constructor() {
                super();
            }
        }

        customElements.define(SUI_ITEM_TAG, SuiPackage);
    }

    //#region Base Enum

    const createEnumModel = (function (name, value) {
        return {
            name: name, value: value
        };
    });

    const enumFactory = (function (array) {
        let _selectors = '';
        let _array = array;

        class Enum {
            constructor() {

            }

            get selectors() {
                return _selectors;
            }

            getProperties(separeter) {
                if (separeter == null) {
                    return _array.map(c => c.name);
                }
                else {
                    return _array.map(c => c.name).reduce((result, name, index) => index > 0 ? result + separeter + name : result + name);
                }
            }

            getValues(separeter) {
                if (separeter == null) {
                    return _array.map(c => c.value);
                }
                else {
                    return _array.map(c => c.value).reduce((result, value, index) => index > 0 ? result + separeter + value : result + value);
                }
            }

            getName(value) {
                return _array.find(c => c.value === value).name;
            }

            getValue(name) {
                return _array.find(c => c.name === name).value;
            }
        }

        let oEnum = new Enum();

        for (let index = 0; index < _array.length; index++) {
            if (_selectors !== '') {
                _selectors += ',';
            }

            _selectors += '[' + _array[index].value + ']';

            (function (source, name, value) {
                Object.defineProperty(source, name, {
                    get: function () {
                        return value;
                    }
                });
            })(oEnum, _array[index].name, _array[index].value);
        }

        return oEnum;
    });

    //#endregion

    const dataTypeEnum = enumFactory([
        createEnumModel("DATA", "$nothing$")
        , createEnumModel("COMPLEX", SUI_CUSTOM)
        , createEnumModel("PACKAGE", SUI_PKG)
        , createEnumModel("COLLECTION", SUI_FOR)
        , createEnumModel("SELECT", SUI_SELECT)
        , createEnumModel("COLLECTION_BIND", SUI_FOR_BIND)
    ]);

    const tableElementTypeEnum = enumFactory([
        createEnumModel("HEAD", 0)
        , createEnumModel("BODY", 1)
        , createEnumModel("FOOT", 2)
    ]);
    debugger
    let oObserver = null;

    //#region Singleton

    class Singleton {
        constructor() {
            if (!!_root) {
                return _root;
            }

            _root = this;
            _packages = [];
            _extends = new Object();

            return _root;
        }

        getPackage(name, callback = null) {
            let result = _packages.find(item => item.name === name);

            if (callback === null) {
                return result !== undefined ? result : null;
            }
            else if (result !== undefined) {
                callback(result);
            }
        }

        createPackage(packageName, action) {
            if (action != null) {
                fnCreatePkg(packageName, action);
            }
            else {
                let pkg = null;

                fnCreatePkg(packageName, itemPkg => {
                    pkg = itemPkg;
                });

                return pkg;
            }
        }

        extend(object) {
            for (var name in object) {
                (function (source, name, value) {
                    Object.defineProperty(source, name, {
                        get: function () {
                            return value;
                        }
                    });
                })(_extends, name, object[name]);
            }
        }
    }

    //#endregion

    //#region Package Or Package Property

    const createPackageModel = (function (name, value) {
        return {
            name: name, value: value
        };
    });

    const packageFactory = (function (view, properties, el) {
        let _viewModel = view;
        let _el = el;

        let _bindProperties = new Object();

        class PackageBind {
            constructor(props) {
                props.forEach(item => {
                    (function (source, name, value) {
                        Object.defineProperty(source, name, {
                            get: function () {
                                return value;
                            }
                        });
                    })(this, item.name, item.value);
                });
            }

            onPropertyChange(propName, fn) {
                if (this[propName] != null && this[propName].changeEventList != null) {
                    this[propName].changeEventList.push(fn);
                }
                else if (_bindProperties[propName] != null && _bindProperties[propName].changeEventList != null) {
                    _bindProperties[propName].changeEventList.push(fn);
                }
            }

            get __elCustom() {
                return _el;
            }

            __addProp(propName, value) {
                _bindProperties[propName] = {
                    value: value
                    , changeEventList: []
                }

                Object.defineProperty(this, propName, {
                    get: function () {
                        return _bindProperties[propName].value;
                    }
                    , set: function (v) {
                        let field = _bindProperties[propName];

                        let oldValue = field.value;
                        field.value = v;
                        triggerChangeEvent(field.changeEventList, this, field.value, oldValue);
                    }
                });
            }

            __addPropGet(propName, value) {
                _bindProperties[propName] = {
                    value: value
                    , changeEventList: []
                }

                Object.defineProperty(this, propName, {
                    get: function () {
                        return _bindProperties[propName].value;
                    }
                });
            }
        }

        class Package extends PackageBind {
            constructor(props) {
                super(props);
            }

            get $() {
                return _viewModel;
            }
        }

        let pkg = null;

        if (_viewModel == null) {
            pkg = new PackageBind(properties);
        }
        else {
            pkg = new Package(properties);
        }

        return pkg;
    });

    //#endregion

    //#region Property

    const collectionBindPropertyFactory = (function (el) {
        let _el = el;
        let _firstChild = null;

        let _list = [];

        let _changeEventList = [];
        let _addEventList = [];
        let _insertEventList = [];
        let _removeEventList = [];

        let fnSourceList = {
            get list() {
                return _list;
            }
        };

        let fnCreateTemplate = createTemplate;

        class CollectionBindProperty extends ArraySui {
            constructor() {
                super(fnSourceList);
            }

            onChange(fn) {
                _changeEventList.push(fn);
            }

            onAdd(fn) {
                _addEventList.push(fn);
            }

            onInsert(fn) {
                _insertEventList.push(fn);
            }

            onRemove(fn) {
                _removeEventList.push(fn);
            }

            get(id, action) {
                let item = _list[id];

                if (action != null) {
                    action(item);
                }
                else {
                    return item;
                }
            }

            push(action) {
                let model = createTemplate();

                if (action != null) {
                    action(model);
                }

                addArray(_el, _list, model);
                triggerAddEvent(_addEventList, model);
            }

            pushRange(func) {
                let source = sourceRangeArrayFactory(fnSourceList, fnCreateTemplate);

                Object.freeze(source);

                func(source).forEach(itemModel => {
                    addArray(_el, _list, itemModel);
                    triggerAddEvent(_addEventList, itemModel);
                });
            }

            pop() {
                let model = _list.pop();

                removeElementArray(model);
                triggerRemoveEvent(_removeEventList, model);

                return model;
            }

            shift() {
                let model = _list.shift();

                removeElementArray(model);
                triggerRemoveEvent(_removeEventList, model);

                return model;
            }

            unshift(action) {
                let model = createTemplate();

                if (action != null) {
                    action(model);
                }

                insertArray(_el, _list, model);

                triggerInsertEvent(_insertEventList, model);
            }

            unshiftRange(func) {
                let source = sourceRangeArrayFactory(fnSourceList, fnCreateTemplate);

                Object.freeze(source);

                let items = func(source);

                for (let index = items.length - 1; index >= 0; index--) {
                    insertArray(_el, _list, items[index]);
                    triggerInsertEvent(_insertEventList, items[index]);
                }
            }

            splice(start, deleteCount, action) {
                let items = null;

                if (action != null) {
                    items = [];

                    let model = createTemplate();

                    if (action != null) {
                        action(model);
                    }

                    items.push(model);
                }

                removeArray(_el, _list, start, deleteCount, items, function (mdl) {
                    triggerRemoveEvent(_removeEventList, mdl);
                }, function (mdl) {
                    triggerInsertEvent(_insertEventList, mdl);
                });
            }

            spliceRange(start, deleteCount, func) {
                let source = sourceRangeArrayFactory(fnSourceList, fnCreateTemplate);

                Object.freeze(source);

                let items = func(source);

                removeArray(_el, _list, start, deleteCount, items, function (mdl) {
                    triggerRemoveEvent(_removeEventList, mdl);
                }, function (mdl) {
                    triggerInsertEvent(_insertEventList, mdl);
                });
            }

            reverse() {
                let parent = _el;

                for (var index = 0; index < _el.childNodes.length / 2; index++) {
                    let first = parent.childNodes[index];

                    let last = parent.childNodes[(parent.childNodes.length - 1) - index];

                    parent.replaceChild(first, last);
                    parent.insertBefore(last, parent.childNodes[index]);
                }

                _list.reverse();

                triggerChangeEventList(_changeEventList, _list);
            }

            sort(compareFn) {
                sortArray(_el, _list, compareFn);
                triggerChangeEventList(_changeEventList, _list);
            }

            clear() {
                while (_el.childNodes.length > 0) {
                    _el.childNodes[0].remove();
                }

                _list = [];

                triggerChangeEventList(_changeEventList, _list);
            }
        }

        //#region functions private

        function createTemplate() {
            let newElement = _firstChild.cloneNode(true);
            let pkg = packageFactory(null, searchProperties(newElement), newElement);

            searchBind(newElement, pkg);

            return pkg;
        }

        //#endregion

        _firstChild = document.createElement(SUI_ITEM_TAG);

        while (el.childNodes.length > 0) {
            _firstChild.appendChild(el.childNodes[0]);
        }

        let oCollection = new CollectionBindProperty();

        Object.freeze(oCollection);

        return oCollection;
    });

    const bindPropertyFactory = (function () {
        let _properties = new Object();

        class BindProperty {
            constructor() {

            }

            onPropertyChange(propName, fn) {
                _properties[propName].changeEventList.push(fn);
            }

            __addProp(propName, value) {
                _properties[propName] = {
                    value: value
                    , changeEventList: []
                }

                Object.defineProperty(this, propName, {
                    get: function () {
                        return _properties[propName].value;
                    }
                    , set: function (v) {
                        let field = _properties[propName];

                        let oldValue = field.value;
                        field.value = v;
                        triggerChangeEvent(field.changeEventList, this, field.value, oldValue);
                    }
                });
            }

            __addPropGet(propName, value) {
                _properties[propName] = {
                    value: value
                    , changeEventList: []
                }

                Object.defineProperty(this, propName, {
                    get: function () {
                        return _properties[propName].value;
                    }
                });
            }
        }

        return new BindProperty();
    });
    
    const propertyFactory = (function (element, dataType) {
        let _viewModel = null;
        let _eventFn = null;

        class Property {
            constructor() {
                
            }

            onPropertyChange(fn) {
                _eventFn.onPropertyChange(fn);
            }

            getValue() {
                return _eventFn.getValue();
            }

            setValue(v) {
                _eventFn.setValue(v);
            }

            get $() {
                return _viewModel;
            }
        }

        let oProperty = new Property();
        let component = null;

        if (dataType === dataTypeEnum.COMPLEX) {
            var name = element.attributes[SUI_CUSTOM].value;

            element.removeAttribute(SUI_CUSTOM);

            let $rootExtend = {
                element: element
                , getPackage: function () {
                    let properties = getPropertiesElement(this.element);

                    let pkg = packageFactory(viewFactory(this.element), properties);

                    searchBind(pkg.$.element, pkg);

                    return pkg;
                }
            }

            Object.freeze($rootExtend);

            component = _extends[name]($rootExtend);
        }
        else {
            component = componentFactory(element);
        }
        
        _viewModel = viewFactory(element, null, component, oProperty, eventFn => {
            _eventFn = eventFn;
        });

        return oProperty;
    });

    //#endregion

    //#region Array

    class ArraySui {
        constructor(fn) {
            let _protected = fn;
            let self = this;

            Object.defineProperty(this, 'length', { get: function () { return _protected.list.length; } });

            self.toString = function () {
                return _protected.list.toString();
            };

            self.toLocaleString = function () {
                return _protected.list.toLocaleString();
            };

            self.join = function (separator = null) {
                return _protected.list.join(separator);
            };

            self.slice = function (start, end) {
                return _protected.list.slice(start, end);
            };

            self.indexOf = function (searchElement, fromIndex) {
                return _protected.list.indexOf(searchElement, fromIndex);
            };

            self.lastIndexOf = function (searchElement, fromIndex) {
                return _protected.list.lastIndexOf(searchElement, fromIndex);
            };

            self.every = function (callbackfn, thisArg) {
                return _protected.list.every(callbackfn, thisArg);
            };

            self.some = function (callbackfn, thisArg) {
                return _protected.list.some(callbackfn, thisArg);
            };

            self.forEach = function (callbackfn, thisArg) {
                _protected.list.forEach(callbackfn, thisArg);
            };

            self.map = function (callbackfn, thisArg) {
                return _protected.list.map(callbackfn, thisArg);
            };

            self.filter = function (callbackfn, thisArg) {
                return _protected.list.filter(callbackfn, thisArg);
            };
            
            self.reduce = function (callbackfn, initialValue) {
                return _protected.list.reduce(callbackfn, initialValue);
            };
            
            self.reduceRight = function (callbackfn, initialValue){
                return _protected.list.reduceRight(callbackfn, initialValue);
            };
        }
    }

    const sourceRangeArrayFactory = (function (sourceFn, createFn, isRow) {
        let _sourceFn = sourceFn;
        let _createFn = createFn;

        class Source {
            constructor() {

            }

            create() {
                return _createFn();
            }

            get length() {
                return _sourceFn.list.length;
            }
        }

        class SourceRow {
            constructor() {

            }

            create(tagName) {
                return _createFn(tagName);
            }

            get length() {
                return _sourceFn.list.length;
            }
        }

        return isRow ? new SourceRow() :  new Source();
    });

    //#endregion

    //#region Select Property

    const selectFactory = (function (view, fnCreateTemplate) {
        let _viewModel = view;

        let _list = [];

        let fnSourceList = {
            get list() {
                return _list;
            }
        };

        let _fnCreateTemplate = fnCreateTemplate;

        let _changeEventList = [];
        let _addEventList = [];
        let _insertEventList = [];
        let _removeEventList = [];

        class ObjectSelect extends ArraySui {
            constructor() {
                super(fnSourceList);
            }

            onChange(fn) {
                _changeEventList.push(fn);
            }

            onAdd(fn) {
                _addEventList.push(fn);
            }

            onInsert(fn) {
                _insertEventList.push(fn);
            }

            onRemove(fn) {
                _removeEventList.push(fn);
            }

            get(id, action) {
                let item = _list[id];

                if (action != null) {
                    action(item);
                }
                else {
                    return item;
                }
            }

            push(action) {
                let model = _fnCreateTemplate();

                if (action != null) {
                    action(model);
                }

                addArray(_viewModel.element, _list, model);
                triggerAddEvent(_addEventList, model);
            }

            pushRange(func) {
                let source = sourceRangeArrayFactory(fnSourceList, _fnCreateTemplate);

                Object.freeze(source);

                func(source).forEach(model => {
                    addArray(_viewModel.element, _list, model);
                    triggerAddEvent(_addEventList, model);
                });
            }

            pop() {
                let model = _list.pop();

                removeElementArray(model);
                triggerRemoveEvent(_removeEventList, model);

                return model;
            }

            shift() {
                let model = _list.shift();

                removeElementArray(model);
                triggerRemoveEvent(_removeEventList, model);

                return model;
            }

            unshift(action) {
                let model = _fnCreateTemplate();

                if (action != null) {
                    action(model);
                }

                insertArray(_viewModel.element, _list, model);
                triggerInsertEvent(_insertEventList, model);
            }

            unshiftRange(func) {
                let source = sourceRangeArrayFactory(fnSourceList, _fnCreateTemplate);

                Object.freeze(source);

                let items = func(source);

                for (let index = items.length - 1; index >= 0; index--) {
                    insertArray(_viewModel.element, _list, items[index]);
                    triggerInsertEvent(_insertEventList, items[index]);
                }
            }

            splice(start, deleteCount, action) {
                let items = null;

                if (action != null) {
                    items = [];

                    let itemList = _fnCreateTemplate();

                    if (action != null) {
                        action(itemList);
                    }

                    items.push(itemList);
                }

                removeArray(_viewModel.element, _list, start, deleteCount, items, function (mdl) {
                    triggerRemoveEvent(_removeEventList, mdl);
                }, function (mdl) {
                    triggerInsertEvent(_insertEventList, mdl);
                });
            }

            spliceRange(start, deleteCount, func) {
                let source = sourceRangeArrayFactory(fnSourceList, _fnCreateTemplate);

                Object.freeze(source);

                let items = func(source);

                removeArray(_viewModel.element, _list, start, deleteCount, items, function (mdl) {
                    triggerRemoveEvent(_removeEventList, mdl);
                }, function (mdl) {
                    triggerInsertEvent(_insertEventList, mdl);
                });
            }

            reverse() {
                let parent = _viewModel.element;

                for (var index = 0; index < _viewModel.element.childNodes.length / 2; index++) {
                    let first = parent.childNodes[index];

                    let last = parent.childNodes[(parent.childNodes.length - 1) - index];

                    parent.replaceChild(first, last);
                    parent.insertBefore(last, parent.childNodes[index]);
                }

                _list.reverse();

                triggerChangeEventList(_changeEventList, _list);
            }

            sort(compareFn) {
                sortArray(viewModel.element, _list, compareFn);
                triggerChangeEventList(_changeEventList, _list);
            }

            clear() {
                while (_viewModel.element.childNodes.length > 0) {
                    _viewModel.element.childNodes[0].remove();
                }

                _list = [];

                triggerChangeEventList(_changeEventList, _list);
            }

            get $() {
                return _viewModel;
            }
        }

        //#region functions private

        function createOptionGroup(templateOptionGroup, templateOptionChild) {
            let newElement = null;

            if (templateOptionGroup != null) {
                newElement = templateOptionGroup.cloneNode(true);
            }
            else {
                newElement = document.createElement('optgroup');
            }

            let itemList = selectFactory(viewFactory(newElement), function () {
                return createOption(templateOptionChild);
            });

            Object.defineProperty(itemList, 'label', {
                get: function () {
                    return this.$.element.label;
                }
                , set: function (v) {
                    this.$.element.label = v;
                }
            });

            Object.defineProperty(itemList, 'value', {
                get: function () {
                    return this.$.element.attributes['value'].value;
                }
                , set: function (v) {
                    this.$.element.setAttribute('value', v);
                }
            });
            
            searchBind(itemList.$.element, itemList);

            Object.freeze(oObjectSelect);

            return itemList;
        }

        function createOption(template) {
            let newElement = null;

            if (template != null) {
                newElement = template.cloneNode(true);
            }
            else {
                newElement = document.createElement('option');
            }

            let itemList = propertyFactory(newElement, dataTypeEnum.DATA);
            
            searchBind(itemList.$.element, itemList);

            return itemList;
        }

        //#endregion

        let oObjectSelect = new ObjectSelect();

        if (_fnCreateTemplate == null) {
            let _templateOption = null;

            let _templateOptionGroup = null;
            let _templateOptionChild = null;

            //#region Template

            let opTemp = _viewModel.element.querySelector(":scope > option");

            if (opTemp != null) {
                opTemp.remove();
                _templateOption = opTemp;
            }

            let optGroupTemp = _viewModel.element.querySelector(":scope > optGroup");

            if (optGroupTemp != null) {
                _templateOptionGroup = optGroupTemp;

                let opTempChild = _templateOptionGroup.querySelector(":scope > option");

                if (opTempChild != null) {
                    opTempChild.remove();
                    _templateOptionChild = opTempChild;
                }

                optGroupTemp.remove();
            }

            //#endregion

            _fnCreateTemplate = function () {
                return createOption(_templateOption);
            };

            Object.defineProperty(oObjectSelect, 'selectedItem', {
                get: function () {
                    if (this.selectedIndex > -1) {
                        return getSelectedOptions()[0];
                    }
                    else {
                        return null;
                    }
                }
            });

            Object.defineProperty(oObjectSelect, 'selectedItems', {
                get: function () {
                    return getSelectedOptions();
                }
            });
            
            let _groups = selectFactory(viewFactory(_viewModel.element), function () {
                return createOptionGroup(_templateOptionGroup, _templateOptionChild);
            });

            Object.defineProperty(oObjectSelect, 'groups', {
                get: function () {
                    return _groups;
                }
            });

            function getSelectedOptions() {
                let array = [];

                oObjectSelect.filter(item => item.$.element.selected).forEach(item => {
                    array.push(item);
                });

                for (let rowIndex = 0; rowIndex < oObjectSelect.group.length; rowIndex++) {
                    let itemGroup = oObjectSelect.group.get(rowIndex);

                    itemGroup.filter(item => item.$.element.selected).forEach(item => {
                        array.push(item);
                    });
                }

                return array;
            }

            Object.freeze(oObjectSelect);
        }

        return oObjectSelect;
    });

    //#endregion

    //#region Collection Property

    const collectionFactory = (function (view, firstChild) {
        let _viewModel = view;
        let _firstChild = firstChild;

        let _list = [];

        let fnSourceList = {
            get list() {
                return _list;
            }
        };

        let fnCreateTemplate = createTemplate;

        class Collection extends ArraySui {
            constructor() {
                super(fnSourceList);
            }

            get(id, action) {
                let item = _list[id];

                if (action != null) {
                    action(item);
                }
                else {
                    return item;
                }
            }

            push(action) {
                let model = createTemplate();

                if (action != null) {
                    action(model);
                }

                addArray(_viewModel.element, _list, model);
            }

            pushRange(func) {
                let source = sourceRangeArrayFactory(fnSourceList, fnCreateTemplate);

                Object.freeze(source);

                func(source).forEach(itemModel => {
                    addArray(_viewModel.element, _list, itemModel);
                });
            }

            pop() {
                let model = _list.pop();

                removeElementArray(model);

                return model;
            }

            shift() {
                let model = _list.shift();

                removeElementArray(model);

                return model;
            }

            unshift(action) {
                let model = createTemplate();

                if (action != null) {
                    action(model);
                }

                insertArray(_viewModel.element, _list, model);
            }

            unshiftRange(func) {
                let source = sourceRangeArrayFactory(fnSourceList, fnCreateTemplate);

                Object.freeze(source);

                let items = func(source);

                for (let index = items.length - 1; index >= 0; index--) {
                    insertArray(_viewModel.element, _list, items[index]);
                }
            }

            splice(start, deleteCount, action) {
                let items = null;

                if (action != null) {
                    items = [];

                    let model = createTemplate();

                    if (action != null) {
                        action(model);
                    }

                    items.push(model);
                }

                removeArray(_viewModel.element, _list, start, deleteCount, items);
            }

            spliceRange(start, deleteCount, func) {
                let source = sourceRangeArrayFactory(fnSourceList, fnCreateTemplate);

                Object.freeze(source);

                let items = func(source);

                removeArray(_viewModel.element, _list, start, deleteCount, items);
            }

            reverse() {
                let parent = _viewModel.element;

                for (var index = 0; index < _viewModel.element.childNodes.length / 2; index++) {
                    let first = parent.childNodes[index];

                    let last = parent.childNodes[(parent.childNodes.length - 1) - index];
                    
                    parent.replaceChild(first, last);
                    parent.insertBefore(last, parent.childNodes[index]);
                }

                _list.reverse();
            }

            sort(compareFn) {
                sortArray(_viewModel.element, _list, compareFn);
            }

            clear() {
                while (_viewModel.element.childNodes.length > 0) {
                    _viewModel.element.childNodes[0].remove();
                }

                _list = [];
            }

            get $() {
                return _viewModel;
            }
        }

        //#region functions private

        function createTemplate() {
            let newElement = _firstChild.cloneNode(true); 
            let pkg = getPackage(_list.length, newElement);//name ex: 0,1,2,3 (_list.length)

            searchBind(pkg.$.element, pkg);

            return pkg;
        }

        function getPackage(name, element) {
            return packageFactory(viewFactory(element, name), searchProperties(element));
        }

        //#endregion

        let oCollection = new Collection();

        Object.freeze(oCollection);

        return oCollection;
    });

    //#endregion

    //#region Table Property

    const captionTableFactory = (function (element) {
        class Caption {
            constructor() {

            }
        }

        let oCaption = new Caption();
        
        createBaseTable(oCaption, element, getPropertiesElement(element));

        return oCaption;
    });

    const rowTableFactory = (function (element, columns, name) {
        let _name = name;
        let _columns = columns;

        let fnSourceList = {
            get list() {
                return _columns;
            }
        };

        let fnCreateTemplate = function (tagName) {
            return createTemplate(tagName);
        };

        class Row extends ArraySui {
            constructor() {
                super(fnSourceList);
            }

            getName() {
                return _name;
            }

            get(id, action) {
                let item = null;

                if (typeof id === "number") {
                    item = _columns[id];
                }
                else {
                    item = _columns.find(c => c.getName() === id);
                }

                if (action != null) {
                    action(item);
                }
                else {
                    return item;
                }
            }
        }
		
		class RowGeneric extends Row {
            constructor() {
                super();

                _columns = [];
            }
			
            push(tagName, action) {
                let model = createTemplate(tagName);

                if (action != null) {
                    action(model);
                }
                
                addArray(this.$.element, _columns, model);
            }

            pushRange(func) {
                let source = sourceRangeArrayFactory(fnSourceList, fnCreateTemplate, true);

                Object.freeze(source);
                
                func(source).forEach(model => {
                    addArray(this.$.element, _columns, model);
                });
            }

            pop() {
                let model = _columns.pop();

                removeElementArray(model);

                return model;
            }

            shift() {
                let model = _columns.shift();

                removeElementArray(model);

                return model;
            }

            unshift(tagName, action) {
                let model = createTemplate(tagName);

                if (action != null) {
                    action(model);
                }

                insertArray(this.$.element, _columns, model);
            }

            unshiftRange(func) {
                let source = sourceRangeArrayFactory(fnSourceList, fnCreateTemplate, true);

                Object.freeze(source);

                let items = func(source);

                for (let index = items.length - 1; index >= 0; index--) {
                    insertArray(this.$.element, _columns, items[index]);
                }
            }

            splice(start, deleteCount, tagName, action) {
                let items = null;

                if (action != null) {
                    items = [];

                    let model = createTemplate(tagName);

                    if (action != null) {
                        action(model);
                    }

                    items.push(model);
                }

                removeArray(this.$.element, _columns, start, deleteCount, items);
            }

            spliceRange(start, deleteCount, func) {
                let source = sourceRangeArrayFactory(fnSourceList, fnCreateTemplate, true);

                Object.freeze(source);

                let items = func(source);

                removeArray(this.$.element, _columns, start, deleteCount, items);
            }

            reverse() {
                for (var index = 0; index < this.$.element.childNodes.length / 2; index++) {
                    let first = this.$.element.childNodes[index];

                    let last = this.$.element.childNodes[(this.$.element.childNodes.length - 1) - index];

                    this.$.element.replaceChild(first, last);
                    this.$.element.insertBefore(last, this.$.element.childNodes[index]);
                }

                _columns.reverse();
            }

            sort(compareFn) {
                sortArray(this.$.element, _columns, compareFn);
            }

            clear() {
                while (this.$.element.childNodes.length > 0) {
                    this.$.element.childNodes[0].remove();
                }

                _columns = [];
            }			
        }		
		
        function createTemplate(tagName) {
            let tag = '';

            if ((/td/gi).test(tagName)) {
                tag = 'TD';
            }
            else {
                tag = 'TH';
            }

            return columnTableFactory(document.createElement(tag));
		}

        let oRow = null;
		
		if(_columns != null){
			oRow = new Row();
		}
		else {
            oRow = new RowGeneric(); 
		}

        createBaseTable(oRow, element);
        Object.freeze(oRow);

        return oRow;
    });

    const columnTableFactory = (function (element, name) {
        let _name = name;

        class Column {
            constructor() {

            }

            getName() {
                return _name;
            }
        }

        let oColumn = new Column();

        createBaseTable(oColumn, element, getPropertiesElement(element));

        searchBind(element, oColumn);

        return oColumn;
    });

    const templateRowTableFactory = (function (element, name) {
        let _name = name;
        let _element = element;

        class Template {
            constructor() {
            }

            get name() {
                return _name;
            }

            get element() {
                return _element;
            }
        }

        return new Template();
    });

    const heBoFoBaseTableFactory = (function (parentEl, template) {
        let _parentEl = parentEl;
        let _template = template;        

        let _rows = [];

        let fnSourceList = {
            get list() {
                return _rows;
            }
        };

        let fnCreateTemplate = function () {
            return createTemplate();
        };

        class HeadBodyFootBase extends ArraySui {
            constructor() {
                super(fnSourceList)
            }

            get(id, action) {
                let item = null;

                if (typeof id === "number") {
                    item = _rows[id];
                }
                else {
                    item = _rows.find(c => c.getName() === id);
                }

                if (action != null) {
                    action(item);
                }
                else {
                    return item;
                }
            }

            push(action) {
                let model = createTemplate();

                if (action != null) {
                    action(model);
                }

                addArray(_parentEl, _rows, model);
            }

            pushRange(func) {
                let source = sourceRangeArrayFactory(fnSourceList, fnCreateTemplate);

                Object.freeze(source);

                func(source).forEach(model => {
                    addArray(_parentEl, _rows, model);
                });
            }

            pop() {
                let model = _rows.pop();

                removeElementArray(model);

                return model;
            }

            shift() {
                let model = _rows.shift();

                removeElementArray(model);

                return model;
            }

            unshift(action) {
                let model = createTemplate();

                if (action != null) {
                    action(model);
                }

                insertArray(_parentEl, _rows, model);
            }

            unshiftRange(func) {
                let source = sourceRangeArrayFactory(fnSourceList, fnCreateTemplate);

                Object.freeze(source);

                let items = func(source);

                for (let index = items.length - 1; index >= 0; index--) {
                    insertArray(_parentEl, _rows, items[index]);
                }
            }

            splice(start, deleteCount, action) {
                let items = null;

                if (action != null) {
                    items = [];

                    let model = createTemplate();

                    if (action != null) {
                        action(model);
                    }

                    items.push(model);
                }

                removeArray(_parentEl, _rows, start, deleteCount, items);
            }

            spliceRange(start, deleteCount, func) {
                let source = sourceRangeArrayFactory(fnSourceList, fnCreateTemplate);

                Object.freeze(source);

                let items = func(source);

                removeArray(_parentEl, _rows, start, deleteCount, items);
            }

            reverse() {
                for (var index = 0; index < _parentEl.childNodes.length / 2; index++) {
                    let first = _parentEl.childNodes[index];

                    let last = _parentEl.childNodes[(_parentEl.childNodes.length - 1) - index];

                    _parentEl.replaceChild(first, last);
                    _parentEl.insertBefore(last, _parentEl.childNodes[index]);
                }

                _rows.reverse();
            }

            sort(compareFn) {
                sortArray(_parentEl, _rows, compareFn);
            }

            clear() {
                while (_parentEl.childNodes.length > 0) {
                    _parentEl.childNodes[0].remove();
                }

                _rows = [];
            }
        }

        //#region functions private

        function createTemplate() {
            if (_template != null) {
                let tr = _template.cloneNode(true);
                let columns = [];

                tr.childNodes.forEach(itemEl => {
                    if ((/td|th/gi).test(itemEl.tagName)) {
                        columns.push(columnTableFactory(itemEl, searchNameAttribute(itemEl)));
                    }
                });

                return rowTableFactory(tr, columns, searchNameAttribute(tr));
            }
            else {
                return rowTableFactory(document.createElement('TR'), null, null);
            }
        }

        //#endregion

        return new HeadBodyFootBase();
    });

    const headBodyFootTableFactory = (function (element) {
        let _templates = [];

        let _type = null;

        class HeadBodyFoot {
            constructor() {
            }

            getTempl(id, action = null) {
                let template = null;

                if (typeof id === "number") {
                    template = _templates[id].element;
                }
                else {
                    template = _templates.find(c => c.name === id).element;
                }

                let self = this;
                let oHeadBodyFoot = heBoFoBaseTableFactory(self.$.element, template)

                Object.freeze(oHeadBodyFoot);

                if (action != null) {
                    action(oHeadBodyFoot);
                }
                else {
                    return oHeadBodyFoot;
                }
            }

            getType() {
                return _type;
            }
        }

        //#region functions private

        function createObject(parentEl) {
            //#region Create Templates

            while (parentEl.childNodes.length > 0) {
                let itemEl = parentEl.childNodes[0];

                if ((/tr/gi).test(itemEl.tagName)) {
                    _templates.push(templateRowTableFactory(itemEl, searchNameAttribute(itemEl)));
                }

                parentEl.removeChild(itemEl);
            }

            //#endregion

            _type = tableElementTypeEnum.getValue(parentEl.tagName.replace(/^t/gi, '').toUpperCase());

            let oHeadBodyFoot = null;

            if (_templates.length > 1) {
                oHeadBodyFoot = new HeadBodyFoot();
            }
            else if (_templates.length === 1) {
                oHeadBodyFoot = heBoFoBaseTableFactory(parentEl, _templates[0].element);
            }
            else {
                oHeadBodyFoot = heBoFoBaseTableFactory(parentEl, null);
            }

            createBaseTable(oHeadBodyFoot, parentEl);

            Object.freeze(oHeadBodyFoot);

            return oHeadBodyFoot;
        }

        //#endregion

        return createObject(element);
    });

    const itemBodiesTableFactory = (function (body, name) {
        let _body = body;
        let _name = name;

        class ItemBodies {
            constructor() {
            }

            get body() {
                return _body;
            }

            get name() {
                return _name;
            }
        }

        return new ItemBodies();
    });

    const bodiesTableFactory = (function (list) {
        let _list = list;

        class Bodies extends ArraySui {
            constructor() {
                super({
                    get list() {
                        return _list;
                    }
                })
            }

            get(id, action) {
                let item = null;

                if (typeof id === "number") {
                    item = _list[id].body;
                }
                else {
                    item = _list.find(c => c.name === id).body;
                }

                if (action != null) {
                    action(item);
                }
                else {
                    return item;
                }
            }
        }

        let oBodies = new Bodies();

        Object.freeze(oBodies);

        return oBodies;
    });

    const tableFactory = (function (view, tableAux) {
        let _viewModel = view;

        let _caption = null;
        let _head = null;
        let _bodies = null;
        let _foot = null;

        class Table {
            constructor() {

            }

            get caption() {
                return _caption;
            }

            get head() {
                return _head;
            }

            get body() {
                return _bodies.length > 0 ? _bodies.get(0) : null;
            }

            get bodies() {
                return _bodies;
            }

            get foot() {
                return _foot;
            }

            get $() {
                return _viewModel;
            }
        }

        //#region functions private

        function createCaption(oTable, cpt) {
            if (cpt == null) {
                oTable.appendChild(document.createElement('CAPTION'));
            }
            else {
                oTable.appendChild(cpt);
            }

            return captionTableFactory(oTable.caption);
        }

        function createHeadFoot(oTable, tag, tagName) {
            if (tag == null) {
                oTable.appendChild(document.createElement(tagName));
            }
            else {
                oTable.appendChild(tag);
            }

            return headBodyFootTableFactory(oTable[tagName]);
        }

        function createBodies(oTable, bodyLst) {
            let bodyCollection = [];

            if (bodyLst == null || bodyLst.length === 0) {
                addBodies(oTable, bodyCollection, document.createElement('BODY'));
            }
            else {
                while (bodyLst.length > 0) {
                    addBodies(oTable, bodyCollection, bodyLst[0]);
                }
            }

            return bodiesTableFactory(bodyCollection);
        }

        function addBodies(oTable, list, bodyEl) {
            oTable.appendChild(bodyEl);

            let oBody = headBodyFootTableFactory(bodyEl);
            let name = searchNameAttribute(bodyEl);

            list.push(itemBodiesTableFactory(oBody, name));
        }

        //#endregion
        
        _caption = createCaption(_viewModel.element, tableAux.caption);
        _head = createHeadFoot(_viewModel.element, tableAux.tHead, 'tHead');
        _bodies = createBodies(_viewModel.element, tableAux.tBodies);
        _foot = createHeadFoot(_viewModel.element, tableAux.tFoot, 'tFoot');
        
        return new Table();
    });

    //#endregion

    //#region View

    const viewFactory = (function (element, packageName, component, property, eventCallBack) {
        let _element = element;
        let _packageName = packageName;

        let changeEventList = [];

        let getValue = null;
        let _action = null;

        class View {
            constructor() {
                if (_packageName != null) {
                    Object.defineProperty(this, 'name', {
                        get: function () {
                            return _packageName;
                        }
                    });
                }

                if (component != null) {
                    _action = {
                        on: function (evt, fn) {
                            component.on(evt, fn);
                        }
                        , trigger: function (evt) {
                            component.trigger(evt);
                        }
                        , css: function (propName) {
                            return component.css(propName);
                        }
                        , css: function (propName, value) {
                            component.css(propName, value);
                        }
                    }

                    let componentProperties = getPropertiesClass(component);

                    componentProperties.forEach(item => {
                        (function (prop, name, source) {
                            Object.defineProperty(prop, name, {
                                get: function () {
                                    return source[name];
                                }
                                , set: function (v) {
                                    let oldValue = source[name];
                                    source[name] = v;
                                    triggerChangeEvent(changeEventList, source, source[name], oldValue);
                                }
                            });
                        })(property, item, component);
                    });

                    getValue = function () {
                        return component.getValue();
                    }

                    if (eventCallBack != null) {
                        let eventsView = {
                            onPropertyChange: function (fn) {
                                changeEventList.push(fn);
                            }
                            , getValue: getValue
                            , setValue: (v) => {
                                let oldValue = getValue();
                                component.setValue(v);
                                triggerChangeEvent(changeEventList, component, v, oldValue);
                            }
                        }

                        Object.freeze(eventsView);

                        eventCallBack(eventsView);
                    }

                    let oldValue = null;

                    component.on("blur", (source) => {
                        oldValue = getValue();
                    });

                    component.on("change", (source) => {
                        triggerChangeEvent(changeEventList, source, getValue(), oldValue);
                        oldValue = null
                    });
                }
                else {
                    _action = {
                        on: function (evt, fn) {
                            addEvent(_element, evt, fn);
                        }
                        , trigger: function (evt) {
                            _element.dispatchEvent(new Event(evt));
                        }
                        , css: function (propName) {
                            return getCss(_element, propName);
                        }
                        , css: function (propName, value) {
                            setCss(_element, propName, value);
                        }
                    }
                }

                Object.freeze(_action);
            }

            find(selector) {
                return viewFactory(_element.querySelector(selector));
            }

            on(evt, fn) {
                _action.on(evt, fn)
            }

            trigger(evt) {
                _action.trigger(evt);
            }

            css(propName) {
                return _action.css(propName);
            }

            css(propName, value) {
                _action.css(propName, value);
            }

            show() {
                _element.style.display = '';
            };

            hide() {
                _element.style.display = 'none';
            };

            addClass() {
                for (let i = 0; i < arguments.length; i++) {
                    _element.classList.add(arguments[i]);
                }
            }

            removeClass() {
                for (let i = 0; i < arguments.length; i++) {
                    _element.classList.remove(arguments[i]);
                }
            }

            switchClass(newClass, oldClass) {
                _element.classList.remove(oldClass);
                _element.classList.add(newClass);
            }

            hasClass(name) {
                return _element.classList.contains(name); 
            }

            get element() {
                return _element;
            }
        }

        return new View();
    });

    //#endregion

    //#region Component

    const componentFactory = (function (element) {
        let _element = element;

        //Audio and Video
        let _ctrl = null;

        //#region Classes

        //#region Text
        class TextComponent {
            constructor() {
            }

            get text() {
                return getText();
            }

            set text(v) {
                setText(v);
            }

            on(evt, fn) {
                addEvent(_element, evt, fn);
            }

            trigger(evt) {
                _element.dispatchEvent(new Event(evt));
            }

            css(propName) {
                return getCss(_element, propName);
            }

            css(propName, value) {
                setCss(_element, propName, value);
            }

            getValue() {
                return this.text;
            }

            setValue(v) {
                this.text = v;
            }
        }
        //#endregion

        //#region Html
        class HtmlComponent extends TextComponent {
            constructor() {
                super();
            }

            get html() {
                return getElementHtml(_element);
            }

            set html(v) {
                setElementHtml(_element, v);
            }
        }
        //#endregion

        //#region Input
        class InputComponent {
            constructor() {

            }

            get value() {
                return _element.value;
            }

            set value(v) {
                _element.value = v;
            }

            on(evt, fn) {
                addEvent(_element, evt, fn);
            }

            trigger(evt) {
                _element.dispatchEvent(new Event(evt));
            }

            css(propName) {
                return getCss(_element, propName);
            }

            css(propName, value) {
                setCss(_element, propName, value);
            }

            getValue() {
                return this.value;
            }

            setValue(v) {
                this.value = v;
            }
        }
        //#endregion

        //#region Container
        class ContainerComponent extends HtmlComponent {
            constructor() {
                super();
            }

        }
        //#endregion

        //#region Boolean
        class BooleanComponent extends InputComponent {
            constructor() {
                super();
            }

            get checked() {
                return _element.checked;
            }

            set checked(v) {
                _element.checked = v;
            }

            getValue() {
                return this.checked;
            }

            setValue(v) {
                this.checked = v;
            }
        }
        //#endregion

        //#region Radio
        class RadioComponent extends BooleanComponent {
            constructor() {
                super();
            }
        }
        //#endregion

        //#region Checkbox
        class CheckboxComponent extends BooleanComponent {
            constructor() {
                super();
            }
        }
        //#endregion

        //#region Button
        class ButtonComponent extends InputComponent {
            constructor() {
                super();
            }
        }
        //#endregion

        //#region Textarea
        class TextareaComponent extends InputComponent {
            constructor() {
                super();
            }

            get text() {
                return getText();
            }

            set text(v) {
                setText(v);
            }
        }
        //#endregion

        //#region Image
        class ImageComponent extends TextComponent {
            constructor() {
                super();
            }

            get src() {
                return _element.src;
            }

            set src(v) {
                _element.src = v;
            }

            get alt() {
                return _element.alt;
            }

            set alt(v) {
                _element.alt = v;
            }

            get isMap() {
                return _element.isMap;
            }

            set isMap(v) {
                _element.isMap = v === true;
            }

            getValue() {
                return this.src;
            }

            setValue(v) {
                this.src = v;
            }
        }
        //#endregion

        //#region Media
        class MediaComponent extends HtmlComponent {
            constructor() {
                super();

                _ctrl = {
                    addTextTrack: function (kind, label, language) {
                        return _element.addTextTrack(kind, label, language);
                    }
                    , captureStream: function () {
                        return _element.captureStream();
                    }
                    , canPlayType: function (mediaType) {
                        _element.canPlayType(mediaType);
                    }
                    , fastSeek: function (time) {
                        _element.fastSeek(time);
                    }
                    , load: function () {
                        _element.load();
                    }
                    , pause: function () {
                        _element.pause();
                    }
                    , play: function () {
                        return _element.play();
                    }
                    , seekToNextFrame: function () {
                        return _element.seekToNextFrame();
                    }
                    , setMediaKeys: function (mediaKeys) {
                        return _element.setMediaKeys(mediaKeys);
                    }
                    , setSinkId: function (sinkId) {
                        return _element.setSinkId(sinkId);
                    } 
                };

                getPropertiesMediaHtmlElement().forEach(item => {
                    if (item.r) {
                        (function (source, name) {
                            Object.defineProperty(source, name, { get: function () { return _element[name]; } });
                        })(_ctrl, item.p);
                    }
                    else {
                        (function (source, name) {
                            Object.defineProperty(source, name, { get: function () { return _element[name]; },  set: function (v) { _element[name] = v; } });
                        })(_ctrl, item.p);
                    }
                });
            }

            get src() {
                return _element.src;
            }

            set src(v) {
                _element.src = v;
            }

            get ctrl() {
                return _ctrl;
            }

            getValue() {
                return this.src;
            }
        }
        //#endregion

        //#region Video
        class VideoComponent extends MediaComponent {
            constructor() {
                super();
            }
        }
        //#endregion

        //#region Audio
        class AudioComponent extends MediaComponent {
            constructor() {
                super();
            }
        }
        //#endregion

        //#region Option
        class OptionComponent extends TextComponent {
            constructor() {
                super();
            }

            get label() {
                return this.text;
            }

            set label(v) {
                this.text = v;
            }

            get value() {
                return _element.value;
            }

            set value(v) {
                _element.value = v;
            }

            getValue() {
                return { label: this.label, value: this.value };
            }

            setValue(v) {
                this.label = v.label;
                this.value = v.value;
            }
        }
        //#endregion

        //#region Element
        class ElementComponent extends HtmlComponent {
            constructor() {
                super();
            }
        }
        //#endregion

        //#endregion

        //#region private functions

        function getText() {
            return getElementText(_element)
        }

        function setText(v) {
            setElementText(_element, v);
        }

        function createComponent() {
            let item = getFnVmArray().find(item => item.condition(_element));

            if (item != null) {
                return item.create();
            }
            else {
                return new ElementComponent();
            }
        }

        function getFnVmArray() {
            return [
                createItemFnVm((el) => { return (/div|header|footer|article|section/gi).test(el.tagName); }, function () { return new ContainerComponent(); })
                , createItemFnVm((el) => { return (/input/gi).test(el.tagName) && !(/button|reset|submit|radio|checkbox/gi).test(el.type); }, function () { return new InputComponent(); })
                , createItemFnVm((el) => { return (/input/gi).test(el.tagName) && (/radio/gi).test(el.type); }, function () { return new RadioComponent(); })
                , createItemFnVm((el) => { return (/input/gi).test(el.tagName) && (/checkbox/gi).test(el.type); }, function () { return new CheckboxComponent(); })
                , createItemFnVm((el) => {
                    return ((/input/gi).test(el.tagName) && (/button|reset|submit/gi).test(el.type)) || (/button/gi).test(el.tagName);
                }, function () { return new ButtonComponent(); })
                , createItemFnVm((el) => { return (/textarea/gi).test(el.tagName); }, function () { return new TextareaComponent(); })
                , createItemFnVm((el) => { return (/img/gi).test(el.tagName); }, function () { return new ImageComponent(); })
                , createItemFnVm((el) => { return (/audio/gi).test(el.tagName); }, function () { return new AudioComponent(); })
                , createItemFnVm((el) => { return (/video/gi).test(el.tagName); }, function () { return new VideoComponent(); })
                , createItemFnVm((el) => { return (/option/gi).test(el.tagName); }, function () { return new OptionComponent(); })	
            ];
        }

        function createItemFnVm(condition, fn) {
            return { condition: condition, create: fn };
        }

        function getPropertiesMediaHtmlElement() {
            return [{ p: 'audioTracks', r: false }
                , { p: 'autoplay', r: false }
                , { p: 'buffered', r: true }
                , { p: 'controller', r: false }
                , { p: 'controls', r: false }
                , { p: 'controlsList', r: true }
                , { p: 'crossOrigin', r: false }
                , { p: 'currentSrc', r: true }
                , { p: 'currentTime', r: false }
                , { p: 'defaultMuted', r: false }
                , { p: 'defaultPlaybackRate', r: false }
                , { p: 'disableRemotePlayback', r: false }
                , { p: 'duration', r: true }
                , { p: 'ended', r: true }
                , { p: 'error', r: true }
                , { p: 'loop', r: false }
                , { p: 'mediaKeys', r: true }
                , { p: 'muted', r: false }
                , { p: 'networkState', r: true }
                , { p: 'paused', r: true }
                , { p: 'playbackRate', r: false }
                , { p: 'played', r: true }
                , { p: 'preload', r: false }
                , { p: 'preservesPitch ', r: false }
                , { p: 'readyState', r: true }
                , { p: 'seekable', r: true }
                , { p: 'seeking', r: true }
                , { p: 'sinkId ', r: true }
                , { p: 'srcObject', r: false }
                , { p: 'textTracks', r: true }
                , { p: 'videoTracks', r: true }
                , { p: 'volume', r: false }];
        }

        //#endregion

        return createComponent();
    });

    //#endregion

    //#region Observe

    const observerFactory = (function () {
        let _list = [];
        let _waitFieldBindList = [];

        let _wasBlocked = false;

        class Observer {
            constructor() {

            }

            addChangeEvent(el, attr, attrName, fn) {
                let idInterval = 0;
                
                idInterval = setInterval(() => {
                    if (!_wasBlocked) {
                        _list.push(createItem(el, attr, attrName, fn));

                        clearInterval(idInterval);
                    }
                }, 5);
            }

            addWaitFieldBind(waitFieldBind) {
                let idInterval = 0;

                idInterval = setInterval(() => {
                    if (!_wasBlocked) {
                        _waitFieldBindList.push(waitFieldBind);

                        clearInterval(idInterval);
                    }
                }, 5);
            }

            existsWaitFieldBind(predicate) {
                return _waitFieldBindList.find(predicate) != null;
            }
        }

        function createItem(el, attr, attrName, fn) {
            return {
                el: el
                , attr: attr
                , attrName: attrName
                , fn: fn
                , oldValue: attr[attrName]
            }
        }

        setInterval(() => {
            _wasBlocked = true;

            for (let index = _list.length - 1; index >= 0; index--) {
                let item = _list[index];

                if (document.body.contains(item.el) && item.fn != null) {
                    if (item.oldValue !== item.attr[item.attrName]) {
                        item.fn(item.attr, item.attr[item.attrName], item.oldValue);

                        item.oldValue = item.attr[item.attrName];
                    }
                } else {
                    _list.splice(index, 1);
                }
            }

            for (let index = _waitFieldBindList.length - 1; index >= 0; index--) {
                let item = _waitFieldBindList[index];

                if (item.call()) {
                    _waitFieldBindList.splice(index, 1);
                }
            }

            _wasBlocked = false;
        }, 10);

        return new Observer();
    });

    //#endregion

    //#region ContentElement

    const contentElementFactory = (function (element) {
        let _element = element;

        class HtmlElement {
            constructor() {

            }

            get isText() {
                return false;
            }

            get content() {
                return getElementText(_element);
            }

            set content(v) {
                setElementText(_element.innerText, v);
            }
        }

        class Text {
            constructor() {

            }

            get isText() {
                return true;
            }

            get content() {
                return _element.nodeValue;
            }

            set content(v) {
                _element.nodeValue = v == null ? '' : v;
            }
        }

        let oClass = null;

        if (_element.innerText !== undefined) {
            oClass = new HtmlElement();
        }
        else {
            oClass = new Text();
        }

        return oClass;
    });

    //#endregion

    //#region private functions

    const createListTypeModel = (function (el, dataType, children) {
        return {
            el: el
            , dataType: dataType
            , children: children
        };
    });

    const fnOtherProperties = [
        { fn: createPackageProperty, index: dataTypeEnum.PACKAGE }
        , { fn: createCollectionProperty, index: dataTypeEnum.COLLECTION }
        , { fn: createPropertyChild, index: dataTypeEnum.COMPLEX }
        , { fn: createPropertyChild, index: dataTypeEnum.DATA }
        , { fn: createSelectProperty, index: dataTypeEnum.SELECT }
    ];

    function fnSearchParentListType(array, el) {
        let parent = array.find(c => c.el.contains(el));

        if (parent != null) {
            if (parent.children.length > 0) {
                fnSearchParentListType(parent.children, el);
            }
            else {
                parent.children.push(createListTypeModel(el, getPropertyType(el), []));
            }
        }
        else {
            array.push(createListTypeModel(el, getPropertyType(el), []));
        }
    }

    function fnListContains(array, el, level = 0) {
        let wasFound = false;
        let parent = array.find(c => c.el.contains(el));

        if (parent != null) {
            if (parent.children != null && parent.children.length > 0) {
                wasFound = fnListContains(parent.children, el, level + 1);
            }
            else {
                wasFound = true;
                parent.children.push(createListTypeModel(el, getPropertyType(el), null));
            }
        }
        else if (level > 0){
            wasFound = true;
            array.push(createListTypeModel(el, getPropertyType(el), null));
        }

        return wasFound;
    }

    function fnCreatePkg(packageName, action) {
        if (_packages.findIndex(item => item.name === packageName) === -1) {
            let pkgElement = document.querySelector('[' + SUI_ID + '="' + packageName + '"]');

            let pkg = packageFactory(viewFactory(pkgElement, getNameAttribute(pkgElement), null, null), searchProperties(pkgElement));
            _packages.push(pkg);

            (function (source, name, value) {
                Object.defineProperty(source, name, {
                    get: function () {
                        return value;
                    }
                });
            })(_root, packageName, pkg);

            searchBind(pkgElement, pkg);

            if (action !== null) {
                action(pkg);
            }
        }
        else {
            throw 'There is already an object named "' + packageName + '"!';
        }
    }

    function searchBind(el, currentObject) {
        let isFor = false;
        
        if (el.hasAttribute(SUI_FOR_BIND)) {
            isFor = true;

            let attributeValue = el.attributes[SUI_FOR_BIND].value;

            if (attributeValue.toLowerCase().indexOf(',one') > -1) {
                attributeValue = attributeValue.replace(/,one/gi, ',forone');
            }
            else {
                attributeValue = attributeValue.replace(/}}/gi, ',for}}');
            }
            
            el.removeAttribute(SUI_FOR_BIND);

            let groups = getFieldGroups(attributeValue);
            
            getFieldBindAll(groups, currentObject, el, null, false);
        }

        if (el.attributes != null) {
            for (let index = 0; index < el.attributes.length; index++) {
                let attr = el.attributes[index];

                let groups = getFieldGroups(attr.value);

                getFieldBindAll(groups, currentObject, el, attr, false);
            }
        }

        if (!isFor) {
            for (let index = 0; index < el.childNodes.length; index++) {
                let childNode = el.childNodes[index];
                
                if (!/#comment/gim.test(childNode.nodeName)) {
                    let contentElement = contentElementFactory(childNode);

                    if (!contentElement.isText) {
                        searchBind(childNode, currentObject);
                    }
                    else {
                        let groups = getFieldGroups(contentElement.content);

                        getFieldBindAll(groups, currentObject, el, contentElement, true);
                    }
                }
            }
        }
    }

    function getFieldGroups(content) {
        let patt = /{{(.+?\S.[^}}]*)}}/gm;
        
        let matches = null;
        let groups = [];
        
        while ((matches = patt.exec(content)) != null) {
            for (let index = 1; index < matches.length; index += 2) {
                groups.push(matches[index]);
            }
        }

        return groups;
    }

    function createWaitCreateField(mainPackage, groups, currentObject, el, htmlElement, isContent) {
        let obj = {
            mainPackage: mainPackage
            , groups: groups
            , currentObject: currentObject
            , el: el
            , htmlElement: htmlElement
            , isContent: isContent
            , call: function () {
                let isOk = false;

                if (_root[this.mainPackage] != null) {
                    getFieldBindAll(this.groups, this.currentObject, this.el, this.htmlElement, this.isContent);

                    isOk = true;
                }

                return isOk;
            }
        }

        Object.freeze(obj);

        oObserver.addWaitFieldBind(obj);
    }

    function getFieldBindAll(groups, currentObject, el, htmlElement, isContent) {
        getFieldBind(groups, currentObject, fieldDataList => {
            createField(fieldDataList, el, htmlElement, isContent);
        }, (mainPackageList) => {
            createWaitCreateField(mainPackageList, groups, currentObject, el, htmlElement, isContent);
        });
    }

    function getFieldBind(groups, currentObject, callBack, callBackWait) {
        if (groups.length > 0) {
            let mainPackageList = [];
            let fieldDataList = [];

            for (let index = 0; index < groups.length; index++) {
                let group = groups[index];

                let array = group.split(',');
                let template = '';
                let twoDirect = true;
                let isFor = false;

                if (array.length > 1) {
                    template = array[0];

                    let param = array[1].toLocaleString().trim().toLowerCase();

                    twoDirect = !(param === "one" || param === "forone");

                    isFor = param === "for" || param === "forone";
                }
                else {
                    template = array[0];
                }

                let fields = template.split('.');
                let firstField = null;

                if (fields[0] === "$") {
                    firstField = currentObject;
                }
                else if (_root[fields[0]] != null) {
                    firstField = _root[fields[0]];
                }
                else {
                    mainPackageList.push(fields[0]);
                }

                if (firstField != null) {
                    let lastFieldName = fields.splice(fields.length - 1, 1);
                    let object = null;

                    if (fields.length == 1) {
                        object = firstField;
                    }
                    else {
                        object = createFieldObject(firstField, fields, 1);
                    }

                    if (!isFor && !(lastFieldName in object)) {
                        object.__addProp(lastFieldName, null);
                    }
                    
                    let fieldData = {
                        object: object
                        , fieldName: lastFieldName
                        , twoDirect: twoDirect
                        , template: '{{' + group + '}}'
                        , fnCreateFor: isFor ? collectionBindPropertyFactory : null
                    }

                    Object.freeze(fieldData);

                    fieldDataList.push(fieldData);
                }
            }

            if (mainPackageList.length === 0) {
                callBack(fieldDataList);
            }
            else {
                callBackWait(mainPackageList);
            }
        }
    }

    function createFieldObject(field, array, index) {
        let name = array[index];

        let chieldField = null;

        if (name in field) {
            chieldField = field[name];
        }
        else {
            let prop = bindPropertyFactory();

            Object.defineProperty(field, name, {
                get: function () {
                    return prop;
                }
            });

            chieldField = prop;
        }

        if (index + 1 < array.length) {
            return createFieldObject(chieldField, array, index + 1);
        }
        else {
            return chieldField;
        }
    }

    function createField(fieldDataList, el, htmlElement, isContent) {
        if (!oObserver.existsWaitFieldBind(item => {
            return item.el === el && item.htmlElement === htmlElement && item.isContent === isContent;
        })) {
            if (fieldDataList.length === 1 && fieldDataList[0].fnCreateFor != null) {
                let fieldData = fieldDataList[0];

                let field = fieldData.object;
                let name = fieldData.fieldName;

                if (name in field) {
                    let _firstChild = document.createElement(SUI_ITEM_TAG);
                    let parentEl = el;

                    while (el.childNodes.length > 0) {
                        _firstChild.appendChild(el.childNodes[0]);
                    }

                    field[name].onAdd(model => {
                        add(model);
                    });

                    field[name].onInsert(model => {
                        let newElement = _firstChild.cloneNode(true);

                        searchBind(newElement, model);

                        parentEl.insertBefore(newElement, parentEl.childNodes[0]);

                        newElement.hashCode = model.getHashCode();
                    });

                    field[name].onRemove(model => {
                        for (var index = parentEl.childNodes.length - 1; index >= 0; index--) {

                            if (parentEl.childNodes[index].hashCode === model.getHashCode()) {
                                parentEl.childNodes[index].remove();
                            }
                        }
                    });

                    field[name].onChange(list => {
                        while (parentEl.firstChild) {
                            parentEl.removeChild(parentEl.firstChild);
                        }

                        if (list.length > 0) {
                            list.forEach(model => {
                                add(model);
                            });
                        }
                    });

                    function add(model) {
                        let newElement = _firstChild.cloneNode(true);

                        searchBind(newElement, model);

                        parentEl.appendChild(newElement);

                        newElement.hashCode = model.getHashCode();
                    }


                    for (let index = 0; index < field[name].length; index++) {
                        add(field[name].get(index));
                    }
                }
                else {
                    field.__addPropGet(name, fieldData.fnCreateFor(el));
                }
            }
            else {

                let fieldHtml = null;
                let isAttribute = null;

                let _template = null;
                let _properties = [];

                //#region Set Value HTML

                if (isContent) {
                    _template = htmlElement.content;
                    htmlElement.content = '';

                    fieldHtml = {
                        get value() {
                            return htmlElement.content;
                        }
                        , set value(v) {
                            htmlElement.content = v;
                        }
                    }
                }
                else {
                    _template = htmlElement.value;
                    htmlElement.value = '';

                    let _attrOrEl = null;
                    let _attributeName = null;

                    if (htmlElement.name in el) {
                        _attrOrEl = el;
                        _attributeName = htmlElement.name;

                        isAttribute = false;
                    }
                    else {
                        _attrOrEl = htmlElement;
                        _attributeName = 'value';
                        isAttribute = true;
                    }

                    if (el.autocomplete !== undefined) {
                        el.autocomplete = "off";
                    }

                    fieldHtml = {
                        get el() {
                            return _attrOrEl;
                        }
                        , get attributeName() {
                            return _attributeName;
                        }
                        , get value() {
                            return _attrOrEl[_attributeName];
                        }
                        , set value(v) {
                            _attrOrEl[_attributeName] = v;
                        }
                    }
                }

                //#endregion

                let onChange = (source, newValue, oldValue) => {
                    setBindValue();
                };

                fieldDataList.forEach(fieldData => {
                    let field = fieldData.object;
                    let name = fieldData.fieldName;
                    
                    let getValue = null;
                    let setValue = null;

                    if (field[name] != null && field[name].getValue !== undefined) {
                        getValue = function () {
                            return field[name].getValue();
                        };

                        setValue = function (v) {
                            field[name].setValue(v);
                        };

                        field[name].onPropertyChange(onChange);
                    }
                    else {
                        getValue = function () {
                            return field[name];
                        };

                        setValue = function (v) {
                            field[name] = v;
                        };

                        field.onPropertyChange(name, onChange);
                    }

                    let property = {
                        get value() {
                            return getValue();
                        }
                        , set value(v) {
                            return setValue(v);
                        }
                        , template: fieldData.template
                        , twoDirect: fieldData.twoDirect
                    }

                    Object.freeze(property);

                    _properties.push(property);
                });

                if (!isContent && _properties.length == 1 && _properties.filter(c => c.twoDirect).length > 0) {
                    let property = _properties[0];

                    if (isAttribute) {
                        oObserver.addChangeEvent(el, fieldHtml.el, fieldHtml.attributeName, () => {
                            property.value = fieldHtml.value;
                        });
                    }
                    else {
                        addEvent(fieldHtml.el, "change", () => {
                            property.value = fieldHtml.value;
                        });
                    }
                }

                function setBindValue() {
                    let value = _template;

                    _properties.forEach(property => {
                        value = value.replace(property.template, property.value);
                    });

                    fieldHtml.value = value;
                }

                setBindValue();
            }
        }
    }

    function searchProperties(element) {
        let properties = [];

        var listTypeArray = [];

        element.querySelectorAll('table[' + SUI_FOR + '], table[' + SUI_PKG + '], table[' + SUI_CUSTOM + ']').forEach(el => {
            let tableAux = document.createElement('TABLE');

            if (el.caption != null) { tableAux.appendChild(el.caption); }
            if (el.tHead != null) { tableAux.appendChild(el.tHead); }
            if (el.tBodies != null) {
                while (el.tBodies.length > 0) {

                    tableAux.appendChild(el.tBodies[0]);
                }
            }
            if (el.tFoot != null) { tableAux.appendChild(el.tFoot); }

            el.tableAux = tableAux;

            fnSearchParentListType(listTypeArray, el);
        });

        element.querySelectorAll('select[' + SUI_ID + ']').forEach(el => {
            el.setAttribute(SUI_SELECT, '');

            fnSearchParentListType(listTypeArray, el);
        });

        let not = ':not(table):not(select):not(optgroup):not(option)';

        element.querySelectorAll('[' + SUI_FOR + ']' + not + ',[' + SUI_PKG + ']' + not + ',[' + SUI_CUSTOM + ']' + not + ',[' + SUI_FOR_BIND + ']' + not).forEach(el => {
            let dataType = getPropertyType(el);

            if (dataType === dataTypeEnum.COLLECTION) {
                let row = document.createElement(SUI_ITEM_TAG);
                
                while (el.childNodes.length > 0) {
                    row.appendChild(el.childNodes[0]);
                }

                el.appendChild(row);
            }

            fnSearchParentListType(listTypeArray, el);
        });
        
        let selSuiId = '[' + SUI_ID + ']:not([' + SUI_FOR + ']):not([' + SUI_PKG + ']):not([' + SUI_CUSTOM + '])' + not;

        element.querySelectorAll(selSuiId).forEach(el => {
            let dataType = getPropertyType(el);

            if (!fnListContains(listTypeArray, el)) {
                createProperty(el, dataType, prop => {
                    properties.push(prop);
                });
            }
        });

        listTypeArray.forEach(item => {
            let result = fnOtherProperties.find(c => c.index === item.dataType);

            if (result != null && result.fn != null) {
                properties.push(result.fn(item.el, item.dataType, item.children));
            }
        });

        return properties;
    }

    function createPackageProperty(el, dataType, children) {
        let properties = [];

        let packageName = getNameAttribute(el);

        children.forEach(item => {
            let fn = fnOtherProperties.find(c => c.index === item.dataType).fn;
            
            properties.push(fn(item.el, item.dataType, item.children));
        });

        let pkg = packageFactory(viewFactory(el, packageName), properties);

        el.removeAttribute(SUI_PKG);

        return createPackageModel(packageName, pkg);
    }

    function createCollectionProperty(el, dataType, children) {
        let name = getNameAttribute(el);

        let collection = null;

        if ((/table/gi).test(el.tagName)) {
            collection = tableFactory(viewFactory(el), el.tableAux);

            delete el.tableAux;
        }
        else {
            let firstChild = el.childNodes[0];

            collection = collectionFactory(viewFactory(el), firstChild);

            el.removeChild(firstChild);
        }

        el.removeAttribute(SUI_FOR);

        return createPackageModel(name, collection);
    }

    function createSelectProperty(el, dataType, children) {
        let name = getNameAttribute(el);
        let select = selectFactory(viewFactory(el));
        
        el.removeAttribute(SUI_SELECT);

        return createPackageModel(name, select);
    }

    function createPropertyChild(el, dataType, children) {
        let propertyModel = null;

        createProperty(el, dataType, model => {
            propertyModel = model;
        });

        return propertyModel;
    }

    function createProperty(el, dataType, callback) {
        let prop = propertyFactory(el, dataType);
        let model = createPackageModel(getNameAttribute(el), prop);

        callback(model);
    }

    function getPropertyType(el) {
        let patt = new RegExp(dataTypeEnum.getValues('|'), 'g');

        for (let index = 0; index < el.attributes.length; index++) {
            let name = el.attributes[index].name;

            if (patt.test(name)) {
                return name;
            }
        }

        return dataTypeEnum.DATA;
    }

    function searchNameAttribute(el) {
        if (el.attributes[SUI_ID] != null) {
            return getNameAttribute(el);
        }
        else {
            return null;
        }
    }

    function getNameAttribute(el) {
        let name = el.attributes[SUI_ID].value;

        el.removeAttribute(SUI_ID);

        let pattern = /^[^A-Za-z$_]*|[^A-Za-z0-9$_]+/gm;

        name = name.replace(/[-.]/g, '_').replace(pattern, "");

        return name.substring(0, 1).toLowerCase() + name.substring(1);
    }

    function getElementHtml(element) {
        if (element !== null && element !== undefined && element.outerHTML) {
            return element.outerHTML;
        }
        else {
            return null;
        }
    }

    function setElementHtml(element, html) {
        let typeStringEqualEmpty = typeof html === 'string' ? html.trim() === '' : false;
        
        if (html !== null && html !== undefined && !typeStringEqualEmpty) {
            if (typeof html === 'string') {
                let resultElement = null;

                let documentXML = null;

                let oDOMParser = new DOMParser();

                documentXML = oDOMParser.parseFromString(html, "text/xml");

                if (isParseError(oDOMParser, documentXML)) {
                    documentXML = oDOMParser.parseFromString('<sui>' + html + '</sui>', "text/xml");
                    
                    resultElement = documentXML.documentElement.childNodes[0];
                }
                else {
                    resultElement = documentXML.documentElement;
                }

                element.append(resultElement);
            }
            else {
                element.append(html);
            }
        }
        else {
            while (element.firstChild) {
                element.removeChild(element.firstChild);
            }            
        }
    }

    function getElementText(element) {
        return element.innerHTML;
    }

    function setElementText(element, v) {
        element.innerHTML = v == null ? '' : v;
    }

    function isParseError(parser, dom) {
        let parsererrorNS = parser.parseFromString('INVALID', 'text/xml').getElementsByTagName("parsererror")[0].namespaceURI;

        return dom.getElementsByTagNameNS(parsererrorNS, 'parsererror').length > 0;
    }

    function getPropertiesElement(element) {
        return searchProperties(element);
    }

    function createBaseTable(source, element, properties) {
        let _vm = viewFactory(element);

        Object.defineProperty(source, '$', {
            get: function () {
                return _vm;
            }
        });

        if (properties != null) {
            if (properties.length === 0) {
                Object.defineProperty(source, 'text', {
                    get: function () {
                        return element.innerText;
                    }
                    , set: function (v) {
                        element.innerText = v;
                    }
                });

                Object.defineProperty(source, 'html', {
                    get: function () {
                        return getElementHtml(element);
                    }
                    , set: function (v) {
                        setElementHtml(element, v);
                    }
                });
            }
            else {
                properties.forEach(item => {
                    (function (src, name, value) {
                        Object.defineProperty(src, name, {
                            get: function () {
                                return value;
                            }
                        });
                    })(source, item.name, item.value);
                });
            }
        }
    }
	
    function addArray(parentEl, list, model) {
        let element = model.$ === undefined ? model.__elCustom : model.$.element;

        parentEl.appendChild(element);

        list.push(model);
	}

    function insertArray(parentEl, list, model) {
        let element = model.$ === undefined ? model.__elCustom : model.$.element;

        parentEl.insertBefore(element, parentEl.childNodes[0]);
		list.unshift(model);
	}

	function removeArray(parentEl, list, start, deleteCount, items, onRemove, onInsert) {
		if (deleteCount == null || deleteCount + start > list.length) { deleteCount = list.length - start; }

		for (let index = (deleteCount - 1) + start; index >= start; index--) {
			parentEl.childNodes[index].remove();
		}

		if (items !== null) {
            list.splice(start, deleteCount).forEach(mdl => {
                if (onRemove != null) {
                    onRemove(mdl);
                }
            });

			for (let index = items.length - 1; index >= 0; index--) {
				let itemModel = items[index];

                let element = itemModel.$ === undefined ? itemModel.__elCustom : itemModel.$.element;

                parentEl.insertBefore(element, parentEl.childNodes[start]);
                list.unshift(itemModel);

                if (onInsert != null) {
                    onInsert(itemModel);
                }
			}
		}
		else {
            list.splice(start, deleteCount).forEach(mdl => {
                if (onRemove != null) {
                    onRemove(mdl);
                }
            });
		}
    }	

    function removeElementArray(model) {
        let element = model.$ === undefined ? model.__elCustom : model.$.element;

        element.parentNode.removeChild(element);
    }

    function sortArray(parentEl, list, compareFn) {
        list.sort(compareFn);

        while (parentEl.childNodes.length > 0) {
            parentEl.childNodes[0].remove();
        }

        list.forEach(model => {
            let element = model.$ === undefined ? model.__elCustom : model.$.element;

            parentEl.appendChild(element);
        });
    }				

    function triggerChangeEvent(eventList, source, newValue, oldValue) {
        for (let index = eventList.length - 1; index >= 0; index--) {
            if (eventList[index] != null) {
                eventList[index](source, newValue, oldValue);
            }
            else {
                eventList.splice(index, 1);
            }
        }
    }

    function triggerChangeEventList(eventList, list) {
        for (let index = eventList.length - 1; index >= 0; index--) {
            if (eventList[index] != null) {
                eventList[index](list);
            }
            else {
                eventList.splice(index, 1);
            }
        }
    }

    function triggerAddEvent(eventList, model) {
        for (let index = eventList.length - 1; index >= 0; index--) {
            if (eventList[index] != null) {
                eventList[index](model);
            }
            else {
                eventList.splice(index, 1);
            }
        }
    }

    function triggerInsertEvent(eventList, model) {
        for (let index = eventList.length - 1; index >= 0; index--) {
            if (eventList[index] != null) {
                eventList[index](model);
            }
            else {
                eventList.splice(index, 1);
            }
        }
    }

    function triggerRemoveEvent(eventList, model) {
        for (let index = eventList.length - 1; index >= 0; index--) {
            if (eventList[index] != null) {
                eventList[index](model);
            }
            else {
                eventList.splice(index, 1);
            }
        }
    }

    function addEvent(el, evt, fn) {
        if (el.addEventListener) {
            el.addEventListener(evt, fn, false);
        }
        else {
            el.attachEvent("on" + evt, fn);
        }
    }

    function getCss(el, propName) {
        return el.style[propName];
    }

    function setCss(el, propName, value) {
        el.style[propName] = value;
    }

    function getPropertiesClass(obj) {
        let list = [];

        while (obj = Reflect.getPrototypeOf(obj)) {
            let keys = Reflect.ownKeys(obj);

            keys.forEach((name) => {

                if (typeof obj[name] !== 'function' && name !== 'constructor' && name[0] !== '_') {
                    list.push(name);
                }

            });
        }

        return list;
    }

    //#endregion

    Object.prototype.hashCode = undefined;

    Object.prototype.getHashCode = (function (id) {
        return function () {
            if (!this.hashCode) {
                this.hashCode = '<hash|#' + (id++) + '>';
            }
            return this.hashCode;
        }
    }(0));


    _root = new Singleton();

    Object.defineProperty(window, '$sui', {
        get: function () {
            return _root;
        }
    });

    oObserver = observerFactory();
})();