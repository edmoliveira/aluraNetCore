let oCanvas = null;
let context = null;

let objectNet = null;

window.onload = () => {
    let elemCanvas = document.querySelector('canvas');

    oCanvas = {
        element: elemCanvas
        , get width() { return this.element.width; }
        , get height() { return this.element.height; }
        , get centerX() { return this.element.width / 2; }
        , get centerY() { return this.element.height / 2; }
        , get area() { return this.element.width * 2 + this.element.height * 2; }
    };

    context = oCanvas.element.getContext('2d');

    objectNet = {
        parent: oCanvas
        , get width() { return this.parent.width * 0.4; }
        , get height() { return this.parent.height * 0.8; }
        , get x() { return this.parent.width / 2 - this.width / 2; }
        , get y() { return this.parent.height / 2 - this.height / 2; }
        , get centerX() { return this.x + this.width / 2; }
        , get centerY() { return this.y + this.height / 2; }
        , get area() { return this.width * 2 + this.height * 2; }
        , mouseOffSet: { canDrag: false, point: null, x: 0, y: 0 }
        , points: []
        , blockMoveInitial: false
    }

    let cols = 8;
    let rows = 10;

    for (let row = 0; row < rows + 1; row++) {
        for (let col = 0; col < cols + 1; col++) {
            let objectPoint = {
                parent: objectNet
                , row: row
                , col: col
                , rows: rows
                , cols: cols
                , addX: 0
                , addY: 0
                , forceX: 0
                , forceY: 0
                , get left() { return this.col - 1 >= 0 ? this.col - 1 : -1; }
                , get right() { return this.col + 1 <= this.cols ? this.col + 1 : -1; }
                , get top() { return this.row - 1 >= 0 ? this.row - 1 : -1; }
                , get bottom() { return this.row + 1 <= this.rows ? this.row + 1 : -1; }
                , get radius() { return this.parent.area * 0.0025; }
                , get separateWidth() { return this.parent.width / this.cols; }
                , get separateHeight() { return this.parent.height / this.rows; }
                , get centerOrigX() { return this.parent.x + this.separateWidth * this.col; }
                , get centerOrigY() { return this.parent.y + this.separateHeight * this.row; }
                , get centerX() { return (this.parent.x + this.separateWidth * this.col) + this.addX; }
                , get centerY() { return (this.parent.y + this.separateHeight * this.row) + this.addY; }
                , get x() { return this.centerX - this.radius; }
                , get y() { return this.centerY - this.radius; }
                , get width() { return this.radius * 2; }
                , get height() { return this.radius * 2; }
                , search: (offSetX, offSetY, self) => {
                    if (self == null) { self = this; }

                    return (offSetX >= self.x
                        && offSetX <= self.x + self.width
                        && offSetY >= self.y
                        && offSetY <= self.y + self.height
                    );
                }
                , moveBack: (elapsedTime, self) => {
                    if (self == null) { self = this; }
                    
                    if (self.centerOrigX > self.centerX) {
                        self.addX += self.forceX * elapsedTime;

                        if (self.centerOrigX <= self.centerX) {
                            self.addX = 0;
                        }
                    }
                    else {
                        self.addX -= self.forceX * elapsedTime;

                        if (self.centerOrigX >= self.centerX) {
                            self.addX = 0;
                        }
                    }
                    
                    if (self.centerOrigY > self.centerY) {
                        self.addY += self.forceY * elapsedTime;

                        if (self.centerOrigY <= self.centerY) {
                            self.addY = 0;
                        }
                    }
                    else {
                        self.addY -= self.forceY * elapsedTime;

                        if (self.centerOrigY >= self.centerY) {
                            self.addY = 0;
                        }
                    }
                }
                , move: (addX, addY, self, canBlockBot, canBlockLeft, canBlockRight, canBlockTop) => {
                    if (self == null) { self = this; }

                    self.addX += addX;
                    self.addY += addY;

                    let porcX = Math.abs(self.centerOrigX - self.centerX) / self.centerOrigX;
                    let porcY = Math.abs(self.centerOrigY - self.centerY) / self.centerOrigY;

                    self.forceX = 400 + 300 * porcX;
                    self.forceY = 400 + 300 * porcY;

                    console.log(self.forceX);

                    if (canBlockRight == null || !canBlockRight) {
                        pointFind(self.right, self.row, point => {
                            point.move(addX * 0.9, addY * 0.9, point, true, true, false, true);
                        });
                    }

                    if (canBlockBot == null || !canBlockBot) {
                        pointFind(self.col, self.bottom, point => {
                            point.move(addX * 0.9, addY * 0.9, point, false, false, false, true);
                        });
                    }

                    if (canBlockLeft == null || !canBlockLeft) {
                        pointFind(self.left, self.row, point => {
                            point.move(addX * 0.9, addY * 0.9, point, true, false, true, true);
                        });
                    }

                    if (canBlockTop == null || !canBlockTop) {
                        pointFind(self.col, self.top, point => {
                            point.move(addX * 0.9, addY * 0.9, point, true, false, false, false);
                        });
                    }
                }
            }

            objectNet.points.push(objectPoint);
        }
    }

    resize();

    animation();
};

window.onresize = () => {
    resize();
    draw();
};

window.onmousedown = (e) => {
    objectNet.points.filter(value => value.search(e.offsetX, e.offsetY, value)).forEach(item => {
        objectNet.blockMoveInitial = true;

        objectNet.mouseOffSet.point = item;
        objectNet.mouseOffSet.x = e.offsetX;
        objectNet.mouseOffSet.y = e.offsetY;
        objectNet.mouseOffSet.canDrag = true;
    });
};

window.onmousemove = (e) => {
    let source = objectNet.mouseOffSet;

    if (source.canDrag) {
        source.point.move(e.offsetX - source.x, e.offsetY - source.y, source.point);

        source.x = e.offsetX;
        source.y = e.offsetY;
    }
};

window.onmouseup = (e) => {
    objectNet.blockMoveInitial = false;
    objectNet.mouseOffSet.point = null;
    objectNet.mouseOffSet.x = 0;
    objectNet.mouseOffSet.y = 0;
    objectNet.mouseOffSet.canDrag = false;
};

let lastTime = Date.now();

function animation() {
    var rightNow = Date.now();
    var elapsedTime = (rightNow - lastTime) / 1000;
    lastTime = rightNow;

    if (!objectNet.blockMoveInitial) {
        objectNet.points.filter(item => item.addX !== 0 || item.addY !== 0).forEach(item => {
            item.moveBack(elapsedTime, item);
        });
    }

    clear();
    draw();

    requestAnimationFrame(animation);
}

function resize() {
    let w = window.innerWidth;
    let h = window.innerHeight;

    oCanvas.element.width = w;
    oCanvas.element.height = h;

    oCanvas.element.style.width = w + 'px';
    oCanvas.element.style.height = h + 'px';
}

function clear() {
    oCanvas.element.width = oCanvas.element.width;
}

function draw() {
    //context.strokeStyle = '#FF3333';
    //context.strokeRect(objectNet.x, objectNet.y, objectNet.width, objectNet.height);    
    context.save();

    context.beginPath();
    objectNet.points.forEach(point => {
        context.moveTo(point.centerX, point.centerY);
        context.arc(point.centerX, point.centerY, point.radius, 0, 2 * Math.PI);

    });
    context.fillStyle = '#000000';
    context.fill();
    context.closePath();

    context.lineWidth = objectNet.area * 0.0015;

    context.beginPath();

    objectNet.points.forEach(point => {
        if (point.left !== -1) {
            pointFind(point.left, point.row, pointLeft => {
                context.moveTo(point.centerX, point.centerY);
                context.lineTo(pointLeft.centerX, pointLeft.centerY);
            });
        }

        if (point.top !== -1) {
            pointFind(point.col, point.top, pointTop => {
                context.moveTo(point.centerX, point.centerY);
                context.lineTo(pointTop.centerX, pointTop.centerY);
            });
        }

        context.strokeStyle = '#000000';
        context.stroke();
    });



    context.closePath();

    context.restore();
}

function pointFind(coldIndex, rowIndex, callBack) {
    let point = objectNet.points.find(item => item.col === coldIndex && item.row === rowIndex);
    
    if (callBack != null && point != null && point.constructor !== Array) {
        callBack(point);
    }
}