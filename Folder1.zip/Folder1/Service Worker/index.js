let oCanvas = null;
let context = null;
let lastTime = null;
let oWorker = null;
let offscreen = null;

window.onload = () => {
    let stageCanvas = document.querySelector('#stageCanvas');
    let charactersCanvas = document.querySelector('#charactersCanvas');

    oCanvas = {
        stage: stageCanvas
        , characters: charactersCanvas
        , get width() { return this.element.width; }
        , get height() { return this.element.height; }
        , get centerX() { return this.element.width / 2; }
        , get centerY() { return this.element.height / 2; }
        , get area() { return this.element.width * 2 + this.element.height * 2; }
    };

    context = oCanvas.stage.getContext('2d');
    offscreen = oCanvas.characters.transferControlToOffscreen();
    
    resize();

    oWorker = new Worker('control.js');
    oWorker.postMessage({ canvas: offscreen }, [offscreen]);

    lastTime = Date.now();

    animation();
};

window.onresize = () => {
    resize();

    draw();
};

window.onmousedown = (e) => {

};

window.onmousemove = (e) => {

};

window.onmouseup = (e) => {

};

function animation() {
    var rightNow = Date.now();
    var elapsedTime = (rightNow - lastTime) / 1000;
    lastTime = rightNow;


    clear();
    draw();

    requestAnimationFrame(animation);
}

function resize() {
    let w = window.innerWidth;
    let h = window.innerHeight;

    oCanvas.stage.width = w;
    oCanvas.stage.height = h;

    oCanvas.stage.style.width = w + 'px';
    oCanvas.stage.style.height = h + 'px';
    
}

function clear() {
    oCanvas.element.width = oCanvas.element.width;
}

function draw() {
   
}