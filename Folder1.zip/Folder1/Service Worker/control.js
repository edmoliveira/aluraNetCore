onmessage = function (e) {
    console.log('Worker: Message received from main script');
    var workerResult = 'Result: ' + (e.data[0] * e.data[1]);
    console.log('Worker: Posting message back to main script');
    postMessage(workerResult);
}

class control {
    constructor(canvas) {
        this.__internal__ = new Object();

        this.__internal__.oCanvas = {
            element: canvas
            , context: canvas.getContext('2d')
            , get width() { return this.element.width; }
            , get height() { return this.element.height; }
            , get centerX() { return this.element.width / 2; }
            , get centerY() { return this.element.height / 2; }
            , get area() { return this.element.width * 2 + this.element.height * 2; }
        };

        window.onresize = () => {
            resize();
            draw();
        };

        function resize() {
            let w = window.innerWidth;
            let h = window.innerHeight;

            oCanvas.element.width = w;
            oCanvas.element.height = h;

            oCanvas.element.style.width = w + 'px';
            oCanvas.element.style.height = h + 'px';
        }
    }
}