/*
(async (a = 1, ...b) => ({...b, a, [a]: `${a}`}))();

// New Promise APIs
require('util').promisify;
require('fs').promises;

console.log('Ready');
*/

const { readFile } = require('fs').promises;

async function main() {
	const data = await readFile('C:/Users/eoliveira/Desktop/SimplePastExercises.txt');
	console.log('File data is ', data);
}

main();

console.log('TEST');