<!DOCTYPE html>
<html>
<body>

<canvas id="myCanvas" width="200" height="100" style="border:1px solid #d3d3d3;">
Your browser does not support the HTML5 canvas tag.</canvas>

<script>
async function getImage({
  canvas,
  width,
  height,
  mime = 'image/jpeg',
  quality = 1,
}) {
  return new Promise(resolve => {
    const tmpCanvas = document.createElement('canvas');
    tmpCanvas.width = width;
    tmpCanvas.height = height;

    const ctx = tmpCanvas.getContext('2d');
    ctx.drawImage(
      canvas,
      0,
      0,
      canvas.width,
      canvas.height,
      0,
      0,
      width,
      height,
    );

    tmpCanvas.toBlob(resolve, mime, quality);
  });
}

async function load(){

var canvas = document.getElementById("myCanvas");
const photo = await getImage({canvas , width: 4096, height: 4096 });


  
  var link = document.createElement("a");
  link.download = "image.png";

    link.href = URL.createObjectURL(photo);

  link.click();
  
}

load();
</script>

</body>
</html>
