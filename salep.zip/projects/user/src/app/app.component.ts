import { Component } from '@angular/core';
import { ConfigurationService } from '../../../shared/services/configuration-service';
import { environment } from '../environments/environment';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  constructor(configService: ConfigurationService) {
    configService.setConfiguration(environment.production);
  }
  //public getRouterOutletState(outlet) {
  //  return outlet.isActivated ? outlet.activatedRoute : '';
  //}
}
