import { MatInput } from '@angular/material';
import { coerceBooleanProperty } from '@angular/cdk/coercion';

export function fixMatInputRequiredAsterisk() {
  Object.defineProperty(MatInput.prototype, 'required', {
    get: function (): boolean {
      if (this._required) {
        return this._required;
      }

      if (this.ngControl && this.ngControl.control && this.ngControl.control.validator) {
        const emptyValueControl = Object.assign({}, this.ngControl.control);
        (emptyValueControl as any).value = null;
        return 'required' in (this.ngControl.control.validator(emptyValueControl) || {});
      }
      return false;
    },
    set: function (value: boolean) {
      this._required = coerceBooleanProperty(value);
    }
  });
}
