import { AbstractControl, ValidatorFn } from '@angular/forms';
import { MessageValidator } from '../models/message-validator';

export class CustomValidators {
  static required(message: string): ValidatorFn {
    return (control: AbstractControl): MessageValidator => {
      return control.value == null || !/\S+/.test(control.value) ? new MessageValidator(message) : null;
    }
  }

  static requiredTrue(message: string): ValidatorFn {
    return (control: AbstractControl): MessageValidator => {
      return control.value !== true ? new MessageValidator(message) : null;
    }
  }

  static email(message: string): ValidatorFn {
    return (control: AbstractControl): MessageValidator => {
      const value = (control.value as string);
      const pattern: RegExp = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

      return control.value != null && value !== '' && !pattern.test(value) ? new MessageValidator(message) : null;
    }
  }

  static minLength(minLength: number, message: string): ValidatorFn {
    return (control: AbstractControl): MessageValidator => {
      const value = (control.value as string);

      return control.value != null && value !== '' && value.length < minLength ? new MessageValidator(message) : null;
    }
  }

  static maxLength(maxLength: number, message: string): ValidatorFn {
    return (control: AbstractControl): MessageValidator => {
      const value = (control.value as string);

      return control.value != null && value !== '' && value.length > maxLength ? new MessageValidator(message) : null;
    }
  }

  static pattern(pattern: string | RegExp, message: string): ValidatorFn {
    return (control: AbstractControl): MessageValidator => {
      const value = (control.value as string);
      const test = pattern instanceof RegExp ? () => {
        const patt = pattern as RegExp;

        return patt.test(value)
      } : () => {
        const patt = pattern as string;

        return value.match(patt);
      };

      return control.value != null && value !== '' && !test() ? new MessageValidator(message) : null;
    }
  }
}
