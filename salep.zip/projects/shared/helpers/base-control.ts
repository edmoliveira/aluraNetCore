import { BaseApplication } from "./base-application";
import { FormGroup } from "@angular/forms";
import { EventEmitter, Input, Output } from '@angular/core';
import { ItemList } from '../models/item-list';
import { FormControlStatus } from '../models/enumerators';

export abstract class BaseControl<TAplication> {
  @Input()
  formTitle: string;

  protected formGroup: FormGroup;
  protected application: BaseApplication<TAplication>;
  protected properties: TAplication;
  
  @Output()
  onLoadApplication: EventEmitter<BaseApplication<TAplication>>;

  @Output()
  onInitialize: EventEmitter<BaseApplication<TAplication>>;

  @Output()
  onStatusChanges: EventEmitter<FormControlStatus>;

  constructor() {
    this.onLoadApplication = new EventEmitter<BaseApplication<TAplication>>();
    this.onInitialize = new EventEmitter<BaseApplication<TAplication>>();
    this.onStatusChanges = new EventEmitter<FormControlStatus>();
  }

  protected initialize(application: BaseApplication<TAplication>) {
    this.application = application;
    this.properties = this.application.properties;

    this.onLoadApplication.emit(this.application);

    this.formGroup = this.application.createFormGroup();

    this.setFormControlStatus(this.formGroup.status);

    this.formGroup.statusChanges.subscribe(newStatus => {
      this.setFormControlStatus(newStatus);
    });

    this.formGroup.valueChanges.subscribe(() => {
      this.setFormControlStatus(this.formGroup.status);
    });

    this.onInitialize.emit(this.application);
  }

  protected displayItemList(item?: ItemList): string | undefined {
    return item ? item.description : undefined;
  }

  private setFormControlStatus(status: string) {
    let controlStatus: FormControlStatus;

    switch (status) {
      case 'VALID':
        controlStatus = FormControlStatus.Valid;
        break;
      case 'INVALID':
        controlStatus = FormControlStatus.Invalid;
        break;
      case 'DISABLED':
        controlStatus = FormControlStatus.Disabled;
        break;
      case 'PENDING':
        controlStatus = FormControlStatus.Pending;
        break;
    }

    this.onStatusChanges.emit(controlStatus);
    (<any>this.application).setStatusChanges(controlStatus);
  }
}
