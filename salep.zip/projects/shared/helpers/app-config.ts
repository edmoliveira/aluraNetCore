import { ServicesUrlConfig } from '../models/services-url-config';
import { EnvironmentConfig } from '../models/base-service-url-config';

export class AppConfig
{
    static ServiceUrls = class
    {
      private static _userLoginUrl: string;

      static initialize(baseServiceUrl: EnvironmentConfig, servicesUrl:ServicesUrlConfig) {

      }
    };
}
