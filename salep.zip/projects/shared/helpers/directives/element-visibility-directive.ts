import { Directive, ElementRef, Input, OnInit, Renderer2 } from '@angular/core';
import { ElementVisibility } from '../../models/controls/element-visibility';

@Directive({
  selector: '[visibility]'
})
export class ElementVisibilityDirective implements OnInit {
  @Input()
  set visibility(display: ElementVisibility) {
    display.onHidden.subscribe({
      next: (hidden: boolean) => {
        this.onHidden(hidden);
      }
    });

    display.onInvisible.subscribe({
      next: (invisible: boolean) => {
        this.onInvisible(invisible);
      }
    });

    this.onHidden(display.hidden);
    this.onInvisible(display.invisible);
  }

  constructor(private renderer: Renderer2, private elementRef: ElementRef) {
    this.addClass('el-visibility');
  }

  ngOnInit() {


  }

  private onHidden(hidden: boolean) {
    if (hidden) {
      this.addClass('el-display-none');
    }
    else {
      this.removeClass('el-display-none');
    }
  }

  private onInvisible(invisible: boolean) {
    if (invisible) {
      this.toggleClass('el-fade-out', 'el-fade-in');
    }
    else {
      this.toggleClass('el-fade-in', 'el-fade-out');
    }
  }

  private addClass(className: string) {
    this.renderer.addClass(this.elementRef.nativeElement, className);
  }

  private removeClass(className: string) {
    this.renderer.removeClass(this.elementRef.nativeElement, className);
  }

  private toggleClass(newClassName: string, oldClassName: string) {
    this.removeClass(oldClassName);
    this.addClass(newClassName);
  }
}
