import { Directive, ElementRef } from "@angular/core";
import { NgControl } from '@angular/forms';
import { FormControlElement } from '../../models/controls/form-control-element';

@Directive({
  selector: '[formControlName]'
})
export class NativeElementFormControlDirective {
  constructor(
    private ngControl: NgControl,
    private elementRef: ElementRef<HTMLFormElement>) {
  }

  ngOnInit() {
    if (this.ngControl.control && (<any>this.ngControl.control).controlElement) {
      const controlElement = (<any>this.ngControl.control).controlElement as FormControlElement;

      if (controlElement != null) {
        controlElement.setElement(this.elementRef);
      }
    }
  }
}
