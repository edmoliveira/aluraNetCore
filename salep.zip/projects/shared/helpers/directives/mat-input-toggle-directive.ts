import { Directive, ElementRef, Input, OnInit } from '@angular/core';
import { BoolPropertyForm } from '../../models/controls/property-form';

@Directive({
  selector: '[mat-input-toggle]'
})
export class MatInputToggleDirective implements OnInit {
  private propertyFormValue: BoolPropertyForm;

  @Input('mat-input-toggle')
  set propertForm(value: BoolPropertyForm) {
    this.propertyFormValue = value;

    this.propertyFormValue.onChangeReadOnlyLoading.subscribe(() => {
      this.setState();
    });

    this.propertyFormValue.valueChanges.subscribe(() => {
      this.setState();
    });

    this.setState();
  }

  constructor(private elementRef: ElementRef) {
    elementRef.nativeElement.style.visibility = 'hidden';
  }

  ngOnInit() {
    this.setState();
  }

  private setState() {
    const el = this.elementRef.nativeElement;

    if (el != null) {
      if (this.propertyFormValue.disabled || this.propertyFormValue.readOnly || this.propertyFormValue.loadingDisabled) {
        el.setAttribute('disabled', '');
        el.setAttribute('mat-input-disabled', '');
      }
      else {
        el.removeAttribute('disabled');
        el.removeAttribute('mat-input-disabled');
      }
    }
  }
}
