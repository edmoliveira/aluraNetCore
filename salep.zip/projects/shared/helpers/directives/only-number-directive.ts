import { Directive, HostListener, Input, ElementRef } from '@angular/core';

@Directive({
  selector: '[onlyNumber]'
})
export class OnlyNumberDirective {
  private _canNegative: boolean = false;
  private _min: number = -1;

  @Input()
  set canNegative(v: boolean) {
    this._canNegative = v;

    if (!this._canNegative && this._min < 0) {
      this._min = -1;
    }
  };

  @Input()
  max: number = -1;

  @Input()
  set min(v: number) {
    this._min = v;

    if (this._min < 0) {
      this._canNegative = true;
    }
  };

  constructor(private elementRef: ElementRef) { }

  @HostListener('keypress', ['$event'])
  onKeyPress(event: KeyboardEvent) {
    this.validate(event, event.key === 'Enter' ? '\n' : event.key);
  }

  @HostListener('paste', ['$event'])
  onPaste(event: Event) {
    const pastedText = (<any>window).clipboardData && (<any>window).clipboardData.getData('Text')
      || <ClipboardEvent>event && (<ClipboardEvent>event).clipboardData.getData('text/plain');
    this.validate(event, pastedText);
  }

  @HostListener('cut', ['$event'])
  onCut(event: Event) {
    this.validate(event, '');
  }

  validate(event: Event, text: string) {
    const txtInput = this.elementRef.nativeElement;
    const newValue = (txtInput.value.substring(0, txtInput.selectionStart) + text + txtInput.value.substring(txtInput.selectionEnd));

    const regex = <RegExp>eval(`/^${(this.canNegative ? '-?' : '')}\\d*$/g`);

    if (!newValue.match(regex)) {
      event.preventDefault();
      return;
    }
  }
}
