import { Directive, ElementRef } from '@angular/core';
import { MatSelect } from '@angular/material/select';

@Directive({
  selector: 'mat-select'
})
export class MatSelectDirective {
  constructor(elementRef: ElementRef, host: MatSelect) {
    let canDisabled = false;

    const observer: MutationObserver = new MutationObserver(
      list => {
        for (const record of list) {
          if (record && record.attributeName == 'mat-input-disabled') {
            if (!host.disabled && !canDisabled) {
              canDisabled = true;
              host.setDisabledState(true);
            }
            else if (canDisabled && elementRef.nativeElement.attributes['mat-input-disabled'] === undefined) {
              canDisabled = false;
              host.setDisabledState(false);
            }
          }
        }
      }
    );

    observer.observe(elementRef.nativeElement, {
      attributes: true,
    });
  }
}
