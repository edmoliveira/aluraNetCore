import { MatInput, MatFormField } from '@angular/material';
import { ElementRef, Directive } from '@angular/core';

@Directive({
  selector: '[matInput]'
})
export class MatInputDirective {
  constructor(private elementRef: ElementRef, private matInput: MatInput, private matFormField: MatFormField) {
    let canDisabled = false;

    const observer: MutationObserver = new MutationObserver(
      list => {
        for (const record of list) {
          if (record && record.attributeName == 'mat-input-disabled') {
            if (!matInput.disabled && !canDisabled) {
              canDisabled = true;

              matFormField._elementRef.nativeElement.classList.add('mat-form-field-disabled');
              console.log('enter');
            }
            else if (canDisabled && elementRef.nativeElement.attributes['mat-input-disabled'] === undefined) {
              console.log('exit');
              console.log(elementRef.nativeElement.attributes);
              canDisabled = false;

              if (!matInput.disabled) {
                matFormField._elementRef.nativeElement.classList.remove('mat-form-field-disabled');
              }
            }
          }
        }
      }
    );

    observer.observe(elementRef.nativeElement, {
      attributes: true,
    });
  }
}
