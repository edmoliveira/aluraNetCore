import { Directive, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[custom-container]',
})
export class CustomContainerDirective {
  constructor(public viewContainerRef: ViewContainerRef) { }
}
