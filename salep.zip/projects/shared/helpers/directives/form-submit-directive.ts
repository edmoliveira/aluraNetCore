import { SubmitPropertyForm } from '../../models/controls/submit-property-form';
import { FormControlElement } from '../../models/controls/form-control-element';
import { ElementRef, Directive, Input, Renderer2 } from '@angular/core';

@Directive({
  selector: '[formSubmit]'
})
export class FormSubmitDirective {
  @Input()
  formSubmit: SubmitPropertyForm;

  private removeClickEvent: () => void;

  constructor(
    private renderer: Renderer2
    , private elementRef: ElementRef<HTMLFormElement>) {
  }

  ngOnInit() {
    this.removeClickEvent = this.renderer.listen(this.elementRef.nativeElement, 'click', event => {
      (<any>this.formSubmit).triggerClickEvent(event);
    });

    const controlElement = (<any>this.formSubmit).controlElement as FormControlElement;

    if (controlElement != null) {
      controlElement.setElement(this.elementRef);
    }
  }

  ngOnDestroy() {
    this.removeClickEvent();
  }
}
