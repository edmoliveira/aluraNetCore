import { Directive, ElementRef } from "@angular/core";
import { ControlContainer } from '@angular/forms';
import { FormControlElement } from '../../models/controls/form-control-element';

@Directive({
  selector: '[formGroupName]'
})
export class NativeElementFormGroupDirective {
  constructor(
    private formGroup: ControlContainer,
    private elementRef: ElementRef<HTMLFormElement>) {
  }

  ngOnInit() {
    if (this.formGroup.control && (<any>this.formGroup.control).controlElement) {
      const controlElement = (<any>this.formGroup.control).controlElement as FormControlElement;

      if (controlElement != null) {
        controlElement.setElement(this.elementRef);
      }
    }
  }
}
