"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var BaseControl = /** @class */ (function () {
    function BaseControl() {
        this.onInitialize = new core_1.EventEmitter();
        this.onLoadApplication = new core_1.EventEmitter();
    }
    BaseControl.prototype.initialize = function (application) {
        this.application = application;
        this.properties = this.application.properties;
        this.onLoadApplication.emit(this.application);
        this.formGroup = this.application.createFormGroup();
        this.onInitialize.emit();
    };
    BaseControl.prototype.displayItemList = function (item) {
        return item ? item.description : undefined;
    };
    return BaseControl;
}());
exports.BaseControl = BaseControl;
//# sourceMappingURL=base-control.js.map