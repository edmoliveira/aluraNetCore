"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var message_validator_1 = require("../models/message-validator");
var CustomValidators = /** @class */ (function () {
    function CustomValidators() {
    }
    CustomValidators.keyMessage = function (key) {
        return {
            name: key, message: function (message) {
                return message;
            }
        };
    };
    CustomValidators.required = function (message) {
        return function (control) {
            return control.value == null || !/\S+/.test(control.value) ? new message_validator_1.MessageValidator(message) : null;
        };
    };
    CustomValidators.requiredTrue = function (message) {
        return function (control) {
            return control.value !== true ? new message_validator_1.MessageValidator(message) : null;
        };
    };
    CustomValidators.email = function (message) {
        return function (control) {
            var value = control.value;
            var pattern = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
            return control.value != null && value !== '' && !pattern.test(value) ? new message_validator_1.MessageValidator(message) : null;
        };
    };
    CustomValidators.minLength = function (minLength, message) {
        return function (control) {
            var value = control.value;
            return control.value != null && value !== '' && value.length < minLength ? new message_validator_1.MessageValidator(message) : null;
        };
    };
    CustomValidators.maxLength = function (maxLength, message) {
        return function (control) {
            var value = control.value;
            return control.value != null && value !== '' && value.length > maxLength ? new message_validator_1.MessageValidator(message) : null;
        };
    };
    CustomValidators.pattern = function (pattern, message) {
        return function (control) {
            var value = control.value;
            var test = pattern instanceof RegExp ? function () {
                var patt = pattern;
                return patt.test(value);
            } : function () {
                var patt = pattern;
                return value.match(patt);
            };
            return control.value != null && value !== '' && !test() ? new message_validator_1.MessageValidator(message) : null;
        };
    };
    return CustomValidators;
}());
exports.CustomValidators = CustomValidators;
//# sourceMappingURL=custom-validators.js.map