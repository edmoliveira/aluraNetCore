"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var BaseApplication = /** @class */ (function () {
    function BaseApplication(formBuilder, properties) {
        this.formBuilder = formBuilder;
        this.onStatusChanges = new core_1.EventEmitter();
        this.properties = properties;
    }
    BaseApplication.prototype.createFormGroup = function () {
        var formGroup = this.formBuilder.group({});
        this.properties.setFormGroup(formGroup);
        for (var propName in this.properties) {
            var prop = this.properties[propName];
            if (prop != null && prop.isPropertyForm) {
                prop.addPropertyForm(formGroup);
            }
        }
        return formGroup;
    };
    BaseApplication.prototype.disable = function () {
        this["disabled"] = true;
        for (var propName in this.properties) {
            var prop = this.properties[propName];
            if (prop.isPropertyForm) {
                prop.disable();
            }
        }
    };
    BaseApplication.prototype.enable = function () {
        this["disabled"] = false;
        for (var propName in this.properties) {
            var prop = this.properties[propName];
            if (prop.isPropertyForm) {
                prop.enable();
            }
        }
    };
    BaseApplication.prototype.setReadOnly = function (value) {
        this["readOnly"] = value;
        for (var propName in this.properties) {
            var prop = this.properties[propName];
            if (prop.isPropertyForm) {
                prop.setReadOnly(this.readOnly);
            }
        }
    };
    BaseApplication.prototype.setLoading = function (value) {
        this["loading"] = value;
        for (var propName in this.properties) {
            var prop = this.properties[propName];
            if (prop.isPropertyForm) {
                prop.setLoading(this.loading, true);
            }
        }
    };
    BaseApplication.prototype.setStatusChanges = function (status) {
        this.onStatusChanges.emit(status);
    };
    return BaseApplication;
}());
exports.BaseApplication = BaseApplication;
//# sourceMappingURL=base-application.js.map