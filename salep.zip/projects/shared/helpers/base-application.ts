import { FormBuilder } from "@angular/forms";
import { IPropertyForm } from '../interfaces/iproperty-form';
import { EventEmitter } from '@angular/core';
import { FormControlStatus } from "../models/enumerators";

export abstract class BaseApplication<T> {
  readonly disabled: boolean;
  readonly readOnly: boolean;
  readonly loading: boolean;
  readonly properties: T;

  onStatusChanges: EventEmitter<FormControlStatus>;

  constructor(protected formBuilder: FormBuilder, properties: T) {
    this.onStatusChanges = new EventEmitter<FormControlStatus>();

    this.properties = properties;
  }

  createFormGroup() {
    let formGroup = this.formBuilder.group({});

    (<any>this.properties).setFormGroup(formGroup);

    for (const propName in this.properties) {
      const prop = (<any>this.properties[propName]) as IPropertyForm;

      if (prop != null && prop.isPropertyForm) {
        prop.addPropertyForm(formGroup);
      }
    }

    return formGroup;
  }

  disable(): void {
    this["disabled" as any] = true;

    for (const propName in this.properties) {
      const prop = (<any>this.properties[propName]) as IPropertyForm;

      if (prop.isPropertyForm) {
        prop.disable();
      }
    }
  }

  enable(): void {
    this["disabled" as any] = false;

    for (const propName in this.properties) {
      const prop = (<any>this.properties[propName]) as IPropertyForm;

      if (prop.isPropertyForm) {
        prop.enable();
      }
    }
  }

  setReadOnly(value: boolean): void {
    this["readOnly" as any] = value;

    for (const propName in this.properties) {
      const prop = (<any>this.properties[propName]) as IPropertyForm;

      if (prop.isPropertyForm) {
        prop.setReadOnly(this.readOnly);
      }
    }
  }

  setLoading(value: boolean): void {
    this["loading" as any] = value;

    for (const propName in this.properties) {
      const prop = (<any>this.properties[propName]) as IPropertyForm;

      if (prop.isPropertyForm) {
        prop.setLoading(this.loading, true);
      }
    }
  }

  private setStatusChanges(status: FormControlStatus) {
    this.onStatusChanges.emit(status);
  }
}
