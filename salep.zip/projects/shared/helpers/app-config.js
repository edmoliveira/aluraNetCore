"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AppConfig = /** @class */ (function () {
    function AppConfig() {
    }
    AppConfig.ServiceUrls = /** @class */ (function () {
        function class_1() {
        }
        class_1.initialize = function (baseServiceUrl, servicesUrl) {
        };
        return class_1;
    }());
    return AppConfig;
}());
exports.AppConfig = AppConfig;
//# sourceMappingURL=app-config.js.map