"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ServiceConfig = /** @class */ (function () {
    function ServiceConfig() {
    }
    return ServiceConfig;
}());
exports.ServiceConfig = ServiceConfig;
//# sourceMappingURL=service-config.js.map