export class BaseServiceUrlConfig {
  production: EnvironmentConfig;
  test: EnvironmentConfig;
}

export class EnvironmentConfig {
  user: string;
}
