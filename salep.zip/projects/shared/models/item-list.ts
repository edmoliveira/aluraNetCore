export class ItemList {
  constructor(
    public code: any
    , public description: string
  ) {

  }
}
