"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var RequireValue = /** @class */ (function () {
    function RequireValue() {
    }
    return RequireValue;
}());
exports.RequireValue = RequireValue;
//# sourceMappingURL=require-value.js.map