export class RequireValue {
  required: boolean;
  requiredFake: boolean;
}
