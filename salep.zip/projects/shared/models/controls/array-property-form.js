"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var ArrayPropertyForm = /** @class */ (function (_super) {
    __extends(ArrayPropertyForm, _super);
    function ArrayPropertyForm() {
        var _this = _super.call(this) || this;
        _this.isPropertyForm = true;
        return _this;
    }
    Object.defineProperty(ArrayPropertyForm.prototype, "hasItems", {
        get: function () {
            return this.length > 0;
        },
        enumerable: true,
        configurable: true
    });
    ArrayPropertyForm.prototype.addItem = function (item, parent) {
        var prop = item;
        if (prop.isPropertyForm) {
            if (this.disabled) {
                prop.disable();
            }
            else {
                prop.enable();
            }
            prop.setReadOnly(this.readOnly);
            prop.addPropertyForm(parent);
        }
        this.push(item);
        return item;
    };
    ArrayPropertyForm.prototype.addPropertyForm = function (parent) {
        this.forEach(function (item) {
            var prop = item;
            if (prop.isPropertyForm) {
                prop.addPropertyForm(parent);
            }
        });
    };
    ArrayPropertyForm.prototype.disable = function () {
        this["disabled"] = true;
        this.forEach(function (item) {
            var prop = item;
            if (prop.isPropertyForm) {
                prop.disable();
            }
        });
    };
    ArrayPropertyForm.prototype.enable = function () {
        this["disabled"] = false;
        this.forEach(function (item) {
            var prop = item;
            if (prop.isPropertyForm) {
                prop.disable();
            }
        });
    };
    ArrayPropertyForm.prototype.setReadOnly = function (value) {
        var _this = this;
        this["readOnly"] = value;
        this.forEach(function (item) {
            var prop = item;
            if (prop.isPropertyForm) {
                prop.setReadOnly(_this.readOnly);
            }
        });
    };
    ArrayPropertyForm.prototype.setLoading = function (value, onlyDisabled) {
        var _this = this;
        if (onlyDisabled === void 0) { onlyDisabled = false; }
        if (!onlyDisabled) {
            this["loading"] = value;
        }
        this["loadingDisabled"] = value;
        this.forEach(function (item) {
            var prop = item;
            if (prop.isPropertyForm) {
                prop.setLoading(_this.loading, true);
            }
        });
    };
    return ArrayPropertyForm;
}(Array));
exports.ArrayPropertyForm = ArrayPropertyForm;
//# sourceMappingURL=array-property-form.js.map