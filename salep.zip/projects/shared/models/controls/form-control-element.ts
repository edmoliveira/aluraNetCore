import { ElementRef } from '@angular/core';

export class FormControlElement {
  private _element: ElementRef<HTMLFormElement>;
  readonly readOnly: boolean;
  readonly disabled: boolean;

  setReadOnly(value: boolean) {
    this["readOnly" as any] = value;
    this.setElementReadOnly();
  }

  setDisabled(value: boolean) {
    this["disabled" as any] = value;
    this.setElementDisabled();
  }

  constructor() {

  }

  setElement(element: ElementRef<HTMLFormElement>) {
    this._element = element;
    this["readOnly" as any] = this.readOnly;
    this["disabled" as any] = this.disabled;

    this.setElementReadOnly();
    this.setElementDisabled();

    setTimeout(() => {
      this.setElementReadOnly();
      this.setElementDisabled();
    }, 1000);
  }

  private setElementReadOnly() {
    if (this._element != null) {
      const el = this._element.nativeElement;

      if (this.readOnly) {
        el.setAttribute('readonly', 'readonly');
      }
      else {
        el.removeAttribute('readonly');
      }
    }
  }

  private setElementDisabled() {
    if (this._element != null) {
      const el = this._element.nativeElement;

      if (this.disabled) {
        el.setAttribute('disabled', '');
        el.setAttribute('mat-input-disabled', '');
      }
      else {
        el.removeAttribute('disabled');
        el.removeAttribute('mat-input-disabled');
      }
    }
  }
}
