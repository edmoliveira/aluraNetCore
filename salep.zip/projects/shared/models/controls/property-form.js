"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var forms_1 = require("@angular/forms");
var form_control_element_1 = require("./form-control-element");
var custom_validators_1 = require("../../helpers/custom-validators");
var element_visibility_1 = require("./element-visibility");
var require_value_1 = require("../require-value");
var core_1 = require("@angular/core");
var PropertyForm = /** @class */ (function (_super) {
    __extends(PropertyForm, _super);
    function PropertyForm(propId, formState, validatorOrOpts, asyncValidator) {
        var _this = _super.call(this, formState, validatorOrOpts, asyncValidator) || this;
        _this.isPropertyForm = true;
        _this.onChangeReadOnlyLoading = new core_1.EventEmitter();
        _this.propId = propId;
        _this.display = new element_visibility_1.ElementVisibility();
        _this.require = new require_value_1.RequireValue();
        _this.controlElement = _this._controlElement = new form_control_element_1.FormControlElement();
        return _this;
    }
    Object.defineProperty(PropertyForm.prototype, "Value", {
        set: function (value) {
            this.setValue(value);
        },
        enumerable: true,
        configurable: true
    });
    PropertyForm.prototype.addPropertyForm = function (parent) {
        parent.addControl(this.propId, this);
    };
    PropertyForm.prototype.hide = function () {
        this["hidden"] = true;
        this.display.hide();
    };
    PropertyForm.prototype.show = function () {
        this["hidden"] = false;
        this.display.show();
    };
    PropertyForm.prototype.fadeOut = function () {
        this["invisible"] = true;
        this.display.fadeOut();
    };
    PropertyForm.prototype.fadeIn = function () {
        this["invisible"] = false;
        this.display.fadeIn();
    };
    PropertyForm.prototype.setRequired = function (othersValidator) {
        if (othersValidator === void 0) { othersValidator = null; }
        this.require.required = true;
        var validators = [];
        validators.push(forms_1.Validators.required, custom_validators_1.CustomValidators.required('It cannot be null'));
        if (othersValidator != null) {
            if (othersValidator.forEach) {
                othersValidator.forEach(function (validator) {
                    validators.push(validator);
                });
            }
            else {
                validators.push(othersValidator);
            }
        }
        this.setValidators(validators);
    };
    PropertyForm.prototype.setReadOnly = function (value) {
        this["readOnly"] = value;
        this._controlElement.setReadOnly(value);
        this.onChangeReadOnlyLoading.emit();
    };
    PropertyForm.prototype.setLoading = function (value, onlyDisabled) {
        if (onlyDisabled === void 0) { onlyDisabled = false; }
        if (!onlyDisabled) {
            this["loading"] = value;
        }
        this["loadingDisabled"] = value;
        if (value && !this.disabled) {
            this._controlElement.setDisabled(true);
        }
        else if (!this.disabled) {
            this._controlElement.setDisabled(false);
        }
        this.onChangeReadOnlyLoading.emit();
    };
    PropertyForm.prototype.setRequiredFake = function (required) {
        this.require.requiredFake = required;
    };
    PropertyForm.prototype.valueIsNull = function () {
        return this.value == null;
    };
    return PropertyForm;
}(forms_1.FormControl));
exports.PropertyForm = PropertyForm;
var StringPropertyForm = /** @class */ (function (_super) {
    __extends(StringPropertyForm, _super);
    function StringPropertyForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Object.defineProperty(StringPropertyForm.prototype, "Value", {
        /** Don't use in HTML, use "value". */
        get: function () {
            return this.value;
        },
        set: function (value) {
            this.setValue(value);
        },
        enumerable: true,
        configurable: true
    });
    StringPropertyForm.prototype.valueToString = function () {
        return !this.valueIsNull() ? this.value : '';
    };
    return StringPropertyForm;
}(PropertyForm));
exports.StringPropertyForm = StringPropertyForm;
var BoolPropertyForm = /** @class */ (function (_super) {
    __extends(BoolPropertyForm, _super);
    function BoolPropertyForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Object.defineProperty(BoolPropertyForm.prototype, "Value", {
        /** Don't use in HTML, use "value". */
        get: function () {
            return this.value;
        },
        set: function (value) {
            this.setValue(value);
        },
        enumerable: true,
        configurable: true
    });
    BoolPropertyForm.prototype.valueToString = function () {
        return !this.valueIsNull() ? this.value.toString() : '';
    };
    return BoolPropertyForm;
}(PropertyForm));
exports.BoolPropertyForm = BoolPropertyForm;
var DatePropertyForm = /** @class */ (function (_super) {
    __extends(DatePropertyForm, _super);
    function DatePropertyForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Object.defineProperty(DatePropertyForm.prototype, "Value", {
        /** Don't use in HTML, use "value". */
        get: function () {
            return this.value;
        },
        set: function (value) {
            this.setValue(value);
        },
        enumerable: true,
        configurable: true
    });
    DatePropertyForm.prototype.valueToString = function () {
        return !this.valueIsNull() ? this.value.toString() : '';
    };
    return DatePropertyForm;
}(PropertyForm));
exports.DatePropertyForm = DatePropertyForm;
var NumberPropertyForm = /** @class */ (function (_super) {
    __extends(NumberPropertyForm, _super);
    function NumberPropertyForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Object.defineProperty(NumberPropertyForm.prototype, "Value", {
        /** Don't use in HTML, use "value". */
        get: function () {
            return this.value;
        },
        set: function (value) {
            this.setValue(value);
        },
        enumerable: true,
        configurable: true
    });
    NumberPropertyForm.prototype.valueToString = function () {
        return !this.valueIsNull() ? this.value.toString() : '';
    };
    return NumberPropertyForm;
}(PropertyForm));
exports.NumberPropertyForm = NumberPropertyForm;
var GenericPropertyForm = /** @class */ (function (_super) {
    __extends(GenericPropertyForm, _super);
    function GenericPropertyForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Object.defineProperty(GenericPropertyForm.prototype, "Value", {
        /** Don't use in HTML, use "value". */
        get: function () {
            return this.value;
        },
        set: function (value) {
            this.setValue(value);
        },
        enumerable: true,
        configurable: true
    });
    return GenericPropertyForm;
}(PropertyForm));
exports.GenericPropertyForm = GenericPropertyForm;
//# sourceMappingURL=property-form.js.map