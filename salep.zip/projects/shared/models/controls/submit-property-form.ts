import { FormGroup } from "@angular/forms";
import { FormControlElement } from './form-control-element';
import { BasePropertyForm } from './base-property-form';
import { IPropertyForm } from '../../interfaces/iproperty-form';
import { EventEmitter } from '@angular/core';

export class SubmitPropertyForm extends BasePropertyForm implements IPropertyForm {
  readonly isPropertyForm: boolean = true;

  private controlElement: FormControlElement;
  readonly disabled: boolean;
  readonly readOnly: boolean;
  readonly loading: boolean;
  readonly loadingDisabled: boolean;

  onClick: EventEmitter<any>;

  constructor(propId: string) {
    super(propId);
    this.controlElement = new FormControlElement();
    this.onClick = new EventEmitter<any>();
  }

  addPropertyForm(parent: FormGroup): void {
    //empty
  }

  disable(): void {
    this["disabled" as any] = true;
    this.controlElement.setDisabled(this.disabled);
  }

  enable(): void {
    this["disabled" as any] = false;
    this.controlElement.setDisabled(this.disabled);
  }

  setReadOnly(value: boolean): void {
    this["readOnly" as any] = value;
    this.controlElement.setReadOnly(value);
  }

  setLoading(value: boolean, onlyDisabled: boolean = false): void {
    if (!onlyDisabled) {
      this["loading" as any] = value;
    }

    this["loadingDisabled" as any] = value;

    if (value && !this.disabled) {
      this.controlElement.setDisabled(true);
    }
    else if (!this.disabled) {
      this.controlElement.setDisabled(false);
    }
  }

  private triggerClickEvent(event: any): void {
    this.onClick.emit(event);
  }
}
