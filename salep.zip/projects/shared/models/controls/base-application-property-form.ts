import { FormGroup } from '@angular/forms';

export abstract class BaseApplicationPropertyForm {
  private _formGroup: FormGroup;

  get formGroup(): FormGroup {
    return this._formGroup;
  }

  private setFormGroup(value: FormGroup) {
    this._formGroup = value;
  }
} 
