"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ElementVisibility = /** @class */ (function () {
    function ElementVisibility() {
        this.onHidden = new core_1.EventEmitter();
        this.onInvisible = new core_1.EventEmitter();
    }
    ElementVisibility.prototype.hide = function () {
        this["hidden"] = true;
        this.onHidden.emit(this.hidden);
    };
    ElementVisibility.prototype.show = function () {
        this["hidden"] = false;
        this.onHidden.emit(this.hidden);
    };
    ElementVisibility.prototype.fadeOut = function () {
        this["invisible"] = true;
        this.onInvisible.emit(this.invisible);
    };
    ElementVisibility.prototype.fadeIn = function () {
        this["invisible"] = false;
        this.onInvisible.emit(this.invisible);
    };
    return ElementVisibility;
}());
exports.ElementVisibility = ElementVisibility;
//# sourceMappingURL=element-visibility.js.map