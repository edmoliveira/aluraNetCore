import { FormGroup, FormBuilder } from "@angular/forms";
import { FormControlElement } from './form-control-element';
import { BasePropertyForm } from './base-property-form';
import { IPropertyForm } from '../../interfaces/iproperty-form';

export class PropertyFormGroup extends BasePropertyForm implements IPropertyForm {
  readonly isPropertyForm: boolean = true;

  private _formGroup: FormGroup;
  private _controlElement: FormControlElement;
  readonly disabled: boolean;
  readonly readOnly: boolean;
  readonly loading: boolean;
  readonly loadingDisabled: boolean;

  private _properties: Array<IPropertyForm>;

  get formGroup(): FormGroup {
    return this._formGroup;
  }

  constructor(propId: string, protected formBuilder: FormBuilder) {
    super(propId);
    this._formGroup = this.formBuilder.group({});
    (<any>this._formGroup).controlElement = this._controlElement = new FormControlElement();
    this._properties = new Array<IPropertyForm>();
  }

  addPropertyForm(parent: FormGroup): void {
    parent.addControl(this.propId, this.formGroup);
  }

  disable(): void {
    this["disabled" as any] = true;

    this._properties.forEach(item => {
      item.disable();
    });
  }

  enable(): void {
    this["disabled" as any] = false;

    this._properties.forEach(item => {
      item.enable();
    });
  }

  setReadOnly(value: boolean): void {
    this["readOnly" as any] = value;

    this._properties.forEach(item => {
      item.setReadOnly(this.readOnly);
    });
  }

  setLoading(value: boolean, onlyDisabled: boolean = false): void {
    if (!onlyDisabled) {
      this["loading" as any] = value;
    }

    this["loadingDisabled" as any] = value;

    this._properties.forEach(item => {
      item.setLoading(this.loading, true);
    });
  }

  protected addProperties() {
    const pattern = /_disabled|_readOnly|_loading|isPropertyForm|_formGroup|_controlElement|_properties|disabled|readOnly|loading/gi;

    for (const propName in this) {
      if (!pattern.test(propName)) {
        const prop = (<any>this[propName]) as IPropertyForm;

        if (prop.isPropertyForm) {
          prop.addPropertyForm(this._formGroup);
          this._properties.push(prop);
        }
      }
    }
  }
}
