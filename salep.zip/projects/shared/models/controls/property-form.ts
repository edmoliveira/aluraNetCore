import { FormControl, Validators, FormGroup, ValidatorFn, AbstractControlOptions, AsyncValidatorFn } from '@angular/forms';
import { FormControlElement } from './form-control-element';
import { CustomValidators } from '../../helpers/custom-validators';
import { IPropertyForm } from '../../interfaces/iproperty-form';
import { ElementVisibility } from './element-visibility';
import { RequireValue } from '../require-value';
import { EventEmitter } from '@angular/core';

export class PropertyForm extends FormControl implements IPropertyForm {
  readonly isPropertyForm: boolean = true;
  readonly propId: string;
  readonly display: ElementVisibility;
  readonly hidden: boolean;
  readonly invisible: boolean;
  readonly readOnly: boolean;
  readonly loading: boolean;
  readonly loadingDisabled: boolean;
  readonly require: RequireValue;

  private _controlElement: FormControlElement;

  onChangeReadOnlyLoading = new EventEmitter();

  set Value(value: any) {
    this.setValue(value);
  }

  constructor(propId: string, formState?: any, validatorOrOpts?: ValidatorFn | ValidatorFn[] | AbstractControlOptions | null, asyncValidator?: AsyncValidatorFn | AsyncValidatorFn[] | null) {
    super(formState, validatorOrOpts, asyncValidator);
    this.propId = propId;
    this.display = new ElementVisibility();
    this.require = new RequireValue();
    (<any>this).controlElement = this._controlElement = new FormControlElement();
  }

  addPropertyForm(parent: FormGroup): void {
    parent.addControl(this.propId, this);
  }

  hide(): void {
    this["hidden" as any] = true;
    this.display.hide();
  }

  show(): void {
    this["hidden" as any] = false;
    this.display.show();
  }

  fadeOut(): void {
    this["invisible" as any] = true;
    this.display.fadeOut();
  }

  fadeIn(): void {
    this["invisible" as any] = false;
    this.display.fadeIn();
  }

  setRequired(othersValidator: ValidatorFn | ValidatorFn[] | null = null): void {
    this.require.required = true;

    let validators = [];

    validators.push(Validators.required, CustomValidators.required('It cannot be null'));

    if (othersValidator != null) {
      if ((<any>othersValidator).forEach) {
        (<any>othersValidator).forEach(validator => {
          validators.push(validator);
        });
      }
      else {
        validators.push(othersValidator);
      }
    }

    this.setValidators(validators);
  }

  setReadOnly(value: boolean): void {
    this["readOnly" as any] = value;
    this._controlElement.setReadOnly(value);

    this.onChangeReadOnlyLoading.emit();
  }

  setLoading(value: boolean, onlyDisabled: boolean = false): void {
    if (!onlyDisabled) {
      this["loading" as any] = value;
    }

    this["loadingDisabled" as any] = value;

    if (value && !this.disabled) {
      this._controlElement.setDisabled(true);
    }
    else if (!this.disabled) {
      this._controlElement.setDisabled(false);
    }

    this.onChangeReadOnlyLoading.emit();
  }

  setRequiredFake(required: boolean): void {
    this.require.requiredFake = required;
  }

  valueIsNull(): boolean {
    return this.value == null;
  }
}

export class StringPropertyForm extends PropertyForm {
  /** Don't use in HTML, use "value". */
  get Value(): string {
    return this.value;
  }

  set Value(value: string) {
    this.setValue(value);
  }

  valueToString() {
    return !this.valueIsNull() ? this.value : '';
  }
}

export class BoolPropertyForm extends PropertyForm {

  /** Don't use in HTML, use "value". */
  get Value(): boolean {
    return this.value;
  }

  set Value(value: boolean) {
    this.setValue(value);
  }

  valueToString() {
    return !this.valueIsNull() ? this.value.toString() : '';
  }
}

export class DatePropertyForm extends PropertyForm {
  /** Don't use in HTML, use "value". */
  get Value(): Date {
    return this.value;
  }

  set Value(value: Date) {
    this.setValue(value);
  }

  valueToString() {
    return !this.valueIsNull() ? this.value.toString() : '';
  }
}

export class NumberPropertyForm extends PropertyForm {
  /** Don't use in HTML, use "value". */
  get Value(): number {
    return this.value;
  }

  set Value(value: number) {
    this.setValue(value);
  }

  valueToString() {
    return !this.valueIsNull() ? this.value.toString() : '';
  }
}

export class GenericPropertyForm<T> extends PropertyForm {
  /** Don't use in HTML, use "value". */
  get Value(): T {
    return this.value;
  }

  set Value(value: T) {
    this.setValue(value);
  }
}
