"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var FormControlElement = /** @class */ (function () {
    function FormControlElement() {
    }
    FormControlElement.prototype.setReadOnly = function (value) {
        this["readOnly"] = value;
        this.setElementReadOnly();
    };
    FormControlElement.prototype.setDisabled = function (value) {
        this["disabled"] = value;
        this.setElementDisabled();
    };
    FormControlElement.prototype.setElement = function (element) {
        var _this = this;
        this._element = element;
        this["readOnly"] = this.readOnly;
        this["disabled"] = this.disabled;
        this.setElementReadOnly();
        this.setElementDisabled();
        setTimeout(function () {
            _this.setElementReadOnly();
            _this.setElementDisabled();
        }, 1000);
    };
    FormControlElement.prototype.setElementReadOnly = function () {
        if (this._element != null) {
            var el = this._element.nativeElement;
            if (this.readOnly) {
                el.setAttribute('readonly', 'readonly');
            }
            else {
                el.removeAttribute('readonly');
            }
        }
    };
    FormControlElement.prototype.setElementDisabled = function () {
        if (this._element != null) {
            var el = this._element.nativeElement;
            if (this.disabled) {
                el.setAttribute('disabled', '');
                el.setAttribute('mat-input-disabled', '');
            }
            else {
                el.removeAttribute('disabled');
                el.removeAttribute('mat-input-disabled');
            }
        }
    };
    return FormControlElement;
}());
exports.FormControlElement = FormControlElement;
//# sourceMappingURL=form-control-element.js.map