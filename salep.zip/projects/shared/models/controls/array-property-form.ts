import { FormGroup } from "@angular/forms";
import { IPropertyForm } from '../../interfaces/iproperty-form';

export class ArrayPropertyForm<T> extends Array<T> implements IPropertyForm {
  readonly isPropertyForm: boolean = true;
  readonly disabled: boolean;
  readonly readOnly: boolean;
  readonly loading: boolean;
  readonly loadingDisabled: boolean;

  constructor() {
    super();
  }

  get hasItems(): boolean {
    return this.length > 0;
  }

  addItem(item: T, parent: FormGroup): T {
    const prop = (<any>item) as IPropertyForm;

    if (prop.isPropertyForm) {
      if (this.disabled) {
        prop.disable();
      }
      else {
        prop.enable();
      }

      prop.setReadOnly(this.readOnly);

      prop.addPropertyForm(parent);
    }

    this.push(item);

    return item;
  }

  addPropertyForm(parent: FormGroup): void {
    this.forEach(item => {
      const prop = (<any>item) as IPropertyForm;

      if (prop.isPropertyForm) {
        prop.addPropertyForm(parent);
      }
    });
  }

  disable(): void {
    (<any>this["disabled" as any]) = true;

    this.forEach(item => {
      const prop = (<any>item) as IPropertyForm;

      if (prop.isPropertyForm) {
        prop.disable();
      }
    });
  }

  enable(): void {
    (<any>this["disabled" as any]) = false;

    this.forEach(item => {
      const prop = (<any>item) as IPropertyForm;

      if (prop.isPropertyForm) {
        prop.disable();
      }
    });
  }

  setReadOnly(value: boolean): void {
    (<any>this["readOnly" as any]) = value;

    this.forEach(item => {
      const prop = (<any>item) as IPropertyForm;

      if (prop.isPropertyForm) {
        prop.setReadOnly(this.readOnly);
      }
    });
  }

  setLoading(value: boolean, onlyDisabled: boolean = false): void {
    if (!onlyDisabled) {
      (<any>this["loading" as any]) = value;
    }

    (<any>this["loadingDisabled" as any]) = value;

    this.forEach(item => {
      const prop = (<any>item) as IPropertyForm;

      if (prop.isPropertyForm) {
        prop.setLoading(this.loading, true);
      }
    });
  }
}
