import { ElementVisibility } from './element-visibility';

export class BasePropertyForm {
  readonly propId: string;
  readonly display: ElementVisibility;
  readonly hidden: boolean;
  readonly invisible: boolean;

  constructor(propId: string) {
    this.propId = propId;
    this.display = new ElementVisibility();
  }

  hide() {
    this["hidden" as any] = true;
    this.display.hide();
  }

  show() {
    this["hidden" as any] = false;
    this.display.show();
  }

  fadeOut() {
    this["invisible" as any] = true;
    this.display.show();
  }

  fadeIn() {
    this["invisible" as any] = false;
    this.display.hide();
  }
}
