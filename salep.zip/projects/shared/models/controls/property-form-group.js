"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var form_control_element_1 = require("./form-control-element");
var base_property_form_1 = require("./base-property-form");
var PropertyFormGroup = /** @class */ (function (_super) {
    __extends(PropertyFormGroup, _super);
    function PropertyFormGroup(propId, formBuilder) {
        var _this = _super.call(this, propId) || this;
        _this.formBuilder = formBuilder;
        _this.isPropertyForm = true;
        _this._formGroup = _this.formBuilder.group({});
        _this._formGroup.controlElement = _this._controlElement = new form_control_element_1.FormControlElement();
        _this._properties = new Array();
        return _this;
    }
    Object.defineProperty(PropertyFormGroup.prototype, "formGroup", {
        get: function () {
            return this._formGroup;
        },
        enumerable: true,
        configurable: true
    });
    PropertyFormGroup.prototype.addPropertyForm = function (parent) {
        parent.addControl(this.propId, this.formGroup);
    };
    PropertyFormGroup.prototype.disable = function () {
        this["disabled"] = true;
        this._properties.forEach(function (item) {
            item.disable();
        });
    };
    PropertyFormGroup.prototype.enable = function () {
        this["disabled"] = false;
        this._properties.forEach(function (item) {
            item.enable();
        });
    };
    PropertyFormGroup.prototype.setReadOnly = function (value) {
        var _this = this;
        this["readOnly"] = value;
        this._properties.forEach(function (item) {
            item.setReadOnly(_this.readOnly);
        });
    };
    PropertyFormGroup.prototype.setLoading = function (value, onlyDisabled) {
        var _this = this;
        if (onlyDisabled === void 0) { onlyDisabled = false; }
        if (!onlyDisabled) {
            this["loading"] = value;
        }
        this["loadingDisabled"] = value;
        this._properties.forEach(function (item) {
            item.setLoading(_this.loading, true);
        });
    };
    PropertyFormGroup.prototype.addProperties = function () {
        var pattern = /_disabled|_readOnly|_loading|isPropertyForm|_formGroup|_controlElement|_properties|disabled|readOnly|loading/gi;
        for (var propName in this) {
            if (!pattern.test(propName)) {
                var prop = this[propName];
                if (prop.isPropertyForm) {
                    prop.addPropertyForm(this._formGroup);
                    this._properties.push(prop);
                }
            }
        }
    };
    return PropertyFormGroup;
}(base_property_form_1.BasePropertyForm));
exports.PropertyFormGroup = PropertyFormGroup;
//# sourceMappingURL=property-form-group.js.map