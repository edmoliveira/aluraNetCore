"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var form_control_element_1 = require("./form-control-element");
var base_property_form_1 = require("./base-property-form");
var core_1 = require("@angular/core");
var SubmitPropertyForm = /** @class */ (function (_super) {
    __extends(SubmitPropertyForm, _super);
    function SubmitPropertyForm(propId) {
        var _this = _super.call(this, propId) || this;
        _this.isPropertyForm = true;
        _this.controlElement = new form_control_element_1.FormControlElement();
        _this.onClick = new core_1.EventEmitter();
        return _this;
    }
    SubmitPropertyForm.prototype.addPropertyForm = function (parent) {
        //empty
    };
    SubmitPropertyForm.prototype.disable = function () {
        this["disabled"] = true;
        this.controlElement.setDisabled(this.disabled);
    };
    SubmitPropertyForm.prototype.enable = function () {
        this["disabled"] = false;
        this.controlElement.setDisabled(this.disabled);
    };
    SubmitPropertyForm.prototype.setReadOnly = function (value) {
        this["readOnly"] = value;
        this.controlElement.setReadOnly(value);
    };
    SubmitPropertyForm.prototype.setLoading = function (value, onlyDisabled) {
        if (onlyDisabled === void 0) { onlyDisabled = false; }
        if (!onlyDisabled) {
            this["loading"] = value;
        }
        this["loadingDisabled"] = value;
        if (value && !this.disabled) {
            this.controlElement.setDisabled(true);
        }
        else if (!this.disabled) {
            this.controlElement.setDisabled(false);
        }
    };
    SubmitPropertyForm.prototype.triggerClickEvent = function (event) {
        this.onClick.emit(event);
    };
    return SubmitPropertyForm;
}(base_property_form_1.BasePropertyForm));
exports.SubmitPropertyForm = SubmitPropertyForm;
//# sourceMappingURL=submit-property-form.js.map