import { EventEmitter } from '@angular/core';

export class ElementVisibility {
  readonly hidden: boolean;
  readonly invisible: boolean;

  onHidden: EventEmitter<boolean>;
  onInvisible: EventEmitter<boolean>;

  constructor() {
    this.onHidden = new EventEmitter();
    this.onInvisible = new EventEmitter();
  }

  hide() {
    this["hidden" as any] = true;
    this.onHidden.emit(this.hidden);
  }

  show() {
    this["hidden" as any] = false;
    this.onHidden.emit(this.hidden);
  }

  fadeOut() {
    this["invisible" as any] = true;
    this.onInvisible.emit(this.invisible);
  }

  fadeIn() {
    this["invisible" as any] = false;
    this.onInvisible.emit(this.invisible);
  }
}
