"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var element_visibility_1 = require("./element-visibility");
var BasePropertyForm = /** @class */ (function () {
    function BasePropertyForm(propId) {
        this.propId = propId;
        this.display = new element_visibility_1.ElementVisibility();
    }
    BasePropertyForm.prototype.hide = function () {
        this["hidden"] = true;
        this.display.hide();
    };
    BasePropertyForm.prototype.show = function () {
        this["hidden"] = false;
        this.display.show();
    };
    BasePropertyForm.prototype.fadeOut = function () {
        this["invisible"] = true;
        this.display.show();
    };
    BasePropertyForm.prototype.fadeIn = function () {
        this["invisible"] = false;
        this.display.hide();
    };
    return BasePropertyForm;
}());
exports.BasePropertyForm = BasePropertyForm;
//# sourceMappingURL=base-property-form.js.map