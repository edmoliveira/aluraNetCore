"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var BaseApplicationPropertyForm = /** @class */ (function () {
    function BaseApplicationPropertyForm() {
    }
    return BaseApplicationPropertyForm;
}());
exports.BaseApplicationPropertyForm = BaseApplicationPropertyForm;
//# sourceMappingURL=base-application-property-form.js.map