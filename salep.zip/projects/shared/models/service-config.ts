import { IServiceConfig } from '../interfaces/iservice-config';
import { BaseServiceUrlConfig } from './base-service-url-config';
import { ServicesUrlConfig } from './services-url-config';

export class ServiceConfig implements IServiceConfig {
  baseServiceUrl: BaseServiceUrlConfig;
  servicesUrl: ServicesUrlConfig;
}
