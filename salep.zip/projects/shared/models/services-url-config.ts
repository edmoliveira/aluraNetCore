export class ServicesUrlConfig {
  user: UserServicesUrlConfig;
}

export class UserServicesUrlConfig {
  login: string;
}
