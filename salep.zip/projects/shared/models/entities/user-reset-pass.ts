export class UserResetPassword {
  userToken: string;
}
