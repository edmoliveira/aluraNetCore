"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ServicesUrlConfig = /** @class */ (function () {
    function ServicesUrlConfig() {
    }
    return ServicesUrlConfig;
}());
exports.ServicesUrlConfig = ServicesUrlConfig;
var UserServicesUrlConfig = /** @class */ (function () {
    function UserServicesUrlConfig() {
    }
    return UserServicesUrlConfig;
}());
exports.UserServicesUrlConfig = UserServicesUrlConfig;
//# sourceMappingURL=services-url-config.js.map