"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var BaseServiceUrlConfig = /** @class */ (function () {
    function BaseServiceUrlConfig() {
    }
    return BaseServiceUrlConfig;
}());
exports.BaseServiceUrlConfig = BaseServiceUrlConfig;
var EnvironmentConfig = /** @class */ (function () {
    function EnvironmentConfig() {
    }
    return EnvironmentConfig;
}());
exports.EnvironmentConfig = EnvironmentConfig;
//# sourceMappingURL=base-service-url-config.js.map