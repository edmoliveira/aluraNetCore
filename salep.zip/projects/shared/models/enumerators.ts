export enum FormControlStatus {
  Valid = 'VALID',
  Invalid = 'INVALID',
  Pending = 'PENDING',
  Disabled = 'DISABLED'
}

export enum ErrorState {
  Empty = 'EMPTY',
  NoAuthorized = 'NO_AUTHORIZED',
  UnregisteredEmail = 'UNREGISTERED_EMAIL',
  ServerError = 'SERVER_ERROR'
}
