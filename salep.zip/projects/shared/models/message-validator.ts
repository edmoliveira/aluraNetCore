export class MessageValidator {
  constructor(
    public appValidatorMessage: string
  ) {

  }
}
