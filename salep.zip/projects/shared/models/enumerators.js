"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var FormControlStatus;
(function (FormControlStatus) {
    FormControlStatus["Valid"] = "VALID";
    FormControlStatus["Invalid"] = "INVALID";
    FormControlStatus["Pending"] = "PENDING";
    FormControlStatus["Disabled"] = "DISABLED";
})(FormControlStatus = exports.FormControlStatus || (exports.FormControlStatus = {}));
var ErrorState;
(function (ErrorState) {
    ErrorState["Empty"] = "EMPTY";
    ErrorState["NoAuthorized"] = "NO_AUTHORIZED";
    ErrorState["UnregisteredEmail"] = "UNREGISTERED_EMAIL";
    ErrorState["ServerError"] = "SERVER_ERROR";
})(ErrorState = exports.ErrorState || (exports.ErrorState = {}));
//# sourceMappingURL=enumerators.js.map