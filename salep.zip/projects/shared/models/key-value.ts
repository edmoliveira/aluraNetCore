export class KeyValue {
  constructor(
    public key: any
    , public value: any
  ) {

  }
}
