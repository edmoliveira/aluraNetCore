import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ServiceConfig } from '../models/service-config';
import { EnvironmentConfig } from '../models/base-service-url-config';
import { AppConfig } from '../helpers/app-config';

@Injectable({
  providedIn: 'root'
})
export class ConfigurationService {
  constructor(private http: HttpClient) {
  }

  setConfiguration(production: boolean) {
    this.http.get<ServiceConfig>('../../../../assets/shared/config/service-config.json')
      .subscribe(response => {
        let baseUrls: EnvironmentConfig = production ? response.baseServiceUrl.production : response.baseServiceUrl.test;

        AppConfig.ServiceUrls.initialize(baseUrls, response.servicesUrl);
      });
  }
}
