"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var BaseService = /** @class */ (function () {
    function BaseService(apiUrl) {
        this.apiUrl = apiUrl;
    }
    BaseService.prototype.getUrl = function (method) {
        var firstUrl = this.apiUrl.replace(/^\/|\/$/g, '');
        var secondUrl = method.replace(/^\//g, '');
        return firstUrl + "/" + secondUrl;
    };
    return BaseService;
}());
exports.BaseService = BaseService;
//# sourceMappingURL=base-service.js.map