export interface IServiceConfig {
  
}
