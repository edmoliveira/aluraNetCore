export interface IAppComponent {
  title: string;
}
