import { FormGroup } from '@angular/forms';

export interface IPropertyForm {
  readonly isPropertyForm: boolean;
  addPropertyForm(parent: FormGroup): void;
  readonly disabled: boolean;
  readonly readOnly: boolean;
  readonly loading: boolean;
  readonly loadingDisabled: boolean;

  disable(): void;
  enable(): void;
  setReadOnly(value: boolean): void;
  setLoading(value: boolean, onlyDisabled: boolean): void;
}
