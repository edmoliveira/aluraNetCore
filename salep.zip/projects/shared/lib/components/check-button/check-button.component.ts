import { Component, OnInit, Input } from '@angular/core';
import { NgStyle, NgClass } from '@angular/common';
import { BoolPropertyForm } from '../../../models/controls/property-form';

@Component({
  selector: 'app-check-button',
  templateUrl: './check-button.component.html',
  styleUrls: ['./check-button.component.scss']
})
export class CheckButtonComponent implements OnInit {
  @Input()
  label: string;

  @Input()
  ngStyle: NgStyle;

  @Input()
  ngClass: NgClass;

  @Input()
  propertyForm: BoolPropertyForm;

  constructor() {
  }

  ngOnInit() {

  }

  private onChecked() {
    if (!this.propertyForm.disabled) {
      this.propertyForm.Value = this.propertyForm.Value ? false : true;
    }
  }
}
