import { Component, OnInit, Input } from '@angular/core';
import { KeyValue} from '../../../models/key-value';

@Component({
  selector: 'app-error-common',
  templateUrl: './error-common.component.html'
})
export class ErrorCommonComponent implements OnInit {
  private errorToKeyValueList: KeyValue[];

  @Input()
  set errors(obj: any) {
    this.errorToKeyValueList = this.getProperties(obj);
  }

  constructor() {
  }

  ngOnInit() {

  }

  private getProperties(obj: any): KeyValue[] {
    let props: KeyValue[] = [];

    for (const name in obj) {
      if (name === 'appValidatorMessage') {
        props.push(new KeyValue(name, obj[name]));
      }
    }

    return props;
  }
}
