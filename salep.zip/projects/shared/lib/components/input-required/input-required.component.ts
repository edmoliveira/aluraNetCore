import { Component, Input } from '@angular/core';
import { RequireValue } from '../../../models/require-value';

@Component({
  selector: 'app-input-required',
  templateUrl: './input-required.component.html'
})
export class InputRequiredComponent {
  @Input()
  required: RequireValue;

  @Input()
  isSelect: boolean;

  constructor() {
  }
}
