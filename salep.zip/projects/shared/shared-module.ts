import { BrowserModule } from '@angular/platform-browser';
import { NgModule, LOCALE_ID, ModuleWithProviders } from '@angular/core';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AngularResizedEventModule } from 'angular-resize-event';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { registerLocaleData } from '@angular/common';

import { OnlyNumberDirective } from './helpers/directives/only-number-directive';
import { NativeElementFormControlDirective } from './helpers/directives/native-element-form-control-directive';
import { NativeElementFormGroupDirective } from './helpers/directives/native-element-form-group-directive';
import { ElementVisibilityDirective } from './helpers/directives/element-visibility-directive';
import { VarDirective } from './helpers/directives/ng-var.directive';
import { CustomContainerDirective } from './helpers/directives/custom-container-directive';
import { FormSubmitDirective } from './helpers/directives/form-submit-directive';
import { MatSelectDirective } from './helpers/directives/mat-select-directive';
import { MatInputToggleDirective } from './helpers/directives/mat-input-toggle-directive';
import { MatInputDirective } from './helpers/directives/mat-input-directive';

import { CheckButtonComponent } from './lib/components/check-button/check-button.component';
import { ErrorCommonComponent } from './lib/components/error-common/error-common.component';
import { InputRequiredComponent } from './lib/components/input-required/input-required.component';

import {
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatButtonModule,
  MatToolbarModule,
  MatIconModule,
  MatBadgeModule,
  MatSidenavModule,
  MatListModule,
  MatGridListModule,
  MatFormFieldModule,
  MatInputModule,
  MatSelectModule,
  MatRadioModule,
  MatDatepickerModule,
  MatNativeDateModule,
  MatChipsModule,
  MatTooltipModule,
  MatTableModule,
  MatPaginatorModule,
  MatCardModule,
  MatCheckboxModule,
  MatAutocompleteModule,
  MatButtonToggleModule,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_DATE_LOCALE,
  MAT_DATE_FORMATS,
  DateAdapter,
} from '@angular/material';

import {
  MatMomentDateModule,
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS
} from '@angular/material-moment-adapter';

import localeIt from '@angular/common/locales/it'
import * as moment from 'moment';
import { fixMatInputRequiredAsterisk } from './helpers/fix-matinput-required-asterisk';
import { HttpErrorInterceptor } from './helpers/http-error.interceptor';
import { AppRoutingModule } from '../adm/src/app/app-routing.module';

moment.fn.toJSON = function () { return this.format("YYYY-MM-DDTHH:mm:ss"); }

registerLocaleData(localeIt, 'it');

fixMatInputRequiredAsterisk();

const DEFAULT_DATE_FORMATS = {
  parse: {
    dateInput: 'L',
  },
  display: {
    dateInput: 'L',
    monthYearLabel: 'MMMM YYYY',
    dateA11yLabel: 'L',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@NgModule({
  declarations: [
    OnlyNumberDirective,
    NativeElementFormControlDirective,
    NativeElementFormGroupDirective,
    ElementVisibilityDirective,
    VarDirective, CustomContainerDirective, FormSubmitDirective, MatSelectDirective, MatInputToggleDirective,
    MatInputDirective,
    CheckButtonComponent, ErrorCommonComponent, InputRequiredComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    AngularResizedEventModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatButtonModule,
    MatToolbarModule,
    MatIconModule,
    MatBadgeModule,
    MatSidenavModule,
    MatListModule,
    MatGridListModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatRadioModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatChipsModule,
    MatTooltipModule,
    MatTableModule,
    MatPaginatorModule,
    MatCardModule,
    MatCheckboxModule,
    MatAutocompleteModule,
    MatButtonToggleModule,
    MatMomentDateModule
  ],
  entryComponents: [],
  exports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    AngularResizedEventModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatButtonModule,
    MatToolbarModule,
    MatIconModule,
    MatBadgeModule,
    MatSidenavModule,
    MatListModule,
    MatGridListModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatRadioModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatChipsModule,
    MatTooltipModule,
    MatTableModule,
    MatPaginatorModule,
    MatCardModule,
    MatCheckboxModule,
    MatAutocompleteModule,
    MatButtonToggleModule,
    MatMomentDateModule,
    OnlyNumberDirective,
    NativeElementFormControlDirective,
    NativeElementFormGroupDirective,
    ElementVisibilityDirective,
    VarDirective, CustomContainerDirective, FormSubmitDirective, MatSelectDirective, MatInputToggleDirective,
    MatInputDirective,
    CheckButtonComponent, ErrorCommonComponent, InputRequiredComponent
  ]
})
export class SharedModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: SharedModule,
      providers: [
        {
          provide: MAT_FORM_FIELD_DEFAULT_OPTIONS
          , useValue: { appearance: 'outline', padding: '0px' }
        }
        , {
          provide: HTTP_INTERCEPTORS,
          useClass: HttpErrorInterceptor,
          multi: true
        },

        { provide: LOCALE_ID, useValue: 'it' },
        { provide: MAT_DATE_LOCALE, useValue: 'it' },
        { provide: DateAdapter, useClass: MomentDateAdapter },
        { provide: MAT_DATE_FORMATS, useValue: DEFAULT_DATE_FORMATS },
        { provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: { useUtc: true } },
      ]
    };
  }
}
