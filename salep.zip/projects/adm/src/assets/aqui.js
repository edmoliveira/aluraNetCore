"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var assetss = /** @class */ (function () {
    function assetss() {
    }
    return assetss;
}());
exports.assetss = assetss;
//# sourceMappingURL=aqui.js.map