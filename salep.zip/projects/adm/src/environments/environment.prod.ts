export const environment = {
  production: true
  , appFullName: 'SALEP - Smart Learning Platform'
  , appShortName: 'Salep'
};
