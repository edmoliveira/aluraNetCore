import { Component, OnInit } from '@angular/core';
import { IAppComponent } from '../../../../../../shared/interfaces/iapp.component';
import { CompanyApplication } from '../../../controls/company/company-control.component';

@Component({
  selector: 'app-company.component',
  templateUrl: './company.component.html',
})
export class CompanyComponent implements OnInit, IAppComponent {
  title: string;

  constructor() {
  }

  ngOnInit() {
    
  }

  private loadApplication(app: CompanyApplication) {
    //app.loading = true;
  }
}
