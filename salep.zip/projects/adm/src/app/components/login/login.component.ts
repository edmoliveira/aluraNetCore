import { Component, OnInit, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { AuthManager } from '../../managers/auth-manager';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit {
  private manager: AuthManager;

  constructor(@Inject(DOCUMENT) private document) {
    this.manager = new AuthManager();
  }

  ngOnInit() {
    this.document.body.classList.add('auth-container');
  }
  ngOnDestroy() {
    this.document.body.classList.remove('auth-container');
  }
}
