import { Component, OnInit } from '@angular/core';
import { IAppComponent } from '../../../../../../shared/interfaces/iapp.component';
import { ResizedEvent } from 'angular-resize-event';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'app-initial-portal.component',
  templateUrl: './initial-portal.component.html',
  styleUrls: ['./initial-portal.component.scss']
})
export class InitialPortalComponent implements OnInit, IAppComponent {
  title: string;

  private flipBoxStyle = { 'width': '0px', 'height': '0px', 'perspective': '0px'};
  private imgBoxStyle = { 'width': '0px', 'height': '0px' };

  constructor() {
  }

  ngOnInit() {

  }

  onResized(event: ResizedEvent) {
    const area = (event.newHeight * 2 + event.newWidth * 2) * 0.12;

    this.flipBoxStyle['width'] = `${area}px`;
    this.flipBoxStyle['height'] = `${area}px`;
    this.flipBoxStyle['perspective'] = `${(area * 2)}px`;

    this.imgBoxStyle['width'] = `${area}px`;
    this.imgBoxStyle['height'] = `${area}px`;
  }
}
