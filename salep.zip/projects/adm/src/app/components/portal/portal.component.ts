import { Component, OnInit, ViewChild, ViewChildren, QueryList, ElementRef, ComponentFactoryResolver } from '@angular/core';
import { FormControl } from '@angular/forms';
import { environment } from '../../../environments/environment';
import { MenuModel } from '../../models/menu-model';
import { ItemMenuModel } from '../../models/item-menu-model';
import { CustomContainerDirective } from '../../../../../shared/helpers/directives/custom-container-directive';
import { IAppComponent } from '../../../../../shared/interfaces/iapp.component';
import { Type } from '@angular/core';
import { CompanyComponent } from '../registers/company/company.component';
import { InitialPortalComponent } from './initial-portal/initial-portal.component';
import { ComponentModel } from '../../models/component-model';

@Component({
  selector: 'app-portal',
  templateUrl: './portal.component.html',
  styleUrls: ['./portal.component.scss']
})
export class PortalComponent implements OnInit {
  private burgerMenu: FormControl;
  private parentNavContainer: any;
  private menus: MenuModel[];

  private readonly appTitle: string;


  @ViewChildren('menuEl')
  menuNativeElement: QueryList<any>;

  @ViewChild(CustomContainerDirective, { static: true })
  container: CustomContainerDirective;

  private openCloseComponentAnimation = { 'bodyComponent': true, 'openCloseComponent': false };
  private initialComponent = new ComponentModel(1, '', InitialPortalComponent);
  private openedComponentId: number = 0;

  private readonly footer: string = `Copyright @ ${environment.appShortName} ${new Date().getFullYear()}. All right reserved.`;

  constructor(private componentFactoryResolver: ComponentFactoryResolver) {
    this.appTitle = environment.appShortName;

    this.burgerMenu = new FormControl(!this.isMobile());

    this.parentNavContainer = { 'parentNavContainer': this.burgerMenu.value };

    this.burgerMenu.valueChanges.subscribe(checked => {
      this.parentNavContainer['parentNavContainer'] = checked;
    });

    this.menus = [];

    for (let index = 0; index < 5; index++) {
      let menu: MenuModel = new MenuModel();

      menu.icon = ['fa', 'fa-list-alt'];
      menu.description = `Menu ${index}`;
      menu.oClass = { 'containerMenuNav': true }

      for (let j = 0; j < 2; j++) {
        let item: ItemMenuModel = new ItemMenuModel();

        item.icon = ['fa', 'fa-asterisk'];
        item.description = `Item Menu ${index}.${j}`;
        item.component = new ComponentModel(2, `Item Menu ${index}.${j}`, CompanyComponent);

        menu.addItem(item);
      }

      this.menus.push(menu);
    }
  }

  ngOnInit() {
    this.openedComponentId = this.initialComponent.id;
    this.addComponentToContainer(this.initialComponent);
  }

  ngAfterViewInit() {
    this.menuNativeElement.forEach((item: ElementRef, index) => {
      let nativeELemenet = item.nativeElement;

      nativeELemenet.auxHeight = nativeELemenet.offsetHeight;
      nativeELemenet.style.height = '0px';

      this.menus[index].element = nativeELemenet;
    });
  }

  private menuClick(menu: MenuModel) {
    if (menu.isOpen) {
      menu.isOpen = false;
      menu.element.style.height = '0px';
    }
    else {
      menu.isOpen = true;
      menu.element.style.height = menu.element.auxHeight + 'px';
    }
  }

  private itemMenuClick(itemMenu: ItemMenuModel) {
    if (this.isMobile()) {
      this.burgerMenu.setValue(false);
    }

    this.openCloseComponent(itemMenu.component);
  }

  private initialClick() {
    this.openCloseComponent(this.initialComponent);
  }

  private openCloseComponent(component: ComponentModel) {
    if (this.openedComponentId !== component.id) {
      this.openedComponentId = component.id;
      this.openCloseComponentAnimation['openCloseComponent'] = true;

      setTimeout(() => {
        this.addComponentToContainer(component);
      }, 500);

      setTimeout(() => {
        this.openCloseComponentAnimation['openCloseComponent'] = false;
      }, 900);
    }
  }

  private addComponentToContainer(component: ComponentModel): IAppComponent {
    const viewContainerRef = this.container.viewContainerRef;
    viewContainerRef.clear();

    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(component.type);

    let instance = viewContainerRef.createComponent<IAppComponent>(componentFactory).instance;

    instance.title = component.title;

    return instance;
  }

  private isMobile() {
    return "ontouchstart" in document.documentElement;
  }
}
