import { Component, OnInit, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { AuthManager, AuthManagerPage } from '../../managers/auth-manager';
import { ActivatedRoute } from '@angular/router';
import { AuthGuard } from '../../../../../shared/helpers/auth-guard';

@Component({
  selector: 'app-new-password',
  templateUrl: './new-password.component.html'
})
export class NewPasswordComponent implements OnInit {
  private manager: AuthManager;

  constructor(@Inject(DOCUMENT) private document, route: ActivatedRoute) {
    const token = route.snapshot.queryParamMap.get("token");

    if (token == null) {
      this.manager = new AuthManager(AuthManagerPage.NoToken);
    }
    else {
      this.manager = new AuthManager(AuthManagerPage.NewPassword, AuthGuard.validTokenNewPasswork(token));
    }
  }

  ngOnInit() {
    this.document.body.classList.add('auth-container');
  }
  ngOnDestroy() {
    this.document.body.classList.remove('auth-container');
  }
}
