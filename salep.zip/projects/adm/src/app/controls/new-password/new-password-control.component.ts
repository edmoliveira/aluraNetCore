import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { BaseControl } from '../../../../../shared/helpers/base-control';
import { BaseApplication } from '../../../../../shared/helpers/base-application';
import { BaseApplicationPropertyForm } from '../../../../../shared/models/controls/base-application-property-form';
import { StringPropertyForm } from '../../../../../shared/models/controls/property-form';
import { ErrorState } from '../../../../../shared/models/enumerators';
import { SubmitPropertyForm } from '../../../../../shared/models/controls/submit-property-form';

@Component({
  selector: 'app-new-password-control',
  templateUrl: './new-password-control.component.html',
  styleUrls: ['./new-password-control.component.scss']
})
export class NewPasswordControlComponent extends BaseControl<NewPasswordApplicationPropertyForm> implements OnInit {
  private ErrorState = ErrorState;

  constructor(private formBuilder: FormBuilder) {
    super();
  }

  ngOnInit() {
    this.initialize(new NewPasswordApplication(this.formBuilder));
  }
}

export class NewPasswordApplication extends BaseApplication<NewPasswordApplicationPropertyForm> {
  passwordPlaceholder: string;
  repeatPasswordPlaceholder: string;
  serverErrorMessage: string;
  state: ErrorState;

  constructor(formBuilder: FormBuilder) {
    super(formBuilder, new NewPasswordApplicationPropertyForm());
  }
}

export class NewPasswordApplicationPropertyForm extends BaseApplicationPropertyForm {
  password: StringPropertyForm;
  repeatPassword: StringPropertyForm;
  notification: StringPropertyForm;
  resetSubmit: SubmitPropertyForm;
  closeSubmit: SubmitPropertyForm;

  constructor() {
    super();

    this.password = new StringPropertyForm('password');
    this.repeatPassword = new StringPropertyForm('repeatPassword');
    this.notification = new StringPropertyForm('notification');
    this.resetSubmit = new SubmitPropertyForm('resetSubmit');
    this.closeSubmit = new SubmitPropertyForm('closeSubmit');
  }
}
