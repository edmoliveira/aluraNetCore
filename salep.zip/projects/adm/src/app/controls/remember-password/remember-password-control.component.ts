import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { BaseControl } from '../../../../../shared/helpers/base-control';
import { BaseApplication } from '../../../../../shared/helpers/base-application';
import { BaseApplicationPropertyForm } from '../../../../../shared/models/controls/base-application-property-form';
import { StringPropertyForm } from '../../../../../shared/models/controls/property-form';
import { SubmitPropertyForm } from '../../../../../shared/models/controls/submit-property-form';
import { ErrorState } from '../../../../../shared/models/enumerators';

@Component({
  selector: 'app-remember-password-control',
  templateUrl: './remember-password-control.component.html',
  styleUrls: ['./remember-password-control.component.scss']
})
export class RememberPasswordControlComponent extends BaseControl<RememberPasswordApplicationPropertyForm> implements OnInit {
  private ErrorState = ErrorState;

  constructor(private formBuilder: FormBuilder) {
    super();
  }

  ngOnInit() {
    this.initialize(new RememberPasswordApplication(this.formBuilder));
  }
}

export class RememberPasswordApplication extends BaseApplication<RememberPasswordApplicationPropertyForm> {
  unregisteredEmaildMessage: string;
  serverErrorMessage: string;
  state: ErrorState;
  notificationClass: string = '';
  rememberSubmitText: string = '';

  constructor(formBuilder: FormBuilder) {
    super(formBuilder, new RememberPasswordApplicationPropertyForm());
  }
}

export class RememberPasswordApplicationPropertyForm extends BaseApplicationPropertyForm {
  email: StringPropertyForm;
  notification: StringPropertyForm;
  rememberSubmit: SubmitPropertyForm;
  closeSubmit: SubmitPropertyForm;
  iconCloseSubmit: SubmitPropertyForm;

  constructor() {
    super();

    this.email = new StringPropertyForm('email');
    this.notification = new StringPropertyForm('notification');
    this.rememberSubmit = new SubmitPropertyForm('rememberSubmit');
    this.closeSubmit = new SubmitPropertyForm('closeSubmit');
    this.iconCloseSubmit = new SubmitPropertyForm('iconCloseSubmit');
  }
}
