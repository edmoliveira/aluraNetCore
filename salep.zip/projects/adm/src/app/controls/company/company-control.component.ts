import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { BaseControl } from '../../../../../shared/helpers/base-control';
import { BaseApplication } from '../../../../../shared/helpers/base-application';
import { BaseApplicationPropertyForm } from '../../../../../shared/models/controls/base-application-property-form';
import { StringPropertyForm } from '../../../../../shared/models/controls/property-form';

@Component({
  selector: 'app-company-control',
  templateUrl: './company-control.component.html'
})
export class CompanyControlComponent extends BaseControl<CompanyApplicationPropertyForm> implements OnInit {
  constructor(private formBuilder: FormBuilder) {
    super();
  }

  ngOnInit() {
    this.initialize(new CompanyApplication(this.formBuilder));
  }
}

export class CompanyApplication extends BaseApplication<CompanyApplicationPropertyForm> {
  constructor(formBuilder: FormBuilder) {
    super(formBuilder, new CompanyApplicationPropertyForm());
  }
}

export class CompanyApplicationPropertyForm extends BaseApplicationPropertyForm {
  companyName: StringPropertyForm;

  constructor() {
    super();

    this.companyName = new StringPropertyForm('companyName');
  }
}
