import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-default-container-control',
  templateUrl: './default-container-control.component.html',
  styleUrls: ['./default-container-control.component.scss']
})
export class DefaultContainerControlComponent implements OnInit {
  @Input()
  formTitle: string;

  @Input()
  spinner: boolean;

  constructor() {
  }

  ngOnInit() {

  }
}
