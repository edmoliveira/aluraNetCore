import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { BaseControl } from '../../../../../shared/helpers/base-control';
import { BaseApplication } from '../../../../../shared/helpers/base-application';
import { BaseApplicationPropertyForm } from '../../../../../shared/models/controls/base-application-property-form';
import { StringPropertyForm, GenericPropertyForm } from '../../../../../shared/models/controls/property-form';
import { SubmitPropertyForm } from '../../../../../shared/models/controls/submit-property-form';
import { ErrorState } from '../../../../../shared/models/enumerators';

@Component({
  selector: 'app-login-control',
  templateUrl: './login-control.component.html',
  styleUrls: ['./login-control.component.scss']
})
export class LoginControlComponent extends BaseControl<LoginApplicationPropertyForm> implements OnInit {
  private ErrorState = ErrorState;

  constructor(private formBuilder: FormBuilder) {
    super();
  }

  ngOnInit() {
    this.initialize(new LoginApplication(this.formBuilder));
  }
}

export class LoginApplication extends BaseApplication<LoginApplicationPropertyForm> {
  userNamePlaceholder: string;
  passwordPlaceholder: string;
  noAuthorizedMessage: string;
  serverErrorMessage: string;
  state: ErrorState;

  constructor(formBuilder: FormBuilder) {
    super(formBuilder, new LoginApplicationPropertyForm());
  }
}

export class LoginApplicationPropertyForm extends BaseApplicationPropertyForm {
  userName: StringPropertyForm;
  password: StringPropertyForm;
  signInSubmit: SubmitPropertyForm;
  forgotPasswordSubmit: SubmitPropertyForm;

  constructor() {
    super();

    this.userName = new StringPropertyForm('userName');
    this.password = new StringPropertyForm('password');
    this.signInSubmit = new SubmitPropertyForm('signInSubmit');
    this.forgotPasswordSubmit = new SubmitPropertyForm('forgotPasswordSubmit');
  }
}
