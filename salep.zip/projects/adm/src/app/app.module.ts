import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { SharedModule } from '../../../shared/shared-module';

import { LoginComponent } from './components/login/login.component';
import { NewPasswordComponent } from './components/new-password/new-password.component';
import { PortalComponent } from './components/portal/portal.component';

import { DefaultContainerControlComponent } from './controls/default-container/default-container-control.component';
import { CompanyComponent } from './components/registers/company/company.component';
import { InitialPortalComponent } from './components/portal/initial-portal/initial-portal.component';

import { CompanyControlComponent } from './controls/company/company-control.component';
import { LoginControlComponent } from './controls/login/login-control.component';
import { RememberPasswordControlComponent } from './controls/remember-password/remember-password-control.component';
import { NewPasswordControlComponent } from './controls/new-password/new-password-control.component';

@NgModule({
  declarations: [
    AppComponent
    , LoginComponent, NewPasswordComponent, PortalComponent
    , InitialPortalComponent, CompanyComponent
    , DefaultContainerControlComponent
    , CompanyControlComponent, LoginControlComponent, RememberPasswordControlComponent
    , NewPasswordControlComponent
  ],
  entryComponents: [
    InitialPortalComponent, CompanyComponent
  ],
  imports: [
    SharedModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
