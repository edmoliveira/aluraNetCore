"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var enumerators_1 = require("../../../../shared/models/enumerators");
var custom_validators_1 = require("../../../../shared/helpers/custom-validators");
var message_validator_1 = require("../../../../shared/models/message-validator");
var AuthManagerPage;
(function (AuthManagerPage) {
    AuthManagerPage[AuthManagerPage["Login"] = 1] = "Login";
    AuthManagerPage[AuthManagerPage["NewPassword"] = 2] = "NewPassword";
    AuthManagerPage[AuthManagerPage["NoToken"] = 3] = "NoToken";
})(AuthManagerPage = exports.AuthManagerPage || (exports.AuthManagerPage = {}));
var AuthManager = /** @class */ (function () {
    function AuthManager(page, user) {
        if (page === void 0) { page = AuthManagerPage.Login; }
        if (user === void 0) { user = null; }
        this.user = user;
        this.loginClass = { 'auth-form': true, 'auth-form-hide': false };
        this.rememberClass = { 'auth-form': true, 'auth-form-hide': true };
        this.newPasswordClass = { 'auth-form': true, 'auth-form-hide': true };
        this.invalidToken = false;
        if (page === AuthManagerPage.NewPassword) {
            if (user != null) {
                this.loginClass['auth-form-hide'] = true;
                this.rememberClass['auth-form-hide'] = true;
                this.newPasswordClass['auth-form-hide'] = false;
            }
            else {
                this.loginClass['auth-form-hide'] = true;
                this.rememberClass['auth-form-hide'] = false;
                this.newPasswordClass['auth-form-hide'] = true;
                this.invalidToken = true;
            }
        }
        else if (page === AuthManagerPage.NoToken) {
            this.loginClass['auth-form-hide'] = false;
            this.rememberClass['auth-form-hide'] = true;
            this.newPasswordClass['auth-form-hide'] = true;
        }
    }
    AuthManager.prototype.login_LoadApplication = function (app) {
        var _this = this;
        //app.loading = true;
        app.userNamePlaceholder = 'Email';
        app.passwordPlaceholder = 'Password';
        app.noAuthorizedMessage = 'Email and password are not accepted';
        app.serverErrorMessage = 'Internal Server Error';
        app.state = enumerators_1.ErrorState.Empty;
        var props = app.properties;
        props.userName.setRequired(custom_validators_1.CustomValidators.email('Incorrect format'));
        props.password.setRequired();
        props.signInSubmit.onClick.subscribe({
            next: function (event) {
            }
        });
        props.forgotPasswordSubmit.onClick.subscribe({
            next: function (event) {
                _this.openRememberApp();
                setTimeout(function () {
                    props.userName.Value = '';
                    props.userName.markAsPristine();
                    props.password.Value = '';
                    props.password.markAsPristine();
                }, 500);
            }
        });
    };
    AuthManager.prototype.login_Initialize = function (app) {
        var _this = this;
        var props = app.properties;
        var status = props.formGroup.status;
        var idInterval = setInterval(function () {
            if (status !== props.formGroup.status) {
                _this.setSignInState(app);
                clearInterval(idInterval);
            }
        }, 100);
        props.formGroup.statusChanges.subscribe(function () {
            _this.setSignInState(app);
        });
    };
    AuthManager.prototype.setSignInState = function (app) {
        var props = app.properties;
        if (props.formGroup.status !== enumerators_1.FormControlStatus.Valid) {
            props.signInSubmit.disable();
        }
        else {
            props.signInSubmit.enable();
        }
    };
    AuthManager.prototype.remember_LoadApplication = function (app) {
        var _this = this;
        var props = app.properties;
        var setInitial = function () {
            app.state = enumerators_1.ErrorState.Empty;
            props.email.fadeIn();
            props.notification.fadeOut();
            props.rememberSubmit.show();
            props.closeSubmit.hide();
        };
        var onClose = function () {
            _this.openLoginApp();
            setTimeout(function () {
                setInitial();
                props.email.Value = '';
                props.email.markAsPristine();
            }, 500);
        };
        //app.loading = true;
        app.unregisteredEmaildMessage = 'Unregistered email address';
        app.serverErrorMessage = 'Internal Server Error';
        setInitial();
        if (!this.invalidToken) {
            app.notificationClass = 'notificationSuccess';
            props.notification.Value = 'Email successfully sent!';
        }
        else {
            app.notificationClass = 'notificationError';
            props.notification.Value = 'Sorry, your token expired! We need to re-send!';
            props.notification.fadeIn();
        }
        app.rememberSubmitText = 'Send';
        props.email.setRequired(custom_validators_1.CustomValidators.email('Incorrect format'));
        props.rememberSubmit.onClick.subscribe({
            next: function (event) {
                app.notificationClass = 'notificationSuccess';
                props.notification.Value = 'Email successfully sent!';
                props.email.fadeOut();
                props.notification.fadeIn();
                props.rememberSubmit.hide();
                props.closeSubmit.show();
            }
        });
        props.closeSubmit.onClick.subscribe({
            next: function (event) {
                onClose();
            }
        });
        props.iconCloseSubmit.onClick.subscribe({
            next: function (event) {
                onClose();
            }
        });
    };
    AuthManager.prototype.remember_Initialize = function (app) {
        var _this = this;
        var props = app.properties;
        var status = props.formGroup.status;
        var idInterval = setInterval(function () {
            if (status !== props.formGroup.status) {
                _this.setRememberState(app);
                clearInterval(idInterval);
            }
        }, 100);
        props.formGroup.statusChanges.subscribe(function () {
            _this.setRememberState(app);
        });
    };
    AuthManager.prototype.setRememberState = function (app) {
        var props = app.properties;
        if (props.formGroup.status !== enumerators_1.FormControlStatus.Valid) {
            props.rememberSubmit.disable();
        }
        else {
            props.rememberSubmit.enable();
        }
    };
    AuthManager.prototype.newPass_LoadApplication = function (app) {
        var _this = this;
        var props = app.properties;
        var strongPasswordValidator = function (message) {
            return function (control) {
                if (props.password.valueIsNull() || props.repeatPassword.valueIsNull())
                    return null;
                return props.password.Value != props.repeatPassword.Value ? new message_validator_1.MessageValidator(message) : null;
            };
        };
        props.password.setRequired([
            custom_validators_1.CustomValidators.minLength(8, 'It must be eight characters or longer'),
            custom_validators_1.CustomValidators.pattern(/.*[a-z]/, 'It must contain at least 1 lowercase alphabetical character'),
            custom_validators_1.CustomValidators.pattern(/.*[A-Z]/, 'It must contain at least 1 uppercase alphabetical character'),
            custom_validators_1.CustomValidators.pattern(/.*[!@#$%^&*]/, 'It must contain at least one special character'),
            custom_validators_1.CustomValidators.pattern(/.*[0-9]/, 'It must contain at least 1 numeric character')
        ]);
        props.repeatPassword.setRequired();
        var setInitial = function () {
            app.state = enumerators_1.ErrorState.Empty;
            props.notification.hide();
            props.password.show();
            props.repeatPassword.show();
            props.resetSubmit.show();
            props.closeSubmit.hide();
        };
        var onClose = function () {
            _this.closeNewPasswordApp();
            setTimeout(function () {
                setInitial();
                props.password.Value = '';
                props.password.markAsPristine();
                props.repeatPassword.Value = '';
                props.repeatPassword.markAsPristine();
            }, 500);
        };
        //app.loading = true;
        props.notification.Value = 'Your password has been changed successfully';
        app.serverErrorMessage = 'Internal Server Error';
        app.passwordPlaceholder = 'Password';
        app.repeatPasswordPlaceholder = 'Repeat Password';
        setInitial();
        props.resetSubmit.onClick.subscribe({
            next: function (event) {
                props.notification.show();
                props.password.hide();
                props.repeatPassword.hide();
                props.resetSubmit.hide();
                props.closeSubmit.show();
            }
        });
        props.closeSubmit.onClick.subscribe({
            next: function (event) {
                onClose();
                window.history.pushState('', 'login', '/login');
            }
        });
    };
    AuthManager.prototype.newPass_Initialize = function (app) {
        var _this = this;
        var props = app.properties;
        var passwordEqualRepeatPasswordValidator = function (message) {
            return function (control) {
                if (props.password.valueIsNull() || props.repeatPassword.valueIsNull())
                    return null;
                return props.password.Value != props.repeatPassword.Value ? new message_validator_1.MessageValidator(message) : null;
            };
        };
        props.formGroup.setValidators([passwordEqualRepeatPasswordValidator('Passwords are not equal')]);
        var status = props.formGroup.status;
        var idInterval = setInterval(function () {
            if (status !== props.formGroup.status) {
                _this.setNewPassState(app);
                clearInterval(idInterval);
            }
        }, 100);
        props.formGroup.statusChanges.subscribe(function () {
            _this.setNewPassState(app);
        });
    };
    AuthManager.prototype.setNewPassState = function (app) {
        var props = app.properties;
        if (props.formGroup.status !== enumerators_1.FormControlStatus.Valid) {
            props.resetSubmit.disable();
        }
        else {
            props.resetSubmit.enable();
        }
    };
    AuthManager.prototype.openLoginApp = function () {
        this.loginClass['auth-form-hide'] = false;
        this.rememberClass['auth-form-hide'] = true;
    };
    AuthManager.prototype.openRememberApp = function () {
        this.loginClass['auth-form-hide'] = true;
        this.rememberClass['auth-form-hide'] = false;
    };
    AuthManager.prototype.closeNewPasswordApp = function () {
        this.loginClass['auth-form-hide'] = false;
        this.newPasswordClass['auth-form-hide'] = true;
    };
    return AuthManager;
}());
exports.AuthManager = AuthManager;
//# sourceMappingURL=auth-manager.js.map