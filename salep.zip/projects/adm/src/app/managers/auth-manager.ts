import { LoginApplication } from '../controls/login/login-control.component';
import { FormControlStatus, ErrorState } from '../../../../shared/models/enumerators';
import { RememberPasswordApplication } from '../controls/remember-password/remember-password-control.component';
import { NewPasswordApplication } from '../controls/new-password/new-password-control.component';
import { UserResetPassword } from '../../../../shared/models/entities/user-reset-pass';
import { CustomValidators } from '../../../../shared/helpers/custom-validators';
import { ValidatorFn, AbstractControl } from '@angular/forms';
import { MessageValidator } from '../../../../shared/models/message-validator';

export enum AuthManagerPage {
  Login = 1
  , NewPassword = 2
  , NoToken = 3
}

export class AuthManager {
  readonly loginClass = { 'auth-form': true, 'auth-form-hide': false };
  readonly rememberClass = { 'auth-form': true, 'auth-form-hide': true };
  readonly newPasswordClass = { 'auth-form': true, 'auth-form-hide': true };

  private readonly invalidToken: boolean = false

  constructor(page: AuthManagerPage = AuthManagerPage.Login, private user: UserResetPassword = null) {
    if (page === AuthManagerPage.NewPassword) {
      if (user != null) {
        this.loginClass['auth-form-hide'] = true;
        this.rememberClass['auth-form-hide'] = true;
        this.newPasswordClass['auth-form-hide'] = false;
      }
      else {
        this.loginClass['auth-form-hide'] = true;
        this.rememberClass['auth-form-hide'] = false;
        this.newPasswordClass['auth-form-hide'] = true;

        this.invalidToken = true;
      }
    }
    else if (page === AuthManagerPage.NoToken) {
      this.loginClass['auth-form-hide'] = false;
      this.rememberClass['auth-form-hide'] = true;
      this.newPasswordClass['auth-form-hide'] = true;
    }
  }

  login_LoadApplication(app: LoginApplication) {
    //app.loading = true;
    app.userNamePlaceholder = 'Email';
    app.passwordPlaceholder = 'Password';

    app.noAuthorizedMessage = 'Email and password are not accepted';
    app.serverErrorMessage = 'Internal Server Error';

    app.state = ErrorState.Empty;

    const props = app.properties;

    props.userName.setRequired(CustomValidators.email('Incorrect format'));
    props.password.setRequired();

    props.signInSubmit.onClick.subscribe({
      next: (event: any) => {

      }
    });

    props.forgotPasswordSubmit.onClick.subscribe({
      next: (event: any) => {
        this.openRememberApp();

        setTimeout(() => {
          props.userName.Value = '';
          props.userName.markAsPristine();

          props.password.Value = '';
          props.password.markAsPristine();
        }, 500);
      }
    });
  }

  login_Initialize(app: LoginApplication) {
    const props = app.properties;

    let status = props.formGroup.status;

    const idInterval = setInterval(() => {
      if (status !== props.formGroup.status) {
        this.setSignInState(app);
        clearInterval(idInterval);
      }
    }, 100);

    props.formGroup.statusChanges.subscribe(() => {
      this.setSignInState(app);
    });
  }

  private setSignInState(app: LoginApplication) {
    const props = app.properties;

    if (props.formGroup.status !== FormControlStatus.Valid) {
      props.signInSubmit.disable();
    }
    else {
      props.signInSubmit.enable();
    }
  }

  remember_LoadApplication(app: RememberPasswordApplication) {
    const props = app.properties;

    const setInitial = () => {
      app.state = ErrorState.Empty;

      props.email.fadeIn();
      props.notification.fadeOut();
      props.rememberSubmit.show();
      props.closeSubmit.hide();
    }

    const onClose = () => {
      this.openLoginApp();

      setTimeout(() => {
        setInitial();

        props.email.Value = '';
        props.email.markAsPristine();
      }, 500);
    }
    //app.loading = true;

    app.unregisteredEmaildMessage = 'Unregistered email address';
    app.serverErrorMessage = 'Internal Server Error';

    setInitial();
    
    if (!this.invalidToken) {      
      app.notificationClass = 'notificationSuccess';
      props.notification.Value = 'Email successfully sent!';
    }
    else {
      app.notificationClass = 'notificationError';
      props.notification.Value = 'Sorry, your token expired! We need to re-send!';
      props.notification.fadeIn();
    }

    app.rememberSubmitText = 'Send';

    props.email.setRequired(CustomValidators.email('Incorrect format')); 

    props.rememberSubmit.onClick.subscribe({
      next: (event: any) => {
        app.notificationClass = 'notificationSuccess';
        props.notification.Value = 'Email successfully sent!';

        props.email.fadeOut();
        props.notification.fadeIn();
        props.rememberSubmit.hide();
        props.closeSubmit.show();
      }
    });

    props.closeSubmit.onClick.subscribe({
      next: (event: any) => {
        onClose();
      }
    });

    props.iconCloseSubmit.onClick.subscribe({
      next: (event: any) => {
        onClose();
      }
    });
  }

  remember_Initialize(app: RememberPasswordApplication) {
    const props = app.properties;

    let status = props.formGroup.status;

    const idInterval = setInterval(() => {
      if (status !== props.formGroup.status) {
        this.setRememberState(app);
        clearInterval(idInterval);
      }
    }, 100);

    props.formGroup.statusChanges.subscribe(() => {
      this.setRememberState(app);
    });
  }

  private setRememberState(app: RememberPasswordApplication) {
    const props = app.properties;

    if (props.formGroup.status !== FormControlStatus.Valid) {
      props.rememberSubmit.disable();
    }
    else {
      props.rememberSubmit.enable();
    }
  }

  newPass_LoadApplication(app: NewPasswordApplication) {
    const props = app.properties;

    const strongPasswordValidator = (message: string): ValidatorFn => {
      return (control: AbstractControl): MessageValidator => {
        if (props.password.valueIsNull() || props.repeatPassword.valueIsNull())
          return null;

        return props.password.Value != props.repeatPassword.Value ? new MessageValidator(message) : null;
      }
    }

    props.password.setRequired([
      CustomValidators.minLength(8, 'It must be eight characters or longer'),
      CustomValidators.pattern(/.*[a-z]/, 'It must contain at least 1 lowercase alphabetical character'),
      CustomValidators.pattern(/.*[A-Z]/, 'It must contain at least 1 uppercase alphabetical character'),
      CustomValidators.pattern(/.*[!@#$%^&*]/, 'It must contain at least one special character'),
      CustomValidators.pattern(/.*[0-9]/, 'It must contain at least 1 numeric character')
    ]);
    props.repeatPassword.setRequired();

    const setInitial = () => {
      app.state = ErrorState.Empty;

      props.notification.hide();
      props.password.show();
      props.repeatPassword.show();
      props.resetSubmit.show();
      props.closeSubmit.hide();
    }

    const onClose = () => {
      this.closeNewPasswordApp();

      setTimeout(() => {
        setInitial();

        props.password.Value = '';
        props.password.markAsPristine();

        props.repeatPassword.Value = '';
        props.repeatPassword.markAsPristine();
      }, 500);
    }
    //app.loading = true;

    props.notification.Value = 'Your password has been changed successfully';
    app.serverErrorMessage = 'Internal Server Error';
    app.passwordPlaceholder = 'Password';
    app.repeatPasswordPlaceholder = 'Repeat Password';

    setInitial();

    props.resetSubmit.onClick.subscribe({
      next: (event: any) => {
        props.notification.show();
        props.password.hide();
        props.repeatPassword.hide();
        props.resetSubmit.hide();
        props.closeSubmit.show();
      }
    });

    props.closeSubmit.onClick.subscribe({
      next: (event: any) => {
        onClose();
        window.history.pushState('', 'login', '/login');
      }
    });
  }

  newPass_Initialize(app: NewPasswordApplication) {
    const props = app.properties;

    const passwordEqualRepeatPasswordValidator = (message: string): ValidatorFn => {
      return (control: AbstractControl): MessageValidator => {
        if (props.password.valueIsNull() || props.repeatPassword.valueIsNull())
          return null;

        return props.password.Value != props.repeatPassword.Value ? new MessageValidator(message) : null;
      }
    }

    props.formGroup.setValidators([passwordEqualRepeatPasswordValidator('Passwords are not equal')]);

    let status = props.formGroup.status;

    const idInterval = setInterval(() => {
      if (status !== props.formGroup.status) {
        this.setNewPassState(app);
        clearInterval(idInterval);
      }
    }, 100);

    props.formGroup.statusChanges.subscribe(() => {
      this.setNewPassState(app);
    });
  }

  private setNewPassState(app: NewPasswordApplication) {
    const props = app.properties;

    if (props.formGroup.status !== FormControlStatus.Valid) {
      props.resetSubmit.disable();
    }
    else {
      props.resetSubmit.enable();
    }
  }

  private openLoginApp() {
    this.loginClass['auth-form-hide'] = false;
    this.rememberClass['auth-form-hide'] = true;
  }

  private openRememberApp() {
    this.loginClass['auth-form-hide'] = true;
    this.rememberClass['auth-form-hide'] = false;
  }

  private closeNewPasswordApp() {
    this.loginClass['auth-form-hide'] = false;
    this.newPasswordClass['auth-form-hide'] = true;
  }
}
