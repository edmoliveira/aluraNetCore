import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PortalComponent } from './components/portal/portal.component';
import { LoginComponent } from './components/login/login.component';
import { AuthGuard } from '../../../shared/helpers/auth-guard';
import { NewPasswordComponent } from './components/new-password/new-password.component';


const routes: Routes = [
  { path: '', component: PortalComponent, canActivate: [AuthGuard], pathMatch: 'full', data: { animation: 'Portal' } }
  , { path: 'login', component: LoginComponent, data: { animation: 'Login' } }
  , { path: 'newPass', component: NewPasswordComponent, data: { animation: 'NewPassword' } }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
