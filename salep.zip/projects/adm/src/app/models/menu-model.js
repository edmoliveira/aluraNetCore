"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var MenuModel = /** @class */ (function () {
    function MenuModel() {
        this.isOpen = false;
        this.items = [];
    }
    MenuModel.prototype.addItem = function (item) {
        this.items.push(item);
    };
    MenuModel.prototype.removeItem = function (index) {
        this.items.splice(index, 1);
    };
    return MenuModel;
}());
exports.MenuModel = MenuModel;
//# sourceMappingURL=menu-model.js.map