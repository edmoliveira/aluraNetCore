"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ItemMenuModel = /** @class */ (function () {
    function ItemMenuModel() {
    }
    return ItemMenuModel;
}());
exports.ItemMenuModel = ItemMenuModel;
//# sourceMappingURL=item-menu-model.js.map