"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ComponentModel = /** @class */ (function () {
    function ComponentModel(id, title, type) {
        this.id = id;
        this.title = title;
        this.type = type;
    }
    return ComponentModel;
}());
exports.ComponentModel = ComponentModel;
//# sourceMappingURL=component-model.js.map