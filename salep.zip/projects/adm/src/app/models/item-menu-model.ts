import { MenuModel } from './menu-model';
import { ComponentModel } from './component-model';

export class ItemMenuModel {
  icon: any;
  description: string;
  parent: MenuModel;
  component: ComponentModel;
}
