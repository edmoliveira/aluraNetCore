import { Type } from '@angular/core';

export class ComponentModel {
  constructor(public id: number, public title: string, public type: Type<any>) {

  }
}
