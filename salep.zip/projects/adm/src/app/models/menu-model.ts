import { ItemMenuModel } from './item-menu-model';
import { ElementRef } from '@angular/core';

export class MenuModel {
  icon: any;
  description: string;
  items: ItemMenuModel[];
  oClass: any;
  element: any;
  isOpen: boolean = false;

  constructor() {
    this.items = [];
  }

  addItem(item: ItemMenuModel) {
    this.items.push(item);
  }

  removeItem(index:number) {
    this.items.splice(index, 1);
  }
}
